/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef ETHERNET_H_INC
#define ETHERNET_H_INC  1

#define ETH_HEADER_LEN  14
#define ETHER_SIZE      1518

/* packet types */
#define ETH_IP_TYPE  0x0800
#define ETH_ARP_TYPE 0x0806
#define ETH_TYPE_HB  0x08
#define ETH_IP_LB    0x00
#define ETH_ARP_LB   0x06

/* hardware type */
#define ETHERNET_10MB_HB   0x00
#define ETHERNET_10MB_LB   0x01

int mn_ether_init(void) cmx_reentrant;
SCHAR ether_recv_header(void) cmx_reentrant;
SCHAR mn_ether_start_packet(PSOCKET_INFO,word16,byte) cmx_reentrant;
void start_arp_packet(PSOCKET_INFO,byte) cmx_reentrant;
byte mn_get_xmit_byte(void) cmx_reentrant;
#if (USE_RECV_BUFF)
void mn_put_recv_byte(byte) cmx_reentrant;
#endif      /* (USE_RECV_BUFF) */

/* ----------------------------------------- */
/* Ethernet macros                           */
/* ----------------------------------------- */

/* the function defined for ETHER_POLL_RECV should return number of bytes
   received if successful or negative number on error. define this macro
   only if using the ethernet chip in polled mode.

   the function defined for ETHER_INIT should return 1 if initialization
   successful or negative number on error.

   the function defined for ETHER_SEND should return the number of bytes
   sent or negative number on error. It takes two parameters, a pointer to
   the socket used and the number of data bytes sent. Note that the number
   of data bytes sent will be zero for TCP control packets and ARP packets.
*/
#if (defined(POLAVRR) || defined(CMXAVRR))
int rtl8019_recv(void) cmx_reentrant;
int rtl8019_init(void) cmx_reentrant;
int rtl8019_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       rtl8019_recv()
#define ETHER_INIT            rtl8019_init()
#define ETHER_SEND(p,n)       rtl8019_send((p),(n))
#elif (defined(POLPIC18E) || defined(CMXPIC18E))
int rtl8019_recv(void) cmx_reentrant;
int rtl8019_init(void) cmx_reentrant;
int rtl8019_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       rtl8019_recv()
#define ETHER_INIT            rtl8019_init()
#define ETHER_SEND(p,n)       rtl8019_send((p),(n))
#elif (defined(POLDSPICE) || defined(CMXDSPICE))
int rtl8019_recv(void) cmx_reentrant;
int rtl8019_init(void) cmx_reentrant;
int rtl8019_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       rtl8019_recv()
#define ETHER_INIT            rtl8019_init()
#define ETHER_SEND(p,n)       rtl8019_send((p),(n))
#elif (defined(POLPHY165) || defined(CMXPHY165) || defined(POLTQS167) || \
   defined(POL188) || defined(CMXTQS167) || defined(CMX188))
int smsc91C96_recv(void) cmx_reentrant;
int smsc91C96_init(void) cmx_reentrant;
int smsc91C96_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C96_recv()
#define ETHER_INIT            smsc91C96_init()
#define ETHER_SEND(p,n)       smsc91C96_send((p),(n))
#elif (defined(POLH8S2674) || defined(CMXH8S2674))
int smsc91C96_recv(void) cmx_reentrant;
int smsc91C96_init(void) cmx_reentrant;
int smsc91C96_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C96_recv()
#define ETHER_INIT            smsc91C96_init()
#define ETHER_SEND(p,n)       smsc91C96_send((p),(n))
#elif (defined(POLH8S2329) || defined(CMXH8S2329))
int smsc91C96_recv(void) cmx_reentrant;
int smsc91C96_init(void) cmx_reentrant;
int smsc91C96_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C96_recv()
#define ETHER_INIT            smsc91C96_init()
#define ETHER_SEND(p,n)       smsc91C96_send((p),(n))
#elif (defined(POLTRI51_SMSC) || defined(CMXTRI51_SMSC))
int smsc91C111_recv(void) cmx_reentrant;
int smsc91C111_init(void) cmx_reentrant;
int smsc91C111_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C111_recv()
#define ETHER_INIT            smsc91C111_init()
#define ETHER_SEND(p,n)       smsc91C111_send((p),(n))
#elif (defined(POLECOG1E) || defined(CMXECOG1E))
int smsc91C111_recv(void) cmx_reentrant;
int smsc91C111_init(void) cmx_reentrant;
int smsc91C111_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C111_recv()
#define ETHER_INIT            smsc91C111_init()
#define ETHER_SEND(p,n)       smsc91C111_send((p),(n))
#elif (defined(POLM16CP) || defined(CMXM16CP))
int smsc91C111_recv(void) cmx_reentrant;
int smsc91C111_init(void) cmx_reentrant;
int smsc91C111_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C111_recv()
#define ETHER_INIT            smsc91C111_init()
#define ETHER_SEND(p,n)       smsc91C111_send((p),(n))
#elif (defined(POLM16C654) || defined(CMXM16C654))
int smsc91C96_recv(void) cmx_reentrant;
int smsc91C96_init(void) cmx_reentrant;
int smsc91C96_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C96_recv()
#define ETHER_INIT            smsc91C96_init()
#define ETHER_SEND(p,n)       smsc91C96_send((p),(n))
#elif (defined(POLST7E) || defined(CMXST7E))
int rtl8019_recv(void) cmx_reentrant;
int rtl8019_init(void) cmx_reentrant;
int rtl8019_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       rtl8019_recv()
#define ETHER_INIT            rtl8019_init()
#define ETHER_SEND(p,n)       rtl8019_send((p),(n))
#elif (defined(POLHC12E) || defined(CMXHC12E))
int smsc91C111_recv(void) cmx_reentrant;
int smsc91C111_init(void) cmx_reentrant;
int smsc91C111_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C111_recv()
#define ETHER_INIT            smsc91C111_init()
#define ETHER_SEND(p,n)       smsc91C111_send((p),(n))
#elif (defined(POLHC12NE64) || defined(CMXHC12NE64))
int ne64_init(void) cmx_reentrant;
int ne64_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV
#define ETHER_INIT            ne64_init()
#define ETHER_SEND(p,n)       ne64_send((p),(n))
#elif (defined(POLH8S2329) || defined(CMXH8S2329))
int smsc91C96_recv(void) cmx_reentrant;
int smsc91C96_init(void) cmx_reentrant;
int smsc91C96_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       smsc91C96_recv()
#define ETHER_INIT            smsc91C96_init()
#define ETHER_SEND(p,n)       smsc91C96_send((p),(n))
#elif (defined(POLH8S2238) || defined(CMXH8S2238))
/* wireless ethernet driver settings */
int wlan_recv(void) cmx_reentrant;
int wlan_init(void) cmx_reentrant;
int wlan_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       wlan_recv()
#define ETHER_INIT            wlan_init()
#define ETHER_SEND(p,n)       wlan_send((p),(n))
#elif (defined(POLARM9) || defined(CMXARM9))
int AT91F_EmacRecv(void) cmx_reentrant;
int AT91F_EmacEntry(void) cmx_reentrant;
int AT91F_EmacSend(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       AT91F_EmacRecv()
#define ETHER_INIT            AT91F_EmacEntry()
#define ETHER_SEND(p,n)       AT91F_EmacSend((p),(n))
#elif (defined(POLEZ80F91) || defined(CMXEZ80F91))
int f91eth_recv(void) cmx_reentrant;
int f91eth_init(void) cmx_reentrant;
int f91eth_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       f91eth_recv()
#define ETHER_INIT            f91eth_init()
#define ETHER_SEND(p,n)       f91eth_send((p),(n))
#elif (defined(POLEZ8E) || defined(CMXEZ8E))
int rtl8019_recv(void) cmx_reentrant;
int rtl8019_init(void) cmx_reentrant;
int rtl8019_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       rtl8019_recv()
#define ETHER_INIT            rtl8019_init()
#define ETHER_SEND(p,n)       rtl8019_send((p),(n))
#else
#if 0
/* wireless ethernet driver settings */
int wlan_recv(void) cmx_reentrant;
int wlan_init(void) cmx_reentrant;
int wlan_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       wlan_recv()
#define ETHER_INIT            wlan_init()
#define ETHER_SEND(p,n)       wlan_send((p),(n))
#else
int cs8900_recv(void) cmx_reentrant;
int cs8900_init(void) cmx_reentrant;
int cs8900_send(PSOCKET_INFO, word16) cmx_reentrant;
#define ETHER_POLL_RECV       cs8900_recv()
#define ETHER_INIT            cs8900_init()
#define ETHER_SEND(p,n)       cs8900_send((p),(n))
#endif
#endif

#if (!defined(ETHER_INIT))
#error Ethernet selected but not set up! Possibly the wrong batch/project file was used.
#endif
#if (POLLED_ETHERNET && !defined(ETHER_POLL_RECV))
#error Polled Ethernet selected but not set up! Possibly the wrong batch/project file was used.
#endif

#endif   /* #ifndef ETHERNET_H_INC */

