/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

#if UDP

/* ----------------------------------------------------------------------- */

/* Get a UDP packet. Returns number of data bytes received on the socket,
   negative number on error, or 0 if no data received or the destination
   socket does not exist. psocket_ptr will point to the socket that received
   the data. mn_ip_recv() MUST be called before calling this function.
*/
int mn_udp_recv(PSOCKET_INFO *psocket_ptr)
cmx_reentrant {
   byte c, odd_byte;
   word16 udp_csum, src_port, dest_port;
   word16 data_len;
   word16 udp_pkt_len;
   word32 csum;
   PSOCKET_INFO socket_ptr;
   word16 temp_data;

   dest_port = LSHIFT8(mn_recv_escaped_byte(TRUE));
   dest_port += (word16)mn_recv_escaped_byte(TRUE);
   src_port = LSHIFT8(mn_recv_escaped_byte(TRUE));
   src_port += (word16)mn_recv_escaped_byte(TRUE);

   /* check what socket the packet goes to. check active open first. */
   socket_ptr = mn_find_socket(src_port, dest_port, recv_src_addr, PROTO_UDP);
   if (socket_ptr == PTR_NULL)
      {
      /* socket not found, check for passive open (socket_ptr->dest_port == 0) */
      socket_ptr = mn_find_socket(src_port, 0, recv_src_addr, PROTO_UDP);
      if (socket_ptr == PTR_NULL)
         socket_ptr = mn_find_socket(src_port, 0, null_addr, PROTO_UDP);
      if (socket_ptr != PTR_NULL)
         {
         /* socket found */
         socket_ptr->dest_port = dest_port;
         }
      else
         {
#if (TFTP)
         /* Look for a tftp bound message, specifically the first message
            from a server when the server changes its own port number.
         */
         socket_ptr = mn_find_socket(src_port, TFTP_SERVER_PORT, \
            recv_src_addr, PROTO_UDP);
         if (socket_ptr != PTR_NULL)
            {
            /* socket found */
            socket_ptr->dest_port = dest_port;
            }
         else
#endif      /* (TFTP) */
            {
            *psocket_ptr = PTR_NULL;
            mn_ip_discard_packet();
            return (0);
            }
         }
      }

   *psocket_ptr = socket_ptr;

#if (SOCKET_INACTIVITY_TIME)
   /* We got a packet for the socket so reset the inactivity timer if
      required.
   */
   mn_reset_inactivity_timer(socket_ptr);
#endif      /* (SOCKET_INACTIVITY_TIME) */

#if (ETHERNET && !ARP)
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
   (void)memcpy((void *)socket_ptr->eth_dest_hw_addr,(void *)eth_dest_hw_addr,\
      ETH_ADDR_LEN);
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif

   if (socket_ptr->ip_dest_addr[0] == 0)
      {
#if (ALLOW_MULTICAST)
      if (socket_ptr->socket_type & MULTICAST_TYPE)
         {
         socket_ptr->ip_dest_addr[0] = recv_dest_addr[0];
         socket_ptr->ip_dest_addr[1] = recv_dest_addr[1];
         socket_ptr->ip_dest_addr[2] = recv_dest_addr[2];
         socket_ptr->ip_dest_addr[3] = recv_dest_addr[3];
         }
      else
#endif      /* (ALLOW_MULTICAST) */
         {
         socket_ptr->ip_dest_addr[0] = recv_src_addr[0];
         socket_ptr->ip_dest_addr[1] = recv_src_addr[1];
         socket_ptr->ip_dest_addr[2] = recv_src_addr[2];
         socket_ptr->ip_dest_addr[3] = recv_src_addr[3];
         }
      }

   udp_pkt_len = LSHIFT8(mn_recv_escaped_byte(TRUE));
   udp_pkt_len += (word16)mn_recv_escaped_byte(TRUE);

   if (udp_pkt_len < UDP_HEADER_LEN)
      {
      *psocket_ptr = (PSOCKET_INFO)PTR_NULL;
      mn_ip_discard_packet();
      return (UDP_ERROR);
      }

   udp_csum = LSHIFT8(mn_recv_escaped_byte(TRUE));
   udp_csum += (word16)mn_recv_escaped_byte(TRUE);

   csum = 0;
   temp_data = 0;

   if (udp_csum)           /* if checksum is zero ignore it */
      {
      /* bww new parameters */
#if (BOOTP || DHCP || ALLOW_BROADCAST || ALLOW_MULTICAST)
      csum = mn_udp_tcp_start_checksum(PROTO_UDP, udp_pkt_len,\
            src_port, dest_port, recv_dest_addr, \
            recv_src_addr);
            
#else
#if (PPP || PING_GLEANING || !(ARP))
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || PING_GLEANING || !(ARP)) */
      csum = mn_udp_tcp_start_checksum(PROTO_UDP, udp_pkt_len,\
            src_port, dest_port, ip_src_addr, \
            socket_ptr->ip_dest_addr);
#if (PPP || PING_GLEANING || !(ARP))
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || PING_GLEANING || !(ARP)) */
#endif      /* (BOOTP || DHCP || ALLOW_BROADCAST || ALLOW_MULTICAST) */
      }

   udp_pkt_len -= UDP_HEADER_LEN;
   data_len = udp_pkt_len;
   if (data_len)
      {
      odd_byte = 0;
      mn_app_init_recv(data_len,socket_ptr);
      do {
         c = (byte)(mn_recv_escaped_byte(TRUE));
         if (udp_csum)
            {
            /* need to add to checksum in words, so every other byte updates
               the checksum.
            */
            if (!odd_byte)
               {
               temp_data = LSHIFT8(c);
               odd_byte = 1;
               }
            else
               {
               temp_data += (word16)(c);
               csum += temp_data;
               odd_byte = 0;
               }
            }
         mn_app_recv_byte(c,socket_ptr);
         }
      while (--data_len);

      if (udp_csum && odd_byte)     /* make sure we get all the csum data */
         csum += temp_data;
      }
   else
      socket_ptr->recv_len = 0;

   if (udp_csum)
      {
      /* finish checksum */
      csum = mn_udp_tcp_end_checksum(csum);
      if (csum != udp_csum)   /* checksum NG, so ignore packet */
         {
         mn_ip_discard_packet();
         return (UDP_BAD_CSUM);
         }
      }
#if PPP
   if(!mn_recv_fcs_ok())
      {
      mn_ip_discard_packet();
      return (UDP_BAD_FCS);
      }
#endif      /* PPP */

   (void)mn_app_process_packet(socket_ptr);

   mn_ip_discard_packet();

   return ((int)socket_ptr->recv_len);
}

/* Send IP header, UDP header and data. */
/* Returns number of data bytes sent or negative number on error. */
int mn_udp_send(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   word16 data_len;
   word16 udp_pkt_len;
   byte *MsgSendPointer;
#if (UDP_CHKSUM)
   word32 csum;
   word16 udp_csum;
#endif
   SCHAR retval;

   if (socket_ptr == PTR_NULL)
      return (BAD_SOCKET_DATA);

   data_len = mn_app_get_send_size(socket_ptr);
   if (data_len == 0)
      return (0);

   MsgSendPointer = socket_ptr->send_ptr;
   udp_pkt_len = data_len + UDP_HEADER_LEN;

#if (UDP_CHKSUM)
/* bww new parameters */
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
   csum = mn_udp_tcp_start_checksum(PROTO_UDP,udp_pkt_len,\
      socket_ptr->src_port, socket_ptr->dest_port, ip_src_addr, \
      socket_ptr->ip_dest_addr);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */

   /* checksum on data */
   csum = mn_data_send_checksum(csum, MsgSendPointer, data_len);

   /* finish checksum */
   csum = mn_udp_tcp_end_checksum(csum);
   udp_csum = (word16)csum;
#endif      /* (UDP_CHKSUM) */

   retval = mn_ip_send_header(socket_ptr,socket_ptr->ip_proto,udp_pkt_len);
   if (retval != 1)
      return ((int)retval);
   mn_send_escaped_byte(HIGHBYTE(socket_ptr->src_port),TRUE);
   mn_send_escaped_byte(LOWBYTE(socket_ptr->src_port),TRUE);
   mn_send_escaped_byte(HIGHBYTE(socket_ptr->dest_port),TRUE);
   mn_send_escaped_byte(LOWBYTE(socket_ptr->dest_port),TRUE);
   mn_send_escaped_byte(HIGHBYTE(udp_pkt_len),TRUE);
   mn_send_escaped_byte(LOWBYTE(udp_pkt_len),TRUE);
#if (UDP_CHKSUM)
   mn_send_escaped_byte(HIGHBYTE(udp_csum),TRUE);
   mn_send_escaped_byte(LOWBYTE(udp_csum),TRUE);
#else    /* no checksum */
   mn_send_escaped_byte(0,TRUE);
   mn_send_escaped_byte(0,TRUE);
#endif      /* (UDP_CHKSUM) */

#if (!ETHERNET)
   while (data_len)
      {
      mn_send_escaped_byte(*MsgSendPointer++,TRUE);
      data_len--;
      }
#endif      /* (!ETHERNET) */
   /* At this point for PPP and SLIP data_len will always be zero. This is
      ok because mn_close_packet only uses it for ethernet packets.
   */
   MN_TASK_LOCK;
   retval = mn_close_packet(socket_ptr, data_len);
   MN_TASK_UNLOCK;
   if (retval <= 0)
      return ((int)retval);

   return ((int)socket_ptr->send_len);
}
#endif   /* UDP */

