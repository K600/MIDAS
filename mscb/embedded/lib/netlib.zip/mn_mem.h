/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MN_MEM_H_INC
#define MN_MEM_H_INC 1

#if NEED_MEM_POOL

#if (defined(POLNECV850) || defined(CMXNECV850))
extern int __sysheap[MEM_POOL_SIZE>>2];
#define MEM_POOL_INIT         MEMSET((char *)__sysheap, 0, MEM_POOL_SIZE)
#elif (defined(__C51__) || defined(__C166__))  /* Keil C51 or C166 */
#define MEM_POOL_INIT         init_mempool(&mem_pool[0],MEM_POOL_SIZE)
#elif ((defined(POLPIC18) || defined(CMXPIC18) || defined(POLPIC18E) || \
    defined(CMXPIC18E)) && defined(HI_TECH_C))
extern char _Lheap[MEM_POOL_SIZE];
#define MEM_POOL_INIT         MEMSET(_Lheap, 0, MEM_POOL_SIZE)
#else
#define MEM_POOL_INIT
#endif

#else

#define MEM_POOL_INIT

#endif      /* NEED_MEM_POOL */

#endif      /* #ifndef MN_MEM_H_INC */
