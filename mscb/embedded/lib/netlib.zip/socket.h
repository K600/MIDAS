/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef SOCKET_H_INC
#define SOCKET_H_INC 1

#if TCP
typedef union seqnum_u {
   byte NUMC[4];
   word16 NUMW[2];
   word32 NUML;
} SEQNUM_U;

#endif      /* TCP */

typedef struct socket_info_s {
   word16 src_port;
   word16 dest_port;
   byte ip_dest_addr[IP_ADDR_LEN];
#if ETHERNET
   byte eth_dest_hw_addr[ETH_ADDR_LEN];
#endif
   byte *send_ptr;
   word16 send_len;
   byte *recv_ptr;
   byte *recv_end;
   word16 recv_len;
   byte ip_proto;
   byte socket_no;
   byte socket_type;
   byte socket_state;
#if (SOCKET_INACTIVITY_TIME)
   word16 inactivity_timer;
#endif      /* (SOCKET_INACTIVITY_TIME) */
#if (RTOS_USED != RTOS_NONE)
   int last_return_value;
#endif      /* (RTOS_USED != RTOS_NONE) */
#if TCP
   byte tcp_state;
   byte tcp_resends;
   byte tcp_flag;
   byte recv_tcp_flag;
   byte data_offset;
   word16 tcp_unacked_bytes;
   word16 recv_tcp_window;
   SEQNUM_U RCV_NXT;
   SEQNUM_U SEG_SEQ;
   SEQNUM_U SEG_ACK;
   SEQNUM_U SND_UNA;
   TIMER_INFO_T tcp_timer;
#endif      /* TCP */
} SOCKET_INFO_T;

typedef SOCKET_INFO_T * PSOCKET_INFO;
#define MK_SOCKET_PTR(s)      &sock_info[(s)]
#define SOCKET_ACTIVATE(s)    sock_info[(s)].socket_state |= 0x01
#define SOCKET_DEACTIVATE(s)  sock_info[(s)].socket_state = 0
#define SOCKET_ACTIVE(s)      (sock_info[(s)].socket_state & 0x01)
#define CLEAR_SOCKET(s)       { SOCKET_DEACTIVATE(s); }

/* Ports */
#define DEFAULT_PORT       1500
#define ECHO_PORT          7
#define HTTP_PORT          80
#define SMTP_PORT          25
#define FTP_DATA_PORT      20
#define FTP_CONTROL_PORT   21
#define BOOTP_SERVER_PORT  67
#define BOOTP_CLIENT_PORT  68
#define DHCP_SERVER_PORT   67
#define DHCP_CLIENT_PORT   68
#define TFTP_SERVER_PORT   69
/* ARP doesn't use ports but we need a port number to get a socket */
#define ARP_PORT           0xFFFF
/* PING doesn't use ports but we need a port number to get a socket */
#define PING_PORT          0

/* socket types */
#define  STD_TYPE       0x00
#define  HTTP_TYPE      0x01
#define  FTP_TYPE       0x02
#define  SMTP_TYPE      0x04
#define  TFTP_TYPE      0x08
#define  MULTICAST_TYPE 0x10
#define  S_ARP_TYPE     0x20
#define  AUTO_TYPE      0x40   /* for automatically created sockets */
#define  INACTIVITY_TIMER  0x80

/* open types */
#define PASSIVE_OPEN    0
#define ACTIVE_OPEN     1
#define NO_OPEN         2

/* used by mn_tcp_recv_header */
#define SAME_SOCKET     0
#define NEW_SOCKET      1

/* socket states */
#define ACTIVE_STATE          0x01
#define SENDING_STATE         0x02

/* Macros for HTTP and FTP servers */
#define SET_SENDING(s)        sock_info[(s)].socket_state |= (SENDING_STATE)
#define CLEAR_SENDING(s)      sock_info[(s)].socket_state &= ((byte)(~(SENDING_STATE)))
#define WAS_SENDING(s)        (sock_info[(s)].socket_state & (SENDING_STATE))


int mn_init(void) cmx_reentrant;
SCHAR mn_open(byte [], word16, word16, byte, byte, byte, byte *, word16) cmx_reentrant;
SCHAR mn_open_socket(byte [], word16, word16, byte, byte, byte *, word16) cmx_reentrant;
int mn_send(SCHAR, byte *, word16) cmx_reentrant;
int mn_recv(SCHAR, byte *, word16) cmx_reentrant;
int mn_recv_wait(SCHAR, byte *, word16, word16) cmx_reentrant;
int mn_close(SCHAR) cmx_reentrant;
int mn_abort(SCHAR) cmx_reentrant;
byte mn_get_socket_type(word16 src_port) cmx_reentrant;
SCHAR mn_close_packet(PSOCKET_INFO, word16) cmx_reentrant;
PSOCKET_INFO mn_find_socket(word16,word16,byte *,byte) cmx_reentrant;
#if (SOCKET_INACTIVITY_TIME)
#if (defined(_CC51))     /* Tasking 8051 */
_noregaddr void mn_update_inactivity_timers(void);
#else
void mn_update_inactivity_timers(void) cmx_reentrant;
#endif      /* (defined(_CC51)) */
void mn_reset_inactivity_timer(PSOCKET_INFO) cmx_reentrant;
#endif      /* (SOCKET_INACTIVITY_TIME) */

/* SR */
int mn_get_link_status(void) cmx_reentrant;

#endif   /* #ifndef SOCKET_H_INC */

