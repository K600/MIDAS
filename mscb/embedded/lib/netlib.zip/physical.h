/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef PHYSICAL_H_INC
#define PHYSICAL_H_INC  1

void mn_send_byte(byte) cmx_reentrant;
int mn_recv_byte(void) cmx_reentrant;

#if (USE_RECV_BUFF && (READ_RECV_COUNT_ATOMIC || (ETHERNET && POLLED_ETHERNET)))
#define mn_recv_byte_present()   (recv_count)
#else
byte mn_recv_byte_present(void) cmx_reentrant;
#endif

#if (ETHERNET)
#define mn_send_escaped_byte(A,B)   mn_send_byte(A)
#define mn_recv_escaped_byte(A)     mn_recv_byte()
#else
void mn_send_escaped_byte(byte,byte) cmx_reentrant;
byte mn_recv_escaped_byte(byte) cmx_reentrant;
#endif

#endif   /* #ifndef PHYSICAL_H_INC */


