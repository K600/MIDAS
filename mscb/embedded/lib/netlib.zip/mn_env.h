/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MN_ENV_H_INC
#define MN_ENV_H_INC 1

/* processor specific includes */
#if (defined(POL8051) || defined(CMX8051))
#if (defined(__C51__))     /* Keil 8051 */
#include <reg52.h>
#elif (defined(_CC51))     /* Tasking 8051 */
#include <reg52.sfr>
#endif

#elif (defined(POLTRI51) || defined(CMXTRI51))
#if (defined(__C51__))     /* Keil 8051 */
#if (!defined(CMX_ETHER))
#include <reg52.h>
#endif
#endif

#elif (defined(POLTRI51_16) || defined(CMXTRI51_16))
#include "cmxikit3.h"

#elif (defined(POLTRI51_DMA) || defined(CMXTRI51_DMA) || \
         defined(POLTRI51_SMSC) || defined(CMXTRI51_SMSC))
#include "fastchip.h"
#include <TE5_CSOC.h>

#elif (defined(POLPHY51) || defined(CMXPHY51))
#if (defined(__C51__))     /* Keil 8051 */
#include "reg591.h"
#elif (defined(_CC51))     /* Tasking 8051 */
#include "reg591.sfr"
#endif

#elif (defined(POLRCH51) || defined(CMXRCH51))
#if (defined(__C51__))     /* Keil 8051 */
#include <reg52.h>
#endif

#elif (defined(POLC8051F124) || defined(CMXC8051F124))

/* SFR PAGE DEFINITIONS */
#define  CONFIG_PAGE       0x0F     /* SYSTEM AND PORT CONFIGURATION PAGE */
#define  LEGACY_PAGE       0x00     /* LEGACY SFR PAGE                    */
#define  TIMER01_PAGE      0x00     /* TIMER 0 AND TIMER 1                */
#define  CPT0_PAGE         0x01     /* COMPARATOR 0                       */
#define  CPT1_PAGE         0x02     /* COMPARATOR 1                       */
#define  UART0_PAGE        0x00     /* UART 0                             */
#define  UART1_PAGE        0x01     /* UART 1                             */
#define  SPI0_PAGE         0x00     /* SPI 0                              */
#define  EMI0_PAGE         0x00     /* EXTERNAL MEMORY INTERFACE          */
#define  ADC0_PAGE         0x00     /* ADC 0                              */
#define  ADC2_PAGE         0x02     /* ADC 2                              */
#define  SMB0_PAGE         0x00     /* SMBUS 0                            */
#define  TMR2_PAGE         0x00     /* TIMER 2                            */
#define  TMR3_PAGE         0x01     /* TIMER 3                            */
#define  TMR4_PAGE         0x02     /* TIMER 4                            */
#define  DAC0_PAGE         0x00     /* DAC 0                              */
#define  DAC1_PAGE         0x01     /* DAC 1                              */
#define  PCA0_PAGE         0x00     /* PCA 0                              */
#define  PLL0_PAGE         0x0F     /* PLL 0                              */

/* Cygnal C8051F124 */
#if (defined(__C51__))     /* Keil 8051 */
#include <c8051f120.h>

/* ------------------------------------------------------------------
 16-bit SFR Definitions for 'F12x
-------------------------------------------------------------------*/

sfr16 DP       = 0x82;                 /* data pointer */
sfr16 ADC0     = 0xbe;                 /* ADC0 data */
sfr16 ADC0GT   = 0xc4;                 /* ADC0 greater than window */
sfr16 ADC0LT   = 0xc6;                 /* ADC0 less than window */
sfr16 RCAP2    = 0xca;                 /* Timer2 capture/reload */
sfr16 RCAP3    = 0xca;                 /* Timer3 capture/reload */
sfr16 RCAP4    = 0xca;                 /* Timer4 capture/reload */
sfr16 TMR2     = 0xcc;                 /* Timer2 */
sfr16 TMR3     = 0xcc;                 /* Timer3 */
sfr16 TMR4     = 0xcc;                 /* Timer4 */
sfr16 DAC0     = 0xd2;                 /* DAC0 data */
sfr16 DAC1     = 0xd2;                 /* DAC1 data */
sfr16 PCA0CP5  = 0xe1;                 /* PCA0 Module 5 capture */
sfr16 PCA0CP2  = 0xe9;                 /* PCA0 Module 2 capture */
sfr16 PCA0CP3  = 0xeb;                 /* PCA0 Module 3 capture */
sfr16 PCA0CP4  = 0xed;                 /* PCA0 Module 4 capture */
sfr16 PCA0     = 0xf9;                 /* PCA0 counter */
sfr16 PCA0CP0  = 0xfb;                 /* PCA0 Module 0 capture */
sfr16 PCA0CP1  = 0xfd;                 /* PCA0 Module 1 capture */

#elif (defined(__ICC8051__))           /* IAR 8051 */
#include <intrinsics.h>
#include <io8051f124.h>
#include "cygf124.h"

#elif (defined(_CC51))     /* Tasking 8051 */
#include <regc51f12x.sfr>
#endif

#elif (defined(POLC8051F020) || defined(CMXC8051F020))
/* Cygnal C8051F020 */
#if (defined(_CC51))     /* Tasking 8051 */
#include "c8051f020.sfr"
#endif
#endif

/* end processor specific includes */

#if (!(defined(MCHP_C18)))
#include <limits.h>     /* for CHAR_BIT, used by tcp.c */
#endif

/* MPLAB Pic18 compiler doesn't define CHAR_BIT */
#if (!defined(CHAR_BIT))
#define CHAR_BIT     8
#endif

/* processor specific defines */
#define DYNAMIC_MEM_AVAILABLE 0     /* Set to 1 if malloc and free available */
                                    /* Currently only used by FTP server */
#define GET_TICK_ATOMIC       0     /* Set to 1 if instruction to get timer
                                       tick in mn_timer.c is atomic. If not
                                       sure set to 0. */
#define RECV_COUNT_ATOMIC     0     /* Set to 1 if instructions to increment
                                       and decrement recv_count are atomic.
                                       If not sure set to 0. */
#define READ_RECV_COUNT_ATOMIC   0  /* Set to 1 if instructions to read the
                                       recv_count are atomic.
                                       If not sure set to 0. */
#define USE_SEND_BUFF         1     /* Set to 1 to use the standard send_buff,
                                       set to 0 if supplying your own transmit
                                       buffer.
                                    */
#define USE_RECV_BUFF         1     /* Set to 1 to use the standard recv_buff,
                                       set to 0 if supplying your own receive
                                       buffer.
                                    */

#if (defined(POL8051) || defined(CMX8051))
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#elif defined(_CC51)          /* Tasking 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLTRI51) || defined(CMXTRI51))
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLTRI51_16) || defined(CMXTRI51_16) || defined(POLTRI51_DMA) || \
   defined(CMXTRI51_DMA) || defined(POLTRI51_SMSC) || defined(CMXTRI51_SMSC))
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLPHY51) || defined(CMXPHY51))
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#elif defined(_CC51)          /* Tasking 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLRCH51) || defined(CMXRCH51))
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON         {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLC8051F124) || defined(CMXC8051F124))
void start_xmit(void);
#define ONE_SECOND   100         /* number of timer ticks in one second */
#if defined(__C51__)          /* Keil 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON           start_xmit()
#define MN_LITTLE_ENDIAN         0
#elif (defined(__ICC8051__))
#define DISABLE_INTERRUPTS    __disable_interrupt()
#define ENABLE_INTERRUPTS     __enable_interrupt()
#define XMIT_INT_ON           start_xmit();
#define MN_LITTLE_ENDIAN         1
#elif (defined(_CC51))     /* Tasking 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON           start_xmit()
#define MN_LITTLE_ENDIAN         0
#endif

#elif (defined(POLC8051F020) || defined(CMXC8051F020))
/* Cygnal C8051F020 */
#define ONE_SECOND   1000         /* number of timer ticks in one second */
#if (defined(_CC51))     /* Tasking 8051 */
#define DISABLE_INTERRUPTS    EA = 0
#define ENABLE_INTERRUPTS     EA = 1
#define XMIT_INT_ON           {MN_XMIT_BUSY_SET; TI = 1;}
#define MN_LITTLE_ENDIAN         0
#endif
#endif

/* end processor specific defines */

#ifndef STRCPY_DEFINED
/* This macro used by vfile.c only. */
#define STRCPY_DEFINED        1
#define STRCPY(A,B)           strcpy((char *)(A),(char *)(B))
#endif

#ifndef MEMSET_DEFINED
#define MEMSET_DEFINED        1
#define MEMSET(A,B,C)         memset((A),(B),(C))
#endif

/* ------------------------------------------- */
/* You shouldn't need to change anything below */
/* ------------------------------------------- */

/* Convert word16 from host to network order */
#if MN_LITTLE_ENDIAN
#define hs2net(w)    ((word16)(((w)>>8) | ((w)<<8)))
#else
#define hs2net(w)    ((word16)(w))
#endif
#define net2hs(w)    hs2net(w)

/* Convert two bytes into a word16 */
#if (defined(MCHP_C18) || defined(HI_TECH_C))
#define MK_WORD16(H,L)  ( (word16)( ((word16)(H)<<8) | (L) ) )
#elif (defined(NC30) || defined(NC308) || defined(ZILOG_Z8) || defined(ZILOG))
#define MK_WORD16(H,L)  ( (word16)( ((word16)(H)<<8) | (L) ) )
#else
#define MK_WORD16(H,L)  ( (word16)( ((H)<<8) | (L) ) )
#endif

/* Convert two bytes into a word16 for checksum routines */
#if (defined(MCHP_C18) || defined(HI_TECH_C))
#define CSUM_WORD16(H,L)   ( ( ((word16)(H)<<8) & 0x0000FFFF) | (L) )
#elif (defined(NC30) || defined(NC308) || defined(ZILOG_Z8) || defined(ZILOG))
#define CSUM_WORD16(H,L)   ( ((word16)(H)<<8) | (L) )
#else
#define CSUM_WORD16(H,L)   ( ( ((H)<<8) & 0x0000FFFF) | (L) )
#endif

/* convert a byte to a word16 and shift it into the upper byte */
#if (defined(MCHP_C18) || defined(HI_TECH_C))
#define LSHIFT8(B)   ( (word16)((word16)(B)<<8) )
#elif (defined(NC30) || defined(NC308) || defined(ZILOG_Z8) || defined(ZILOG))
#define LSHIFT8(B)   ( (word16)((word16)(B)<<8) )
#else
#define LSHIFT8(B)   ( (word16)((B)<<8) )
#endif

/* extract the low or high byte out of a word16 */
#define HIGHBYTE(w)     ((byte)((w)>>8))
#define LOWBYTE(w)      ((byte)((w)&0x00ff))

/* extract the low or high word16 out of a word32 */
#define HIGHWORD(l)     ((word16)(((word32)(l) >> 16) & 0x0000FFFF))
#define LOWWORD(l)      ((word16)((l) & 0x0000FFFF))

/* extract bytes out of a word32 */
#define WORD32_BYTE0(l) ((byte)(((word32)(l) >>  0) & 0x000000FF))
#define WORD32_BYTE1(l) ((byte)(((word32)(l) >>  8) & 0x000000FF))
#define WORD32_BYTE2(l) ((byte)(((word32)(l) >> 16) & 0x000000FF))
#define WORD32_BYTE3(l) ((byte)(((word32)(l) >> 24) & 0x000000FF))

/* convert a byte to a word32 and shift it left one byte */
#define WORD32_LSHIFT8(B)  ( (word32)((word32)(B)<<8) )

/* convert a byte to a word32 and shift it left two bytes */
#define WORD32_LSHIFT16(B)  ( (word32)((word32)(B)<<16) )

/* convert a byte to a word32 and shift it left three bytes */
#define WORD32_LSHIFT24(B)  ( (word32)((word32)(B)<<24) )

/* convert 4 bytes to a word32 */
#define MK_WORD32(A,B,C,D)  \
((word32)( ((word32)(A)<<24) | ((word32)(B)<<16) | ((word32)(C)<<8) | (D) ))

#endif      /* #ifndef MN_ENV_H_INC */
