/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

/**************************************************************
 This file contains processor specific timer and uart routines 
***************************************************************/

#include "micronet.h"

/* global variables */
#if (defined(MCHP_C18))
#pragma udata mn_port2
#endif
#if (USE_RECV_BUFF)
byte recv_buff[RECV_BUFF_SIZE];
#endif      /* (USE_RECV_BUFF) */
#if (defined(MCHP_C18))
#pragma udata
#endif
#if (USE_SEND_BUFF)
byte send_buff[XMIT_BUFF_SIZE];
#endif      /* (USE_SEND_BUFF) */
#if (USE_RECV_BUFF)
byte *recv_out_ptr;
byte *volatile recv_in_ptr;
volatile RECV_COUNT_T recv_count;
#endif      /* (USE_RECV_BUFF) */
byte *volatile send_out_ptr;
byte *send_in_ptr;
#if (!(ETHERNET))
byte *send_end_ptr;
#endif      /* (!(ETHERNET)) */
#if (RTOS_USED == RTOS_NONE || defined(CMXPIC18))
volatile byte xmit_busy;
#endif      /* (RTOS_USED == RTOS_NONE || defined(CMXPIC18)) */
#if (RTOS_USED != RTOS_NONE)
#if (MODEM)
byte modem_mode;
#endif      /* (MODEM) */
#endif      /* (RTOS_USED != RTOS_NONE) */

#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
#if 0 /* (defined(POLPIC18) || defined(CMXPIC18)) */
/* some PIC compilers can't handle 16-bit math in ISRs, workaround by
   using a union
*/
volatile BYTE2WORD_U timer;
#define  timer_tick timer.w
#else
volatile TIMER_TICK_T timer_tick;   /* Restart timer */
#endif
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */

#define KEEP_ERROR_COUNT   0     /* set to 1 to count errors */
#if (KEEP_ERROR_COUNT)
volatile word16 uart_errors;
#endif

#define SEND_INIT    0
#define SEND_RESET   1
static void init_send(byte type) cmx_reentrant;

void wd_refresh(void); // ## SR

/* Warning: enabling LOG_OUTPUT may cause problems with the UART transmit ISR
   on some processors.
*/
#define LOG_OUTPUT   0
void Nputchr(byte cc) cmx_reentrant;
#if ( LOG_OUTPUT && !(defined(POLPIC18) || defined(CMXPIC18) || \
   defined(POLPIC18E) || defined(CMXPIC18E)) )
#define OBUF_SIZE 256
char obuf[OBUF_SIZE];
static char *obuf_ptr = obuf;
static char * const obuf_max = &obuf[OBUF_SIZE-1];

void Nputchr(byte cc)
cmx_reentrant {
   if (obuf_ptr > obuf_max)
      obuf_ptr = obuf;

   *obuf_ptr++ = cc;
}
#endif      /* LOG_OUTPUT */

#if (PPP || SLIP)
#if (RTOS_USED != RTOS_NONE)
   /* Send a signal to the modem module for each character if in modem
      mode. If we have a frame character send a signal to the PPP module
      if the PPP layer is not up, otherwise send a signal to the IP layer.
   */
#if (MODEM && PPP)
#define SEND_RECEIVE_SIGNAL(C) { \
   if (modem_mode) MN_ISR_SIGNAL_POST(SIGNAL_MODEM); \
   else if ((C) == PPP_FRAME) { \
      if (!ppp_status.up) MN_ISR_SIGNAL_POST(SIGNAL_PPP); \
      else MN_ISR_SIGNAL_POST(SIGNAL_RECEIVE); } \
}

#elif (PPP)
#define SEND_RECEIVE_SIGNAL(C) { \
   if ((C) == PPP_FRAME) { \
      if (!ppp_status.up) MN_ISR_SIGNAL_POST(SIGNAL_PPP); \
      else MN_ISR_SIGNAL_POST(SIGNAL_RECEIVE); } \
}

#elif (MODEM && SLIP)
#define SEND_RECEIVE_SIGNAL(C) { \
   if (modem_mode) MN_ISR_SIGNAL_POST(SIGNAL_MODEM); \
   else if ((C) == SLIP_END) MN_ISR_SIGNAL_POST(SIGNAL_RECEIVE); \
}

#elif (SLIP)
#define SEND_RECEIVE_SIGNAL(C) { \
   if ((C) == SLIP_END) MN_ISR_SIGNAL_POST(SIGNAL_RECEIVE); \
}
#endif
#endif      /* (RTOS_USED != RTOS_NONE) */
#endif      /* (PPP || SLIP) */

/* ----------------------------------------------------------------------- */

/* Initialize send buffer pointers. Modify this function as needed if the
   define USE_SEND_BUFF in mn_env.h is 0. 
*/
static void init_send(byte type)
cmx_reentrant {
#if (USE_SEND_BUFF)
   send_out_ptr = send_in_ptr = &send_buff[0];

#if (ETHERNET)
   if(type);
#else
   /* Set send_end_ptr to the last byte inside the send_buff if called
      from init_io_buffs(). Note: send_end_ptr is not used by ethernet.
   */
   if (type == SEND_INIT)
      send_end_ptr = &send_buff[XMIT_BUFF_SIZE - 1];
#endif      /* (!(ETHERNET)) */

#else
#endif      /* (USE_SEND_BUFF) */
}

#if (USE_RECV_BUFF)
/* Initialize receive buffer pointers. */
void init_recv(void)
cmx_reentrant {
   recv_in_ptr = recv_out_ptr = &recv_buff[0];
   recv_count = 0;
}
#endif      /* (USE_RECV_BUFF) */

/* initialize uart variables. This function must be called by all
   mn_uart_init functions.
*/
void init_io_buffs(void)
cmx_reentrant {
   init_recv();
   init_send(SEND_INIT);
#if (KEEP_ERROR_COUNT)
   uart_errors = 0;
#endif
#if (RTOS_USED != RTOS_NONE)
   MN_SET_MODEM_MODE(FALSE);
#endif      /* (RTOS_USED != RTOS_NONE) */
   MN_XMIT_BUSY_CLEAR;
}

/* waits up to SOCKET_WAIT_TICKS for the previous transmit to be done,
   i.e. xmit_busy = 0. returns 1 if it is ok to start the next packet or
   0 if not ok. Resets send_in_ptr and send_out_ptr if ok.

   If SOCKET_WAIT_TICKS is set at the default 6 seconds then returning 0
   is almost certainly a fatal error. Even the slowest serial link should
   be able to transmit a packet in less than 6 seconds. If SOCKET_WAIT_TICKS
   is set for a smaller value than the default then returning 0 may only mean
   that the packet is not done sending yet.
*/
byte mn_transmit_ready(void)
cmx_reentrant {
#if (RTOS_USED == RTOS_NONE)
   TIMER_INFO_T wait_timer;

#if 1
   /* This loop can be removed if you don't want to block */
   if (xmit_busy)
      {
      mn_reset_timer(&wait_timer,(SOCKET_WAIT_TICKS));
      while ( !mn_timer_expired(&wait_timer) )
         {
         if (!xmit_busy)
            break;
         }
      }
#endif

   if (!xmit_busy)
      init_send(SEND_RESET);

   return (byte)(!xmit_busy);
#else
   /* wait for signal */
   if (MN_SIGNAL_WAIT(SIGNAL_TRANSMIT,(SOCKET_WAIT_TICKS)) == SIGNAL_SUCCESS)
      {
      init_send(SEND_RESET);
      return (1);
      }
   return (0);
#endif      /* (RTOS_USED == RTOS_NONE) */

}

/* ----------------------------------------------------------------------- */

 
 
 
#if (defined(POL8051) || defined(CMX8051))
/* 8051 */
#if defined(__C51__)    /* Keil 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   SCON = 0X50;         /* 8 bits, no parity */
   T2CON = 0X34;  
   RCAP2H = 0XFF; 
   RCAP2L = 0XDC;       /* 9600 at 11.059 MHZ */
/* RCAP2L = 0XE8; */    /* 14400 at 11.059 MHZ */
/* RCAP2L = 0XEE; */    /* 19200 at 11.059 MHZ */
/* RCAP2L = 0XF4; */    /* 28800 at 11.059 MHZ */
/* RCAP2L = 0XF7; */    /* 38400 at 11.059 MHZ */
/* RCAP2L = 0XFA; */    /* 57600 at 11.059 MHZ */
/* RCAP2L = 0XFD; */    /* 115200 at 11.059 MHZ */
   PS = 1;              /* High priority interrupt */
   ES = 1;              /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void uart_isr(void) interrupt 4 using 2
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#pragma AREGS
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TMOD |= 0x01;        /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also. 7 is added to TL0 in tcp_timer to make up for the time spent
      in that function.
   */
   TH0 = 0x60;          /* load timer 0 counter with count for 10
                        milliseconds at 49 mhz, ## SR */
   TL0 = 0x7F;

   TR0 = 1;          /* set the timer 0 run bits */
   ET0 = 1;          /* enable timer  0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE && defined(TIMER_INTERRUPT))  /* ##SR */
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0x60;          /* load timer 0 counter ##SR */
   TL0 = 0x7F;
   TR0 = 1;
   MN_TICK_UPDATE;
#if defined(C51DEMO)
   P1 |= 0x02;          /* take care of watchdog */
   P1 &= ~0x02;
#endif

#ifdef USE_WATCHDOG
   wd_refresh(); /* ## SR */
#endif

#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#pragma AREGS
#endif      /* defined(__C51__) */

#if defined(_CC51)      /* Tasking 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();     /* do not remove this function call */
   SCON = 0X50;         /* 8 bits, no parity */
   T2CON = 0X34;  
   RCAP2H = 0XFF; 
   RCAP2L = 0XDC;       /* 9600 at 11.059 MHZ */
/* RCAP2L = 0XE8; */    /* 14400 at 11.059 MHZ */
/* RCAP2L = 0XEE; */    /* 19200 at 11.059 MHZ */
/* RCAP2L = 0XF4; */    /* 28800 at 11.059 MHZ */
/* RCAP2L = 0XF7; */    /* 38400 at 11.059 MHZ */
/* RCAP2L = 0XFA; */    /* 57600 at 11.059 MHZ */
   PS = 1;              /* High priority interrupt */
   ES = 1;              /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(4) _using(2) void uart_isr(void)
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TMOD |= 0x01;        /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also. 7 is added to TL0 in tcp_timer to make up for the time spent
      in that function.
   */
   TH0 = 0x60;          /* load timer 0 counter with count for 10
                           milliseconds at (49MHz / 12) ##SR */
   TL0 = 0x7F;

   TR0 = 1;             /* set the timer 0 run bits */
   ET0 = 1;             /* enable timer  0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(1) _using(1) void tcp_timer(void)
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0xDC;          /* load timer 0 counter */
   TL0 = 0x07;
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#endif      /* defined(_CC51) */
#endif      /* #if (defined(POL8051) || defined(CMX8051)) */

#if (defined(POLTRI51) || defined(CMXTRI51))
/* Triscend 8051 */
#if defined(__C51__)    /* Keil 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   SCON = 0X50;         /* 8 bits, no parity */
   T2CON = 0X34;  
/* RCAP2H = 0XFE; */    /* 1200 at 11.059 MHZ */
/* RCAP2L = 0XE0; */    /* 1200 at 11.059 MHZ */
   RCAP2H = 0XFF;
/* RCAP2L = 0XDC; */       /* 9600 at 11.059 MHZ */
/* RCAP2L = 0XEE; */       /* 19200 at 11.059 MHZ */
/* RCAP2L = 0XAE; */       /* 9600 at 25 MHZ */
/* RCAP2L = 0XD7; */       /* 19200 at 25 MHZ */
/* RCAP2L = 0XF2; */       /* 57600 at 25 MHZ */
   RCAP2L = 0X9e;          /* 9600 at 30 MHZ */
/* RCAP2L = 0Xcf; */       /* 19200 at 30 MHZ */
/* RCAP2L = 0Xe8; */       /* 38400 at 30 MHZ */
/* RCAP2L = 0Xf0; */       /* 57600 at 30 MHZ */
   PS = 1;              /* High priority interrupt */
   ES = 1;              /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void uart_isr(void) interrupt 4 using 2
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#pragma AREGS
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TMOD |= 0x01;        /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also.
   */
#if (1)
/* TH0 = 0x51;          */ /* timer 0 count for 10 milliseconds at 25 mhz */
/* TL0 = 0x61; */
/* TH0 = 0xF6;          */ /* timer 0 count for 1  milliseconds at 30 mhz */
/* TL0 = 0x3C; */
   TH0 = 0x9E;          /* timer 0 count for 10 milliseconds at 30 mhz */
   TL0 = 0x58;
#else
   TH0 = 0xDC;          /* load timer 0 counter with count for 10
                        milliseconds at 11.059 mhz */
   TL0 = 0x00;
#endif
   TR0 = 1;          /* set the timer 0 run bits */
   ET0 = 1;          /* enable timer  0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
#if (1)
/* TH0 = 0x51;          */ /* timer 0 count for 10 milliseconds at 25 mhz */
/* TL0 = 0x61; */
/* TH0 = 0xF6;          */ /* timer 0 count for 1  milliseconds at 30 mhz */
/* TL0 = 0x3C; */
   TH0 = 0x9E;          /* timer 0 count for 10 milliseconds at 30 mhz */
   TL0 = 0x58;
#else
   TH0 = 0xDC;          /* load timer 0 counter */
   TL0 = 0x00;
#endif
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#pragma AREGS
#endif      /* defined(__C51__) */
#endif      /* #if (defined(POLTRI51) || defined(CMXTRI51)) */

#if (defined(POLTRI51_16) || defined(CMXTRI51_16) || defined(POLTRI51_DMA) || \
   defined(CMXTRI51_DMA) || defined(POLTRI51_SMSC) || defined(CMXTRI51_SMSC))
/* Triscend 8051 16-bit ethernet driver */
#if defined(__C51__)    /* Keil 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   SCON = 0X50;         /* 8 bits, no parity */
   T2CON = 0X34;  
/* RCAP2H = 0XFE; */    /* 1200 at 11.059 MHZ */
/* RCAP2L = 0XE0; */    /* 1200 at 11.059 MHZ */
   RCAP2H = 0XFF;
/* RCAP2L = 0XDC; */       /* 9600 at 11.059 MHZ */
/* RCAP2L = 0XEE; */       /* 19200 at 11.059 MHZ */
/* RCAP2L = 0XAE; */       /* 9600 at 25 MHZ */
/* RCAP2L = 0XD7; */       /* 19200 at 25 MHZ */
/* RCAP2L = 0XF2; */       /* 57600 at 25 MHZ */
/* RCAP2L = 0X9e; */       /* 9600 at 30 MHZ */
/* RCAP2L = 0Xcf; */       /* 19200 at 30 MHZ */
 RCAP2L = 0Xe8;        /* 38400 at 30 MHZ */
/* RCAP2L = 0Xf0; */       /* 57600 at 30 MHZ */
   PS = 1;              /* High priority interrupt */
   ES = 1;              /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void uart_isr(void) interrupt 4 using 2
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#pragma AREGS
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TR0 = 0;
   TMOD |= 0x01;        /* set the timer 0 to mode 1 (16 bit counter) */
   CKCON &= 0x0F7;      /* Timer 0 clock source is (BusClock / 12) (CKCON.3) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also.
   */
#if (1)
/* TH0 = 0x51;          */ /* timer 0 count for 10 milliseconds at 25 mhz */
/* TL0 = 0x61; */
/* TH0 = 0xF6;          */ /* timer 0 count for 1  milliseconds at 30 mhz */
/* TL0 = 0x3C; */
   TH0 = 0x9E;          /* timer 0 count for 10 milliseconds at 30 mhz */
   TL0 = 0x58;
#else
   TH0 = 0xDC;          /* load timer 0 counter with count for 10
                        milliseconds at 11.059 mhz */
   TL0 = 0x00;
#endif
   TR0 = 1;          /* set the timer 0 run bits */
   ET0 = 1;          /* enable timer  0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
#if (1)
/* TH0 = 0xF6;          */ /* timer 0 count for 1  milliseconds at 30 mhz */
/* TL0 = 0x3C; */
   TH0 = 0x9E;          /* timer 0 count for 10 milliseconds at 30 mhz */
   TL0 = 0x58;
#else
   TH0 = 0xDC;          /* load timer 0 counter */
   TL0 = 0x00;
#endif
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#pragma AREGS
#endif      /* defined(__C51__) */
#endif      /* #if (defined(POLTRI51_16) || defined(CMXTRI51_16)) */

#if (defined(POLPHY51) || defined(CMXPHY51))
#if defined(__C51__)    /* Keil 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   S0CON = 0x50;        /* 8 bits, no parity */
   PCON |= 0x80;        /* double baud rate */

   S0PSH = 0X8F;  
   S0PSL = 0XB2;        /* 9600 at 12.0000 MHZ */
/* S0PSL = 0XD9;        */ /* 19200 at 12.0000 MHZ */
/* S0PSL = 0XE6;        */ /* 28800 at 12.0000 MHZ */
/* S0PSL = 0XF3;        */ /* 57600 at 12.0000 MHZ */

   PS0 = 1;             /* High priority interrupt */
   IP0H |= 0x10;
   ES0 = 1;             /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void uart_isr(void) interrupt 4 using 2
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)S0BUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         S0BUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#pragma AREGS
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TR0 = 0;
   TMOD |= 0x01;           /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also.
   */
   TH0 = 0xB1;          /* load timer 0 counter with count for 10
                        milliseconds at 12.000 mhz */
   TL0 = 0xDF;
   ET0 = 1;
   TR0 = 1;          /* set the timer 0 run bits */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0xB1;
   TL0 = 0xDF;
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#pragma AREGS
#endif      /* defined(__C51__) */

#if defined(_CC51)      /* Tasking 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   S0CON = 0x50;        /* 8 bits, no parity */
   PCON |= 0x80;        /* double baud rate */

   S0PSH = 0X8F;  
   S0PSL = 0XB2;        /* 9600 at 12.0000 MHZ */
/* S0PSL = 0XD9;        */ /* 19200 at 12.0000 MHZ */
/* S0PSL = 0XE6;        */ /* 28800 at 12.0000 MHZ */
/* S0PSL = 0XF3;        */ /* 57600 at 12.0000 MHZ */

   PS0 = 1;             /* High priority interrupt */
   IP0H |= 0x10;
   ES0 = 1;             /* enable serial interrupts */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(4) _using(2) void uart_isr(void)
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   TR0 = 0;
   TMOD |= 0x01;           /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also.
   */
   TH0 = 0xB1;          /* load timer 0 counter with count for 10
                        milliseconds at 12.000 mhz */
   TL0 = 0xDF;
   ET0 = 1;
   TR0 = 1;          /* set the timer 0 run bits */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(1) _using(1) void tcp_timer(void)
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0xB1;
   TL0 = 0xDF;
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#endif      /* defined(_CC51) */
#endif      /* #if (defined(POLPHY51) || defined(CMXPHY51)) */

#if (defined(POLRCH51) || defined(CMXRCH51))
#if defined(__C51__)    /* Keil 8051 */
#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */
   /* do the rest later when we need it */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void uart_isr(void) interrupt 4 using 2
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c;

   if (RI)
      {
      RI = 0;
      c = (byte)SBUF;
      if (recv_count < (RECV_BUFF_SIZE-1))
         {
         *recv_in_ptr = c;
         ++recv_count;
         ++recv_in_ptr;
         if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   else if (TI)
      {
      TI = 0;
      if (send_out_ptr != send_in_ptr)
         {
         SBUF = *send_out_ptr;
#if (LOG_OUTPUT)
         Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
         }
      else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
      }
}
#pragma AREGS
#endif      /* (PPP || SLIP) */

void mn_timer_init(void)
cmx_reentrant {
   /* we use 12.0 Mhz because that is what our emulator is using. if running
      off the board's clock, change below for 24.0 Mhz.
   */
   DISABLE_INTERRUPTS;
   TR0 = 0;
   TMOD |= 0x01;           /* set the timer 0 to mode 1 (16 bit counter) */
   /* if the TH0 and TL0 values are changed here, change them in tcp_timer
      also.
   */
   TH0 = 0xD8;          /* load timer 0 counter with count for 10
                        milliseconds at 12.000 mhz */
   TL0 = 0xF0;

   /* values for 24 Mhz with divide by 12 clock */
/*   TH0 = 0xB1; */        /* load timer 0 counter with count for 10
                            milliseconds at 24.000 mhz */
/*   TL0 = 0xE0; */

   ET0 = 1;
   TR0 = 1;          /* set the timer 0 run bits */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#pragma NOAREGS
#if (RTOS_USED == RTOS_NONE)
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0xD8;
   TL0 = 0xF0;
   TR0 = 1;
   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
}
#endif      /* defined(__C51__) */
#endif      /* (defined(POLRCH51) || defined(CMXRCH51)) */

#if (defined(POLC8051F124) || defined(CMXC8051F124))

#define SYSCLK       49000000        /* SYSCLK frequency in Hz */
#define BAUDRATE     38400

#if defined(__C51__)    /* Keil 8051 */

void start_xmit(void);

void SYSCLK_Init (void);
void PORT_Init (void);
void EMIF_Init (void);

#if (PPP || SLIP)
void mn_uart_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */

#error Need to do mn_uart_init

   ENABLE_INTERRUPTS;
}

void start_xmit(void)
{
   if (send_out_ptr != send_in_ptr)
      {
      DISABLE_INTERRUPTS;
      MN_XMIT_BUSY_SET;

#error Need to do start_xmit

      ENABLE_INTERRUPTS;
      }
}

#pragma NOAREGS
#error Need UART ISR
#pragma AREGS

#endif      /* (PPP || SLIP) */

//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use the internal oscillator
// at 24.5 MHz multiplied by two using the PLL.
//
void SYSCLK_Init (void)
{
   int i;                           // software timer

   char SFRPAGE_SAVE = SFRPAGE;     // Save Current SFR page

   SFRPAGE = CONFIG_PAGE;           // set SFR page

   OSCICN = 0x83;                   // set internal oscillator to run
                                    // at its maximum frequency

   CLKSEL = 0x00;                   // Select the internal osc. as
                                    // the SYSCLK source
   
   //Turn on the PLL and increase the system clock by a factor of M/N = 2 or 4
   
   PLL0CN  = 0x00;                  // Set internal osc. as PLL source
   SFRPAGE = LEGACY_PAGE;
   FLSCL   = 0x10;                  // Set FLASH read time for 50MHz clk
   SFRPAGE = CONFIG_PAGE;

   PLL0CN |= 0x01;                  // Enable Power to PLL
   PLL0DIV = 0x01;                  // Set Pre-divide value to N (N = 1)
   PLL0FLT = 0x01;                  // Set the PLL filter register for 
                                    // a reference clock from 19 - 30 MHz
                                    // and an output clock from 45 - 80 MHz 
   PLL0MUL = 0x02;                  // Multiply SYSCLK by M (M = 2)
   
   for (i=0; i < 256; i++) ;        // Wait at least 5us
   PLL0CN  |= 0x02;                 // Enable the PLL
   while(!(PLL0CN & 0x10));         // Wait until PLL frequency is locked
   CLKSEL  = 0x02;                  // Select PLL as SYSCLK source

   SFRPAGE = SFRPAGE_SAVE;          // Restore SFR page
}

//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
   char SFRPAGE_SAVE = SFRPAGE;     // Save Current SFR page
   
   SFRPAGE = CONFIG_PAGE;           // set SFR page

   XBR0     = 0x00;                 
   XBR1     = 0x00;                 // Enable SYSCLK on P0.2
   XBR2     = 0x44;                 // Enable crossbar, weak pull-ups,
                                    // and UART1

   P0MDOUT |= 0x01;                 // Set TX1 pin to push-pull
   P1MDOUT |= 0x40;					   // Set P1.6(LED) to push-pull   
   
   // all pins used by the external memory interface are in push-pull mode 
   P4MDOUT =  0xFF; 
   P5MDOUT =  0xFF;
   P6MDOUT =  0xFF;
   P7MDOUT =  0xFF;                 
   P4 = 0xC0;                       // /WR, /RD, are high, RESET is low
   P5 = 0x00;  
   P6 = 0x00;                       // P5, P6 contain the address lines
   P7 = 0xFF;                       // P7 contains the data lines
   
   SFRPAGE = SFRPAGE_SAVE;          // Restore SFR page
   
}

//-----------------------------------------------------------------------------
// EMIF_Init
//-----------------------------------------------------------------------------
//
// Configure the External Memory Interface for both on and off-chip access.
//
void EMIF_Init (void)
{
   
   char SFRPAGE_SAVE = SFRPAGE;     // Save Current SFR page
   
   SFRPAGE = LEGACY_PAGE;
   
   EMI0CF = 0xF7;                   // Split-mode, non-multiplexed
                                    // on P4 - P7

   EMI0TC = 0xB7;					      // This constant may be modified 
                                    // according to SYSCLK to meet the 
                                    // timing requirements for the CS8900A
                                    // For example, EMI0TC should be >= 0xB7 
                                    // for a 100 MHz SYSCLK.
   SFRPAGE = SFRPAGE_SAVE;          // Restore SFR page
}

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   SFRPAGE = LEGACY_PAGE;
   TCON  &= (byte)(~0x30);       /* STOP Timer0 and clear overflow flag */
   TMOD  &= 0xf0;                /* configure Timer0 to 16-bit mode */
   TMOD |= 0x01;              /* set the timer 0 to mode 1 (16 bit counter) */
   CKCON &= 0x0F0;               /* Timer 0 clock source is (SysClock / 12) */
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms @ 49 MHz */
   TL0 = 0x7F;
   TR0 = 1;                      /* set the timer 0 run bits */
   ET0 = 1;                      /* enable timer 0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
#pragma NOAREGS
void tcp_timer(void) interrupt 1 using 1
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms @ 49 MHz */
   TL0 = 0x7F;
   TR0 = 1;

   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#pragma AREGS
#endif      /* defined(__C51__) */

#if defined(__ICC8051__)    /* IAR 8051 */

void SYSCLK_Init (void);
void PORT_Init (void);
void EMIF_Init (void);

#if (PPP || SLIP)
void start_xmit(void);

void mn_uart_init(void)
cmx_reentrant {
   char SFRPAGE_SAVE;

   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */

   SFRPAGE_SAVE = SFRPAGE;          /* Save Current SFR page */
   
   SFRPAGE = UART1_PAGE;

   SCON1  = 0x50;                   /* SCON0: mode 0, 8-bit UART, enable RX */

   SFRPAGE = TIMER01_PAGE;
   TMOD   &= ~0xF0;                  
   TMOD   |=  0x20;                 /* TMOD: timer 1, mode 2, 8-bit reload */
   
   if (SYSCLK/BAUDRATE/2/256 < 1) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2));
      CKCON |= 0x10;                // T1M = 1; SCA1:0 = xx
   } else if (SYSCLK/BAUDRATE/2/256 < 4) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/4));
      CKCON &= ~0x13;               // Clear all T1 related bits
      CKCON |=  0x01;               // T1M = 0; SCA1:0 = 01
   } else if (SYSCLK/BAUDRATE/2/256 < 12) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/12));
      CKCON &= ~0x13;               // T1M = 0; SCA1:0 = 00
   } else {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/48));
      CKCON &= ~0x13;               // Clear all T1 related bits
      CKCON |=  0x02;               // T1M = 0; SCA1:0 = 10
   }   

   TL1 = TH1;                       /* initialize Timer1 */
   TCON_bit.TR1 = 1;                /* start Timer1   */

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */

   EIP2 |= 0x40;                    /* UART1 is high priority interrupt */
   EIE2 |= 0x40;                    /* enable UART1 interrupts */

   ENABLE_INTERRUPTS;
}

void start_xmit(void)
{
   char SFRPAGE_SAVE;

   if (send_out_ptr != send_in_ptr)
      {
      DISABLE_INTERRUPTS;
      MN_XMIT_BUSY_SET;
      SFRPAGE_SAVE = SFRPAGE;          /* Save Current SFR page */
      SFRPAGE = UART1_PAGE;
      SCON1_bit.TI0 = 1;
      SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
      ENABLE_INTERRUPTS;
      }
}

#if (RTOS_USED == RTOS_NONE)
#pragma vector=0xA3
#pragma register_bank=2
__interrupt void uart_isr(void)
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c, status;
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */

   SFRPAGE = UART1_PAGE;

   status = SCON1;

	if (status & 0x01)         /* RI1 bit set? */
		{
      SCON1_bit.RI0 = 0;
      c = (byte)SBUF1;
		if (recv_count <= RECV_BUFF_SIZE)
			{
			*recv_in_ptr = c;
			++recv_count;
			++recv_in_ptr;
			if (recv_in_ptr >= &recv_buff[RECV_BUFF_SIZE])
				recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
			}
		}

   if (status & 0x02)    /* TI1 bit set? */
		{
		SCON1_bit.TI0 = 0;
		if (send_out_ptr != send_in_ptr)
			{
			SBUF1 = *send_out_ptr;
#if (LOG_OUTPUT)
			Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
			}
		else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
		}

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

#endif      /* (PPP || SLIP) */

/*----------------------------------------------------------------------------- */
/* SYSCLK_Init */
/*----------------------------------------------------------------------------- */
/* This routine initializes the system clock to use the internal oscillator */
/* at 24.5 MHz multiplied by two using the PLL. */
void SYSCLK_Init (void)
{
   int i;                           /* software timer */

   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */

   SFRPAGE = CONFIG_PAGE;           /* set SFR page */

   OSCICN = 0x83;                   /* set internal oscillator to run */
                                    /* at its maximum frequency */

   CLKSEL = 0x00;                   /* Select the internal osc. as */
                                    /* the SYSCLK source */
   
   /*Turn on the PLL and increase the system clock by a factor of M/N = 2 */
   SFRPAGE = CONFIG_PAGE;
   
   PLL0CN  = 0x00;                  /* Set internal osc. as PLL source */
   SFRPAGE = LEGACY_PAGE;
   FLSCL   = 0x10;                  /* Set FLASH read time for 50MHz clk */
                                    /* or less */
   SFRPAGE = CONFIG_PAGE;
   PLL0CN |= 0x01;                  /* Enable Power to PLL */
   PLL0DIV = 0x01;                  /* Set Pre-divide value to N (N = 1) */
   PLL0FLT = 0x01;                  /* Set the PLL filter register for  */
                                    /* a reference clock from 19 - 30 MHz */
                                    /* and an output clock from 45 - 80 MHz  */
   PLL0MUL = 0x02;                  /* Multiply SYSCLK by M (M = 2) */
   
   for (i=0; i <256; i++)          /* Wait at least 5us */
      __no_operation();
   PLL0CN  |= 0x02;                 /* Enable the PLL */
   while(!(PLL0CN & 0x10));         /* Wait until PLL frequency is locked */
   CLKSEL  = 0x02;                  /* Select PLL as SYSCLK source */

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

/*----------------------------------------------------------------------------- */
/* PORT_Init */
/*----------------------------------------------------------------------------- */
/* Configure the Crossbar and GPIO ports */
void PORT_Init (void)
{
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */
   
   SFRPAGE = CONFIG_PAGE;           /* set SFR page */

   XBR0     = 0x00;                 
   XBR1     = 0x00;                 /* Enable SYSCLK on P0.2 */
   XBR2     = 0x44;                 /* Enable crossbar, weak pull-ups, */
                                    /* and UART1 */

   P0MDOUT |= 0x01;                 /* Set TX1 pin to push-pull */
   P1MDOUT |= 0x40;					   /* Set P1.6(LED) to push-pull */
   
   /* all pins used by the external memory interface are in push-pull mode  */
   P4MDOUT =  0xFF; 
   P5MDOUT =  0xFF;
   P6MDOUT =  0xFF;
   P7MDOUT =  0xFF;                 
   P4 = 0xC0;                       /* /WR, /RD, are high, RESET is low */
   P5 = 0x00;  
   P6 = 0x00;                       /* P5, P6 contain the address lines */
   P7 = 0xFF;                       /* P7 contains the data lines */
   
   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
   
}

/*----------------------------------------------------------------------------- */
/* EMIF_Init */
/*----------------------------------------------------------------------------- */
/* Configure the External Memory Interface for both on and off-chip access. */
void EMIF_Init (void)
{
   
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */
   
   SFRPAGE = LEGACY_PAGE;
   
   EMI0CF = 0xF7;                   /* Split-mode, non-multiplexed */
                                    /* on P4 - P7 */

   EMI0TC = 0xB7;					      /* This constant may be modified  */
                                    /* according to SYSCLK to meet the  */
                                    /* timing requirements for the CS8900A */
                                    /* For example, EMI0TC should be >= 0xB7  */
                                    /* for a 100 MHz SYSCLK. */
   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   SFRPAGE = LEGACY_PAGE;
   TCON  &= (byte)(~0x30);       /* STOP Timer0 and clear overflow flag */
   TMOD  &= 0xf0;                /* configure Timer0 to 16-bit mode */
   TMOD |= 0x01;              /* set the timer 0 to mode 1 (16 bit counter) */
   CKCON &= 0x0F0;               /* Timer 0 clock source is (SysClock / 12) */
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms @ 49 MHz */
   TL0 = 0x7F;
   TCON_bit.TR0 = 1;             /* set the timer 0 run bits */
   IE_bit.ET0 = 1;               /* enable timer 0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
#pragma vector=0x0B
#pragma register_bank=1
__interrupt void tcp_timer(void)
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TCON_bit.TR0 = 0;
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms @ 49 MHz */
   TL0 = 0x7F;
   TCON_bit.TR0 = 1;

   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#endif      /* defined(__ICC8051__) */

#if defined(_CC51)      /* Tasking 8051 */
void SYSCLK_Init (void);
void PORT_Init (void);
void EMIF_Init (void);

#if (PPP || SLIP)
void start_xmit(void);

void mn_uart_init(void)
cmx_reentrant {
   char SFRPAGE_SAVE;

   DISABLE_INTERRUPTS;
   init_io_buffs();           /* do not remove this function call */

   SFRPAGE_SAVE = SFRPAGE;          /* Save Current SFR page */
   
   SFRPAGE = UART1_PAGE;

   SCON1  = 0x50;                   /* SCON0: mode 0, 8-bit UART, enable RX */

   SFRPAGE = TIMER01_PAGE;
   TMOD   &= ~0xF0;                  
   TMOD   |=  0x20;                 /* TMOD: timer 1, mode 2, 8-bit reload */
   
   if (SYSCLK/BAUDRATE/2/256 < 1) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2));
      CKCON |= 0x10;                // T1M = 1; SCA1:0 = xx
   } else if (SYSCLK/BAUDRATE/2/256 < 4) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/4));
      CKCON &= ~0x13;               // Clear all T1 related bits
      CKCON |=  0x01;               // T1M = 0; SCA1:0 = 01
   } else if (SYSCLK/BAUDRATE/2/256 < 12) {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/12));
      CKCON &= ~0x13;               // T1M = 0; SCA1:0 = 00
   } else {
      TH1 = (byte)(-(SYSCLK/BAUDRATE/2/48));
      CKCON &= ~0x13;               // Clear all T1 related bits
      CKCON |=  0x02;               // T1M = 0; SCA1:0 = 10
   }   

   TL1 = TH1;                       /* initialize Timer1 */
   TR1 = 1;                         /* start Timer1   */

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */

   EIP2 |= 0x40;                    /* UART1 is high priority interrupt */
   EIE2 |= 0x40;                    /* enable UART1 interrupts */

   ENABLE_INTERRUPTS;
}

void start_xmit(void)
{
   char SFRPAGE_SAVE;

   if (send_out_ptr != send_in_ptr)
      {
      DISABLE_INTERRUPTS;
      MN_XMIT_BUSY_SET;
      SFRPAGE_SAVE = SFRPAGE;          /* Save Current SFR page */
      SFRPAGE = UART1_PAGE;
      TI0 = 1;
      SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
      ENABLE_INTERRUPTS;
      }
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(20) _using(2) void uart_isr(void)
#else
void uart_isr(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   byte c, status;
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */

   SFRPAGE = UART1_PAGE;

   status = SCON1;

	if (status & 0x01)         /* RI1 bit set? */
		{
      RI0 = 0;
      c = (byte)SBUF1;
		if (recv_count <= RECV_BUFF_SIZE)
			{
			*recv_in_ptr = c;
			++recv_count;
			++recv_in_ptr;
			if (recv_in_ptr >= &recv_buff[RECV_BUFF_SIZE])
				recv_in_ptr = &recv_buff[0];
#if (RTOS_USED != RTOS_NONE)
         SEND_RECEIVE_SIGNAL(c);
#endif      /* (RTOS_USED != RTOS_NONE) */
			}
		}

   if (status & 0x02)    /* TI1 bit set? */
		{
		TI0 = 0;
		if (send_out_ptr != send_in_ptr)
			{
			SBUF1 = *send_out_ptr;
#if (LOG_OUTPUT)
			Nputchr(*send_out_ptr);
#endif
         ++send_out_ptr;
			}
		else
         {
         MN_XMIT_BUSY_CLEAR;
         MN_ISR_SIGNAL_POST(SIGNAL_TRANSMIT);
         }
		}

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

#endif      /* (PPP || SLIP) */

/*----------------------------------------------------------------------------- */
/* SYSCLK_Init */
/*----------------------------------------------------------------------------- */
/* This routine initializes the system clock to use the internal oscillator */
/* at 24.5 MHz multiplied by two using the PLL. */
void SYSCLK_Init (void)
{
   int i;                           /* software timer */

   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */

   SFRPAGE = CONFIG_PAGE;           /* set SFR page */

   OSCICN = 0x83;                   /* set internal oscillator to run */
                                    /* at its maximum frequency */

   CLKSEL = 0x00;                   /* Select the internal osc. as */
                                    /* the SYSCLK source */
   
   /*Turn on the PLL and increase the system clock by a factor of M/N = 2 */
   SFRPAGE = CONFIG_PAGE;
   
   PLL0CN  = 0x00;                  /* Set internal osc. as PLL source */
   SFRPAGE = LEGACY_PAGE;
   FLSCL   = 0x10;                  /* Set FLASH read time for 50MHz clk */
                                    /* or less */
   SFRPAGE = CONFIG_PAGE;
   PLL0CN |= 0x01;                  /* Enable Power to PLL */
   PLL0DIV = 0x01;                  /* Set Pre-divide value to N (N = 1) */
   PLL0FLT = 0x01;                  /* Set the PLL filter register for  */
                                    /* a reference clock from 19 - 30 MHz */
                                    /* and an output clock from 45 - 80 MHz  */
   PLL0MUL = 0x02;                  /* Multiply SYSCLK by M (M = 2) */
   
   for (i=0; i < 256; i++) ;        /* Wait at least 5us */
   PLL0CN  |= 0x02;                 /* Enable the PLL */
   while(!(PLL0CN & 0x10));         /* Wait until PLL frequency is locked */
   CLKSEL  = 0x02;                  /* Select PLL as SYSCLK source */

   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

/*----------------------------------------------------------------------------- */
/* PORT_Init */
/*----------------------------------------------------------------------------- */
/* Configure the Crossbar and GPIO ports */
void PORT_Init (void)
{
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */
   
   SFRPAGE = CONFIG_PAGE;           /* set SFR page */

   XBR0     = 0x00;                 
   XBR1     = 0x00;                 /* Enable SYSCLK on P0.2 */
   XBR2     = 0x44;                 /* Enable crossbar, weak pull-ups, */
                                    /* and UART1 */

   P0MDOUT |= 0x01;                 /* Set TX1 pin to push-pull */
   P1MDOUT |= 0x40;					   /* Set P1.6(LED) to push-pull */
   
   /* all pins used by the external memory interface are in push-pull mode  */
   P4MDOUT =  0xFF; 
   P5MDOUT =  0xFF;
   P6MDOUT =  0xFF;
   P7MDOUT =  0xFF;                 
   P4 = 0xC0;                       /* /WR, /RD, are high, RESET is low */
   P5 = 0x00;  
   P6 = 0x00;                       /* P5, P6 contain the address lines */
   P7 = 0xFF;                       /* P7 contains the data lines */
   
   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
   
}

/*----------------------------------------------------------------------------- */
/* EMIF_Init */
/*----------------------------------------------------------------------------- */
/* Configure the External Memory Interface for both on and off-chip access. */
void EMIF_Init (void)
{
   
   char SFRPAGE_SAVE = SFRPAGE;     /* Save Current SFR page */
   
   SFRPAGE = LEGACY_PAGE;
   
   EMI0CF = 0xF7;                   /* Split-mode, non-multiplexed */
                                    /* on P4 - P7 */

   EMI0TC = 0xB7;					      /* This constant may be modified  */
                                    /* according to SYSCLK to meet the  */
                                    /* timing requirements for the CS8900A */
                                    /* For example, EMI0TC should be >= 0xB7  */
                                    /* for a 100 MHz SYSCLK. */
   SFRPAGE = SFRPAGE_SAVE;          /* Restore SFR page */
}

void mn_timer_init(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   SFRPAGE = LEGACY_PAGE;
   TCON  &= (byte)(~0x30);       /* STOP Timer0 and clear overflow flag */
   TMOD  &= 0xf0;                /* configure Timer0 to 16-bit mode */
   TMOD |= 0x01;              /* set the timer 0 to mode 1 (16 bit counter) */
   CKCON &= 0x0F0;               /* Timer 0 clock source is (SysClock / 12) */
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms at 49 MHz */
   TL0 = 0x7F;
   TR0 = 1;                      /* set the timer 0 run bits */
   ET0 = 1;                      /* enable timer 0 interrupt */
#if (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP)
   timer_tick = 0;
#endif      /* (RTOS_USED == RTOS_NONE || RTOS_USED == RTOS_CMX_TINYP) */
   ENABLE_INTERRUPTS;
}

#if (RTOS_USED == RTOS_NONE)
_interrupt(1) _using(1) void tcp_timer(void)
#else
void tcp_timer(void) cmx_reentrant
#endif      /* (RTOS_USED == RTOS_NONE) */
{
   TR0 = 0;
   TH0 = 0x60;                   /* set Timer0 to overflow in 10ms at 49 MHz */
   TL0 = 0x7F;
   TR0 = 1;

   MN_TICK_UPDATE;
#if (RTOS_USED == RTOS_NONE)
#if DHCP
   mn_dhcp_update_timer();
#endif      /* DHCP */
#if (ARP && ARP_TIMEOUT)
   mn_arp_update_timer();
#endif      /* (ARP && ARP_TIMEOUT) */
#if (IGMP)
   mn_igmp_update_timers();
#endif      /* (IGMP) */
#if (SOCKET_INACTIVITY_TIME)
   mn_update_inactivity_timers();
#endif      /* (SOCKET_INACTIVITY_TIME) */
#else    /* RTOS used */
#if (DHCP || (ARP && ARP_TIMEOUT))
   MN_ISR_SIGNAL_POST(SIGNAL_TIMER_UPDATE);
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (IGMP)
   MN_ISR_SIGNAL_POST(SIGNAL_IGMP);
#endif      /* (IGMP) */
#endif      /* (RTOS_USED == RTOS_NONE) */
}
#endif      /* defined(_CC51) */
#endif      /* (defined(POLC8051F124) || defined(CMXC8051F124)) */

