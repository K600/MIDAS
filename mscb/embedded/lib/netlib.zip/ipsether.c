/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/
/* driver for CS8900A chip in 8-bit IO-mode */
/* modified 12/11/00 for new IPS definitions */

/* defines for mn_env.h and ipsether.h */
#define CMX_ETHER       1
#define PROTOTYPE_ONLY  1

#include "micronet.h"

/*
   Porting Notes:

   1. Make sure that mnconfig.h is set for POLLED_ETHERNET. The cs8900
      in 8-bit mode does not support interrupts.

   2. Make sure the ETHER_POLL_RECV, ETHER_INIT and ETHER_SEND(p,n) in
      ethernet.h are defined properly.

      #define ETHER_POLL_RECV       cs8900_recv()
      #define ETHER_INIT            cs8900_init()
      #define ETHER_SEND(p,n)       cs8900_send(p,n)

   3. Set the macro iPS_ETH8_100_RDWR below to point to the base address
      for the chip. The Reichmann board has a base address of 0x0000, but
      this will be different for other hardware.

   4. Check the readWord16 and writeWord16 macros and the readPacketPage16
      and writePacketPage16 functions to make sure they work correctly
      on your setup.      

   5. Add code at the start of cs8900_init to do a hardware reset.

*/

#if (ETHERNET)

#if (!POLLED_ETHERNET)
#error Only polled ethernet is supported for this driver.
#endif      /* (!POLLED_ETHERNET) */

#if (!(USE_RECV_BUFF))
#error USE_RECV_BUFF must be set to 1 for this driver.
#endif      /* (!(USE_RECV_BUFF)) */

#define DO_DEBUG        0

#if (defined(POLTRI51) || defined(CMXTRI51))
/* Triscend 8051 */
/* The header file automatically created by FastChip */
#include "ipsether.h"
#elif (defined(POLRCH51) || defined(CMXRCH51))
/* setup for Reichmann 8051 board */
#define iPS_ETH8_100_RDWR     ((volatile unsigned char xdata *)0x00)
#elif (defined(POLAVRE) || defined(CMXAVRE))
/* Change the define below according to where your board is mapped.
   Note: this driver assumes that odd and even bytes are contiguous. If
   your hardware is setup so that odd bytes are at an offset from the even
   bytes the code below will need modification.
*/
#define iPS_ETH8_100_RDWR     ((volatile unsigned char *)0x4800)
#undef DO_DEBUG
#define DO_DEBUG        0     /* set to 1 to send debug info to UART */
#if DO_DEBUG
#include <stdio.h>            
#include <pgmspace.h>
#include "support.h"
char Str[25];
void DiagSend(char *Str) cmx_reentrant;
flash char str1[] = "No 3000h\r\n";
flash char str2[] = "No 630Eh\r\n";
flash char str3[] = "No 0300h\r\n";
flash char str4[] = "Write Failed\r\n";
flash char str5[] = "Init Ok\r\n";
flash char str6[] = "No Recv\r\n";
flash char str7[] = "No Room\r\n";
flash char str8[] = "Recv OK\r\n";
#endif      /* DO_DEBUG */

#elif (defined(POLC8051F124) || defined(CMXC8051F124))
/* Cygnal C8051F124 */
#if (defined(__C51__))     /* Keil 8051 */
#define iPS_ETH8_100_RDWR ((volatile unsigned char xdata *)0xC000)
#elif (defined(__ICC8051__))           /* IAR 8051 */
#define iPS_ETH8_100_RDWR ((volatile unsigned char __xdata *)0xC000)
#elif (defined(_CC51))     /* Tasking 8051 */
#define iPS_ETH8_100_RDWR ((volatile unsigned char *)0xC000)
#endif

#endif      /* (defined(POLTRI51) || defined(CMXTRI51)) */

#if (!DO_DEBUG)
static void dummy(word16) cmx_reentrant;
#endif      /* !DO_DEBUG */


/* CS8900 definitions */
#include "cs8900a.h"

/* Local Prototypes */
#if (!(defined(POLTRI51) || defined(CMXTRI51)))
static void cs8900_reset(void) cmx_reentrant;
#endif      /* (!(defined(POLTRI51) || defined(CMXTRI51))) */

static word16 readPacketPage16(word16 PPadd) cmx_reentrant;
static void writePacketPage16(word16 PPadd, word16 PPdata) cmx_reentrant;

#define writeWord16(Padd,Pdata) {iPS_ETH8_100_RDWR[(Padd)] = (Pdata) & 0x00ff; \
   iPS_ETH8_100_RDWR[(Padd)+1] = ((Pdata) >> 8) & 0x00ff;}
#define readWord16(Padd) (((word16)iPS_ETH8_100_RDWR[(Padd)+1] << 8) + iPS_ETH8_100_RDWR[(Padd)])

#if (ALLOW_MULTICAST)
#define RX_SETTING   (CS_RX_OK_A|CS_PROMISCUOUS_A|CS_BROADCAST_A)
#else
#define RX_SETTING   (CS_RX_OK_A|CS_INDIVIDUAL_A|CS_BROADCAST_A)
#endif

/**************************************************************** */
/* functions */
/**************************************************************** */

/* initialization. returns 1 if ok or negative number on error. */
int cs8900_init(void)
cmx_reentrant {

#if (defined(POLTRI51) || defined(CMXTRI51))
   /* Initialize C8900A */
   iPS_ETH8_100_ENRSET = 0;  /*reset CS8900A chip */
   MN_TASK_WAIT(ONE_SECOND);
#elif (defined(POLAVRE) || defined(CMXAVRE))
   PORTB &= 0xdf;       /* CS8900Run */
   MN_TASK_WAIT(ONE_SECOND);
#elif (defined(POLC8051F124) || defined(CMXC8051F124))
   MN_TASK_WAIT(ONE_SECOND);
#endif      /* (defined(POLTRI51) || defined(CMXTRI51)) */

   /* Check for presence of CS8900A by reading 3000h
      from the PacketPage pointer.
   */
   if (readWord16(PP_POINTER_PORT) != CS8900A_SIG)
      {
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
      strcpy_P(Str,str1);
      DiagSend(Str);
#endif
      return ETHER_INIT_ERROR;
      }

   /* Check for EISA number to be 0x630E */
   if (readPacketPage16(PP_ProductID) != EISA_REG_NUM) 
      {
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
      strcpy_P(Str,str2);
      DiagSend(Str);
#endif
      return ETHER_INIT_ERROR;
      }

   /* Check for Base I/O address to be 300h */
   if (readPacketPage16(PP_IOBaseAddr) != DEFAULT_BASE) 
      {
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
      strcpy_P(Str,str3);
      DiagSend(Str);
#endif
      return ETHER_INIT_ERROR;
      }

#if (defined(POLTRI51) || defined(CMXTRI51))
   /* wait till reset is done */
   while (!(readPacketPage16(PP_SelfST) & CS_INITD))
      MN_TASK_WAIT((ONE_SECOND)/10);
#else
   cs8900_reset();
#endif      /* (defined(POLTRI51) || defined(CMXTRI51)) */

   /* If the code has gotten this far, then basic I/O is working between
      the processor and the CS8900A is working.
   */

   /* Set the Interrupt number to be 0 */
   writePacketPage16(PP_IntNum, 0);

   /* Verify that the PacketPage memory can be written to. */
   if ((readPacketPage16(PP_IntNum) & 0x000f) != 0)
      {
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
      strcpy_P(Str,str4);
      DiagSend(Str);
#endif
      return ETHER_INIT_ERROR;
      }

   /* setup for polled mode */
   writePacketPage16(PP_BufCFG, 0);
   writePacketPage16(PP_RxCFG, 0);                 /* No Rx interrupt */
   writePacketPage16(PP_RxCTL, RX_SETTING);
   writePacketPage16(PP_TxCFG, 0);                 /* No Tx interrupt */

   /* write the MAC address to Individual Address */
   /* Important: The IA needs to be byte reversed */
   writePacketPage16(PP_IndAddr, MK_WORD16(eth_src_hw_addr[1],eth_src_hw_addr[0]));
   writePacketPage16(PP_IndAddr2, MK_WORD16(eth_src_hw_addr[3],eth_src_hw_addr[2]));
   writePacketPage16(PP_IndAddr4, MK_WORD16(eth_src_hw_addr[5],eth_src_hw_addr[4]));

   writePacketPage16(PP_TestCTL, 0);      /* half Duplex */
   writePacketPage16(PP_BusCTL, 0);       /* No interrupts */

   /* enable receive and transmit, half duplex */
   writePacketPage16(PP_LineCTL, (CS_SER_RX_ON|CS_SER_TX_ON) );

#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
   strcpy_P(Str,str5);
   DiagSend(Str);
#endif
   return 1;
}


/* Transmit a frame in polled mode. The ethernet header must in the frame
   to be sent. Returns the number of bytes sent or negative number on error.
   The ethernet header and other header info is in the xmit_buff. The TCP
   or UDP data is pointed to by socket_ptr->send_ptr. xmit_sock_len is the
   number of data bytes to be sent in the current packet.
*/
int cs8900_send(PSOCKET_INFO socket_ptr, word16 xmit_sock_len)
cmx_reentrant {
   word16 i;
   unsigned long j;
   word16 xmit_buff_len;
   word16 total_len;
   int retval;
   byte oddLength;
   TIMER_INFO_T wait_timer;
   byte *MsgSendPointer;

   retval = 0;
   oddLength = FALSE;

   /* make sure there is something to send */
   if (send_out_ptr != send_in_ptr)
      {
      /* calculate the number of bytes to send */
      xmit_buff_len = send_in_ptr - send_out_ptr;
      if (xmit_sock_len && socket_ptr->send_ptr != PTR_NULL)
         {
         MsgSendPointer = socket_ptr->send_ptr;
         oddLength = (xmit_sock_len & 0x0001);
         }
      else if (xmit_buff_len & 0x0001)
         {
         /* xmit_buff_len should be an even # if socket_ptr->send_ptr != PTR_NULL,
            otherwise force it to be even.
         */
         mn_send_byte(0x00);
         xmit_buff_len++;
         }
   
      total_len = xmit_sock_len + xmit_buff_len;
      if (total_len > ETHER_SIZE)
         return (ETHER_SEND_ERROR);

      writeWord16(TX_CMD_PORT, CS_TX_START_ALL);   /* bid for frame storage */
      writeWord16(TX_LENGTH_PORT, total_len);         /* write the length */
   
      /* wait for TX ready */
      mn_reset_timer(&wait_timer,(ETHER_WAIT_TICKS));
      while (!mn_timer_expired(&wait_timer))
         {
         if (readPacketPage16(PP_BusST) & CS_RDY_4_TX_NOW)
            {
            retval = (int)total_len;
            break;
            }
         }
   
      if (!retval)
         {
         return (UNABLE_TO_SEND);
         }
   
      if ((readPacketPage16(PP_BusST) & CS_TX_BID_ERR))
         {
         return (ETHER_SEND_ERROR);
         }
   
      /* write the data */
      for (i=0;i<xmit_buff_len;i += 2)
         {
         iPS_ETH8_100_RDWR[XMIT_PORT] = *send_out_ptr;
         ++send_out_ptr;
         iPS_ETH8_100_RDWR[XMIT_PORT1] = *send_out_ptr;
         ++send_out_ptr;
         }

      if (oddLength)
         xmit_sock_len--;     /* need even count for the loop */
   
      /* write the data */
      for (i=0;i<xmit_sock_len;i += 2)
         {
         iPS_ETH8_100_RDWR[XMIT_PORT] = *MsgSendPointer++;
         iPS_ETH8_100_RDWR[XMIT_PORT1] = *MsgSendPointer++;
         }
   
      if (oddLength)
         {
         iPS_ETH8_100_RDWR[XMIT_PORT] = *MsgSendPointer;
         iPS_ETH8_100_RDWR[XMIT_PORT1] = (byte)'\0';
         }

#if (POLLED_ETHERNET)
      for (j=0 ; j<200000 ; j++) // ## SR added to avoid endless loop if no Ethernet connected
         {
         i = readPacketPage16(PP_TxEvent);
         if (i & CS_TX_ERROR)
            {
            retval = ETHER_SEND_ERROR;
            break;
            }
         else if (i & CS_TX_OK)
            break;
         }
#endif      /* (POLLED_ETHERNET) */
      }

   return (retval);
}

#if POLLED_ETHERNET
/* receives a frame in polled mode. returns number of bytes received if
   successful or negative number on error.
   Copies entire frame including ethernet header into the receive buffer.
*/
int cs8900_recv(void)
cmx_reentrant {
   volatile word16 recv_status;
   word16 recv_len, i;
   TIMER_INFO_T wait_timer;
   int retval;
   byte oddLength;
#if (defined(POLAVRE) || defined(CMXAVRE))
   byte temp_char;
#endif

   retval = 0;

   if (!(readPacketPage16(PP_RxEvent) & CS_RX_OK))
      {
      mn_reset_timer(&wait_timer,(ETHER_WAIT_TICKS));
      while (!mn_timer_expired(&wait_timer))
         {
         if (readPacketPage16(PP_RxEvent) & CS_RX_OK)
            {
            retval = 1;
            break;
            }
#if (RTOS_USED != RTOS_NONE)
         MN_TASK_WAIT(1);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      if (!retval)
         return (SOCKET_TIMED_OUT);
      }

   recv_status = readWord16(RECV_PORT);
#if ( DO_DEBUG )
   mn_ustoa((byte *)Str,recv_status);
   DiagSend(Str);
   Str[0] = ' ';
   Str[1] = '\0';
   DiagSend(Str);
#else
   dummy(recv_status);  /* force compiler to not ignore recv_status */
#endif

#if (defined(POLAVRE) || defined(CMXAVRE))
   temp_char = iPS_ETH8_100_RDWR[RECV_PORT];   /* hack! */
#endif
   recv_len = readWord16(RECV_PORT);
/* recv_len = (recv_len + 1) & 0xfffe; */    /* ensure even # of chars */
   oddLength = recv_len & 0x01;

#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
   mn_ustoa(Str,recv_len);
   DiagSend(Str);
   Str[0] = ' ';
   Str[1] = '\0';
   DiagSend(Str);
#endif

   if ( (RECV_BUFF_SIZE - recv_count - 2) >= recv_len)
      {
      retval = recv_len;

       MN_TASK_LOCK;

      /* put recv_len into buffer so all packets start with the length.
         Do NOT remove the next two lines.
      */
      mn_put_recv_byte(HIGHBYTE(recv_len));
      mn_put_recv_byte(LOWBYTE(recv_len));

      if (oddLength)
         recv_len--;    /* need even count for the loop */

      for (i=0; i<recv_len;i += 2)
         {
         *recv_in_ptr = iPS_ETH8_100_RDWR[RECV_PORT];
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
         mn_uctoa(Str,*recv_in_ptr);
         DiagSend(Str);
         Str[0] = ' ';
         Str[1] = '\0';
         DiagSend(Str);
#endif
         if (++recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];

         *recv_in_ptr = iPS_ETH8_100_RDWR[RECV_PORT1];
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
         mn_uctoa(Str,*recv_in_ptr);
         DiagSend(Str);
         Str[0] = ' ';
         Str[1] = '\0';
         DiagSend(Str);
#endif
         if (++recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];

         recv_count += 2;
         }

      if (oddLength)    /* get the last byte */
         {
         *recv_in_ptr = iPS_ETH8_100_RDWR[RECV_PORT];
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
         mn_uctoa(Str,*recv_in_ptr);
         DiagSend(Str);
         Str[0] = ' ';
         Str[1] = '\0';
         DiagSend(Str);
#endif
         if (++recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
            recv_in_ptr = &recv_buff[0];

         recv_count++;
         }

       MN_TASK_UNLOCK;

#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
         strcpy_P(Str,str8);
         DiagSend(Str);
#endif
      }
   else
      {
      /* not enough room to hold this packet so get rid of it */
#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG )
         strcpy_P(Str,str7);
         DiagSend(Str);
#endif
      writePacketPage16(PP_RxCFG, CS_SKIP_1);            /* skip this frame */
      retval = ETHER_RECV_ERROR;
      }

   return (retval);
}

#endif      /* POLLED_ETHERNET */


/*********************************************************/

/* Returns the data read from PacketPage address, PPadd */
static word16 readPacketPage16(word16 PPadd)
cmx_reentrant {
   iPS_ETH8_100_RDWR[PP_POINTER_PORT] = PPadd & 0x00ff;         /* PacketPage pointer low byte */
   iPS_ETH8_100_RDWR[PP_POINTER_PORT1] = (PPadd >> 8) & 0x00ff; /* PacketPage pointer high byte */

   return (readWord16(PP_DATA_PORT));
}


/* Writes the data, PPdata, to the PacketPage address, PPadd */
static void writePacketPage16(word16 PPadd, word16 PPdata)
cmx_reentrant {
   iPS_ETH8_100_RDWR[PP_POINTER_PORT] = PPadd & 0x00ff;         /* PacketPage pointer low byte */
   iPS_ETH8_100_RDWR[PP_POINTER_PORT1] = (PPadd >> 8) & 0x00ff; /* PacketPage pointer high byte */

   iPS_ETH8_100_RDWR[PP_DATA_PORT] = PPdata & 0x00ff;    /* Data low byte */
   iPS_ETH8_100_RDWR[PP_DATA_PORT1] = (PPdata >> 8) & 0x00ff;  /* Data high byte */
}

#if (!(defined(POLTRI51) || defined(CMXTRI51)))
static void cs8900_reset(void)
cmx_reentrant {
   writePacketPage16(PP_SelfCTL, CS_RESET);     /* reset command */
   MN_TASK_WAIT(2);

   do
      {
      MN_TASK_WAIT(1);
      /* wait until reset bit is cleared */
      if (readPacketPage16(PP_SelfCTL) & CS_RESET)
         continue;
      }
      /* wait till CS_INITD bit is set */
   while (!(readPacketPage16(PP_SelfST) & CS_INITD));
}
#endif      /* (!(defined(POLTRI51) || defined(CMXTRI51))) */

#if ( (defined(POLAVRE) || defined(CMXAVRE)) && DO_DEBUG)
void DiagSend(char *Str)
cmx_reentrant {
   char i;

   i = 0; 
   
   while(Str[i] != 0)
      {   
      while(!(USR & 0x20));
      UDR = Str[i++];
      }  

  }
#endif      /* (defined(POLAVRE) || defined(CMXAVRE)) */

#if (!DO_DEBUG)
/* Needed to force compiler to not ignore recv_status above */
static void dummy(word16 d)
cmx_reentrant {
   d=d;
}
#endif      /* !DO_DEBUG */

int cs8900_get_link_status(void) cmx_reentrant 
{
   unsigned int status;
   status = readPacketPage16(PP_LineST);
   if (status & CS_LINK_OK)
      return 1;
   return 0;
}


#endif      /* (ETHERNET) */

