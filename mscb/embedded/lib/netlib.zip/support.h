/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef SUPPORT_H_INC
#define SUPPORT_H_INC   1

byte mn_ustoa(byte *str,word16 num) cmx_reentrant;
byte mn_uctoa(byte *str, byte num) cmx_reentrant;
word16 mn_getMyIPAddr_func(byte **) cmx_reentrant;
word16 mn_atous(byte *str) cmx_reentrant;

#endif   /* #ifndef SUPPORT_H_INC */

