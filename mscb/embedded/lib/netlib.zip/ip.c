/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

static byte ip_recv_header(void) cmx_reentrant;
static word32 ip_checksum(word16,word16,word16,word16,word16,byte *,byte *, byte) cmx_reentrant;
static byte is_multicast(void) cmx_reentrant;

byte recv_src_addr[IP_ADDR_LEN];
byte recv_dest_addr[IP_ADDR_LEN];
word16 ip_recv_len;

byte null_addr[IP_ADDR_LEN];
#if (DHCP || BOOTP || ALLOW_BROADCAST)
byte broadcast_addr[IP_ADDR_LEN];
#endif      /* (DHCP || BOOTP || ALLOW_BROADCAST) */
#if (ALLOW_MULTICAST)
byte all_hosts_addr[IP_ADDR_LEN];
#endif      /* (ALLOW_MULTICAST) */

#if (ETHERNET)
#if (USE_RECV_BUFF)
static byte *next_out_ptr;    /* holds position where next packet starts */
static void reset_recv(void) cmx_reentrant;
#endif      /* (USE_RECV_BUFF) */
#endif      /* (ETHERNET) */

#if (PING)
static SCHAR get_ping_pkt(void) cmx_reentrant;
static void send_ping_reply(void) cmx_reentrant;

/* add 9 to PING_BUFF_SIZE for the partial header we copy also */
static byte ping_reply_buff[PING_BUFF_SIZE+9];
#endif      /* (PING) */

/********************************************************************/

/* Initialize IP variables. */
void mn_ip_init(void)
cmx_reentrant {
   MN_MUTEX_WAIT(MUTEX_IP_RECEIVE,INFINITE_WAIT);

   ip_recv_len = 0;
#if (ETHERNET)
#if (USE_RECV_BUFF)
   next_out_ptr = BYTE_PTR_NULL;
#endif      /* (USE_RECV_BUFF) */
#endif      /* (ETHERNET) */

   MEMSET(recv_src_addr, 0, sizeof(recv_src_addr));
   MEMSET(recv_dest_addr, 0, sizeof(recv_dest_addr));
   MEMSET(null_addr, 0, sizeof(null_addr));
#if (PING)
   MEMSET(ping_reply_buff, 0, sizeof(ping_reply_buff));
#endif      /* (PING) */
#if (DHCP || BOOTP || ALLOW_BROADCAST)
   broadcast_addr[0] = broadcast_addr[1] = broadcast_addr[2] = \
      broadcast_addr[3] = 0xff;
#endif      /* (DHCP || BOOTP || ALLOW_BROADCAST) */

#if (ALLOW_MULTICAST)
   all_hosts_addr[0] = 224;
   all_hosts_addr[1] =   0;
   all_hosts_addr[2] =   0;
   all_hosts_addr[3] =   1;
#endif      /* (ALLOW_MULTICAST) */

   MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
}

/* Waits for a signal from the ISR that a packet has been received or when
   POLLED_ETHERNET is used polls every other system tick for a packet. If
   a packet is present it processes the packet and wakes the appropriate
   task that is waiting.
*/
#if (RTOS_USED != RTOS_NONE)
void mn_receive_task(void)
cmx_reentrant {
   byte packet_type;
   PSOCKET_INFO socket_ptr;
   int retval;

#if (POLLED_ETHERNET)
   /* Wait for signal from mn_init that it is ok to start. */
   if (MN_SIGNAL_WAIT(SIGNAL_RECEIVE,INFINITE_WAIT) == SIGNAL_SUCCESS)
#endif      /* (POLLED_ETHERNET) */
      {
      while (1)
         {
#if (POLLED_ETHERNET)
         MN_TASK_WAIT(1);
#else
         /* wait for a signal from the ethernet or UART receive ISR */
         if (MN_SIGNAL_WAIT(SIGNAL_RECEIVE,INFINITE_WAIT) == SIGNAL_SUCCESS)
#endif      /* (POLLED_ETHERNET) */
            {
#if (PPP)
            if (recv_count < MIN_PPP_LEN)
               continue;
#elif (SLIP)
            if (recv_count < MIN_SLIP_LEN)
               continue;
#endif      /* (PPP) */

            packet_type = mn_ip_recv();
            /* mn_ip_recv will take care of ARP and ICMP packets */
            if (!(packet_type & (TCP_TYPE|UDP_TYPE)))
               continue;

            socket_ptr = PTR_NULL;
            retval = 0;
#if TCP
            if (packet_type & TCP_TYPE)
               {
               retval = mn_tcp_recv(&socket_ptr);
#if 0
               /* Get another packet if we need to listen. */
               if (retval == NEED_TO_LISTEN)
                  continue;
#endif
               }
#endif
#if TCP && UDP
            else
#endif
#if UDP
               {
               if (packet_type & UDP_TYPE)
                  {
                  retval = mn_udp_recv(&socket_ptr);
                  }
               }
#endif
            /* signal the task associated with the socket that we have
               received a packet for it and save the return value from
               the TCP or UDP receive function.
            */
            if (socket_ptr != PTR_NULL && SOCKET_ACTIVE(socket_ptr->socket_no))
               {
               socket_ptr->last_return_value = retval;
               MN_SIGNAL_POST(signal_socket[socket_ptr->socket_no]);
               }

            }     /* SIGNAL_WAIT */
         }        /* while (1) */
      }

   MN_TASK_STOP;     /* Should never reach here ... */
}
#endif      /* (RTOS_USED != RTOS_NONE) */

/* ----------------------------------------------------------------------- */
/* Receives ethernet or PPP or SLIP header and IP header. If an ICMP echo  */
/* request is received it will send an ICMP echo reply. Returns the        */
/* packet_type. It should be checked so the proper routine can be called   */
/* to process the rest of the packet. */
byte mn_ip_recv(void)
cmx_reentrant {
   byte packet_type;
   
   packet_type = mn_ip_get_pkt();
   if (packet_type & ICMP_TYPE)        /* ICMP ? */
      {
#if (PING)
      if (get_ping_pkt() >= 0)         /* copy the packet into the buffer */
         {
         /* Signal the ping reply task or send the reply directly. */
#if (RTOS_USED != RTOS_NONE)
         MN_SIGNAL_POST(SIGNAL_PING_REPLY);
#else
         send_ping_reply();
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
#else
      /* PING not enabled */
      mn_ip_discard_packet();       /* get rid of it. */
#endif      /* (PING) */
      }

   else if (packet_type & IGMP_TYPE)        /* IGMP ? */
      {
#if (IGMP)
      mn_igmp_process_packet();
#endif      /* (IGMP) */
      mn_ip_discard_packet();       /* get rid of it. */
      }

   return (packet_type);
}

/* Does the bulk of the IP level receiving chores. */
byte mn_ip_get_pkt(void)
cmx_reentrant {
   byte packet_type;
#if PPP
   byte ppp_ok;
#endif      /* PPP */
#if ETHERNET
#if (USE_RECV_BUFF)
   word16 eth_len;
   byte *tmp_ptr;
#endif      /* (USE_RECV_BUFF) */
#endif      /* ETHERNET */

#if (RTOS_USED != RTOS_NONE)
   if (MN_MUTEX_WAIT(MUTEX_IP_RECEIVE,(SOCKET_WAIT_TICKS)) != MUTEX_SUCCESS)
      return (0);
#endif      /* (RTOS_USED != RTOS_NONE) */

   ip_recv_len = 0;

#if (ETHERNET && POLLED_ETHERNET)
   /* if ethernet is in polled mode call ethernet receive routine */
   if (ETHER_POLL_RECV <= 0)
      {
      MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
      return 0;
      }
#else
   if (!mn_recv_byte_present())  /* data present? */
      {
      MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
      return 0;
      }
#endif

#if ETHERNET
#if (USE_RECV_BUFF)
   /* read the length and calculate next_out pointer. We need this pointer
      for mn_ip_discard_packet.
   */
   eth_len = LSHIFT8(mn_recv_byte());
   eth_len += (word16)(mn_recv_byte());

   /* if eth_len is > ETHER_SIZE something is really screwed up, so we
      reset the receive pointers and count, then exit.
   */
   if (eth_len > ETHER_SIZE || eth_len == 0)
      {
      reset_recv();
      MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
      return 0;
      }

   tmp_ptr = recv_out_ptr + eth_len;
   if ( tmp_ptr <=  &recv_buff[RECV_BUFF_SIZE-1])
      next_out_ptr = tmp_ptr;
   else
      {
      next_out_ptr = &recv_buff[0] + (eth_len - \
         (&recv_buff[RECV_BUFF_SIZE-1] - recv_out_ptr + 1));
      }
#endif      /* (USE_RECV_BUFF) */

   /* ether_recv_header() will take care of ARP. It will return 1 if there
      is an IP packet to be processed, 0 if we processed a valid arp packet,
      otherwise returns -1.
   */
   switch (ether_recv_header())
      {
      case 1:
         /* IP packet, handle it below. */
         break;
      case 0:
         /* arp packet, we already finished with it. */
         return (ARP_TYPE);
      default:
         /* error */
         return 0;
      }
#elif PPP
#if (RTOS_USED != RTOS_NONE)
   if (MN_MUTEX_WAIT(MUTEX_PPP,(SOCKET_WAIT_TICKS)) != MUTEX_SUCCESS)
      {
      MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
      return 0;
      }
#endif      /* (RTOS_USED != RTOS_NONE) */
   ppp_ok = mn_ppp_state_machine();    /* process PPP header. */
   if (!ppp_ok)
      {
      MN_MUTEX_RELEASE(MUTEX_PPP);
      MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
      return 0;
      }
#elif SLIP
   packet_type = 0;
   /* Check for SLIP_END character */
   if (SLIP_END == (byte)(mn_recv_escaped_byte(TRUE)))
#endif

      packet_type = ip_recv_header();           /* process IP header. */

   if (!packet_type || packet_type & UNKNOWN_TYPE)
      mn_ip_discard_packet();

   /* need to toss tcp packets if tcp not included and toss udp packets if
      udp not included.
   */
#if (!TCP)
   else if (packet_type & TCP_TYPE)
      {
      mn_ip_discard_packet();
      packet_type = 0;
      }
#endif

#if (!UDP)
   else if (packet_type & UDP_TYPE)
      {
      mn_ip_discard_packet();
      packet_type = 0;
      }
#endif

#if (ETHERNET && ARP && ARP_AUTO_UPDATE)
   else if (packet_type & TCP_TYPE || packet_type & UDP_TYPE || \
            packet_type & ICMP_TYPE)
      {
      /* update ARP cache with received IP & hw addresses */
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
      mn_arp_update(recv_src_addr,eth_dest_hw_addr);
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
      }
#endif      /* (ETHERNET && ARP) */

   return (packet_type);
}

/* ----------------------------------------------------------------------- */
/* Compute the IP checksum then send the IP header. Returns 1 if able to
   send packet, otherwise returns a negative number.
*/
SCHAR mn_ip_send_header(PSOCKET_INFO socket_ptr,byte ip_proto,word16 ip_len)
cmx_reentrant {
   word32 csum;
   byte ip_csum_hb;
   byte ip_csum_lb;
   static word16 ip_id = 0;
   word16 pkt_ip_id;
   int memcmp_retval;
   word16 TTLProto;
#if ETHERNET
   byte isBcast;
   SCHAR retval;
#endif

   if (socket_ptr == PTR_NULL)
      return (BAD_SOCKET_DATA);

#if (DHCP)
   /* Don't allow packets to be sent when in DHCP renewing or rebinding mode
      other than DHCP packets.
   */
   if (bootpMode != BOOTP_INACTIVE && \
         socket_ptr->src_port != DHCP_CLIENT_PORT)
      return (DHCP_LEASE_RENEWING);
#endif      /* (DHCP) */

#if (BOOTP || DHCP)
   if (bootpMode != BOOTP_ACTIVE)
#endif      /* (BOOTP || DHCP) */
      {
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
      memcmp_retval = memcmp(ip_src_addr,null_addr,IP_ADDR_LEN);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
      if (memcmp_retval == 0)
         return (BAD_SOCKET_DATA);
      }

   ip_len += IP_HEADER_LEN;

   MN_MUTEX_WAIT(MUTEX_IP_SEND,INFINITE_WAIT);
   ++ip_id;
   pkt_ip_id = ip_id;
   MN_MUTEX_RELEASE(MUTEX_IP_SEND);

   if (socket_ptr->socket_type & MULTICAST_TYPE)
      TTLProto = MK_WORD16(MULTICAST_TTL,ip_proto);
   else
      TTLProto = MK_WORD16(TIME_TO_LIVE,ip_proto);

#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
   csum = ip_checksum(IP_VER_IHL_TOS,ip_len,pkt_ip_id,0,TTLProto, \
         ip_src_addr, socket_ptr->ip_dest_addr, 0);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */

   ip_csum_hb = HIGHBYTE(csum);
   ip_csum_lb = LOWBYTE(csum);

   /* send the header */
#if ETHERNET
/* bww Check for broadcast flag, tell function to send to 255.255.255.255 if
   broadcast is on, otherwise do not.  Previous version sent a FALSE.
*/

#if (BOOTP || DHCP)
   if (ip_proto == PROTO_ICMP)
      isBcast = FALSE;
   else
      isBcast = (byte)(bootpMode == BOOTP_ACTIVE);
#else
      isBcast = FALSE;
#endif      /* (BOOTP || DHCP) */

   retval = mn_ether_start_packet(socket_ptr, ETH_IP_TYPE, isBcast);
   if (retval != 1)
      return (retval);

#elif PPP
   if (!mn_ppp_start_ip_packet())
      return (UNABLE_TO_SEND);
#elif SLIP
   if (!mn_transmit_ready())
      return (UNABLE_TO_SEND);
   mn_send_byte(SLIP_END);
#endif

   mn_send_escaped_byte(IP_VER_IHL,TRUE);
   mn_send_escaped_byte(ROUTINE_SERVICE,TRUE);
   mn_send_escaped_byte(HIGHBYTE(ip_len),TRUE);
   mn_send_escaped_byte(LOWBYTE(ip_len),TRUE);
   mn_send_escaped_byte(HIGHBYTE(pkt_ip_id),TRUE);
   mn_send_escaped_byte(LOWBYTE(pkt_ip_id),TRUE);
   mn_send_escaped_byte(LAST_FRAGMENT,TRUE);
   mn_send_escaped_byte(NO_FRAGMENT,TRUE);
   if (socket_ptr->socket_type & MULTICAST_TYPE)
      mn_send_escaped_byte(MULTICAST_TTL,TRUE);
   else
      mn_send_escaped_byte(TIME_TO_LIVE,TRUE);
   mn_send_escaped_byte(ip_proto,TRUE);
   mn_send_escaped_byte(ip_csum_hb,TRUE);
   mn_send_escaped_byte(ip_csum_lb,TRUE);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
   mn_send_escaped_byte(ip_src_addr[0],TRUE);
   mn_send_escaped_byte(ip_src_addr[1],TRUE);
   mn_send_escaped_byte(ip_src_addr[2],TRUE);
   mn_send_escaped_byte(ip_src_addr[3],TRUE);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */

   mn_send_escaped_byte(socket_ptr->ip_dest_addr[0],TRUE);
   mn_send_escaped_byte(socket_ptr->ip_dest_addr[1],TRUE);
   mn_send_escaped_byte(socket_ptr->ip_dest_addr[2],TRUE);
   mn_send_escaped_byte(socket_ptr->ip_dest_addr[3],TRUE);

   return (1);
}

#if (USE_RECV_BUFF)
/* eat rest of packet */
void mn_ip_discard_packet(void)
cmx_reentrant {
#if (PPP || SLIP)
   byte thisChar;
   int status;
#elif (ETHERNET)
   RECV_COUNT_T num_skip;
#endif      /* (PPP || SLIP) */

#if ETHERNET
   if (recv_out_ptr != next_out_ptr)
      {
      if (recv_out_ptr < next_out_ptr)  /* calculate bytes we are skipping */
         num_skip = next_out_ptr - recv_out_ptr;
      else                                   /* handle wrap */
         num_skip = RECV_BUFF_SIZE - (recv_out_ptr - next_out_ptr);
      if (num_skip > recv_count)
         {
         /* if num_skip is greater than recv_count we have a serious problem
            so just reset the receive pointers.
         */
         reset_recv();
         }
      else
         {
         DISABLE_INTERRUPTS;
         recv_count -= num_skip;
         recv_out_ptr = next_out_ptr;
         ENABLE_INTERRUPTS;
         }
      }

#elif (PPP)
   byte lastChar;

   thisChar = 0;

   while(1)
      {
      lastChar = thisChar;
      status = mn_recv_byte();
      if (status == RECV_TIMED_OUT)
         break;
      else
         thisChar = (byte)status;
      if (thisChar != PPP_FRAME)
         continue;
      if (lastChar != PPP_ESC)
         break;
      }
   mn_ppp_recv_init();
   MN_MUTEX_RELEASE(MUTEX_PPP);
#elif SLIP
   thisChar = 0;

   while(thisChar != SLIP_END)
      {
      status = mn_recv_byte();
      if (status == RECV_TIMED_OUT)
         break;
      else
         thisChar = (byte)status;
      }
#endif

   MN_MUTEX_RELEASE(MUTEX_IP_RECEIVE);
}
#endif      /* (USE_RECV_BUFF) */

/* get the IP header, returns packet type or 0 if the header is not valid. */
static byte ip_recv_header(void)
cmx_reentrant {
   byte tos, ttl, proto, csumh, csuml, ver_ihl, ip_hdr_len, opt_len;
   byte packet_type;
   word16 IPId, frag;
   word32 csum;

   packet_type = 0;

   ver_ihl = (byte)(mn_recv_escaped_byte(TRUE));
   ip_hdr_len = (byte)(ver_ihl & 0x0f);
   if ((((ver_ihl >> 4) & 0x0f) == IP_VER) && (ip_hdr_len >= MIN_IHL))
      {
      ip_hdr_len <<= 2;       /* convert ip_hdr_len to number of bytes */
      /* Get number of option bytes. */
      opt_len = (byte)(ip_hdr_len - IP_HEADER_LEN);

      tos = (byte)(mn_recv_escaped_byte(TRUE));
      ip_recv_len = LSHIFT8(mn_recv_escaped_byte(TRUE));
      ip_recv_len += (word16)mn_recv_escaped_byte(TRUE);
      if (ip_recv_len < IP_HEADER_LEN)
         return (0);
      IPId = LSHIFT8(mn_recv_escaped_byte(TRUE));
      IPId += (word16)mn_recv_escaped_byte(TRUE);
      frag = LSHIFT8(mn_recv_escaped_byte(TRUE));
      frag += (word16)mn_recv_escaped_byte(TRUE);
      if (frag & 0x20)
         packet_type |= FRAG_TYPE;
      ttl = (byte)(mn_recv_escaped_byte(TRUE));
      proto = (byte)(mn_recv_escaped_byte(TRUE));
      switch (proto)
         {
         case PROTO_TCP:
            packet_type |= TCP_TYPE;
            break;
         case PROTO_UDP:
            packet_type |= UDP_TYPE;
            break;
         case PROTO_ICMP:
            packet_type |= ICMP_TYPE;
            break;
         case PROTO_IGMP:
            packet_type |= IGMP_TYPE;
            break;
         default:
            packet_type |= UNKNOWN_TYPE;
            break;
         }
      csumh = (byte)(mn_recv_escaped_byte(TRUE));
      csuml = (byte)(mn_recv_escaped_byte(TRUE));
      /* recv_src_addr is used by TCP and UDP to create a new socket */
      recv_src_addr[0] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_src_addr[1] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_src_addr[2] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_src_addr[3] = (byte)(mn_recv_escaped_byte(TRUE));

      /* Discard packet if the source IP address is a multicast address. */
      if (recv_src_addr[0] >= 224 && recv_src_addr[0] <= 239)
         return (0);

      recv_dest_addr[0] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_dest_addr[1] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_dest_addr[2] = (byte)(mn_recv_escaped_byte(TRUE));
      recv_dest_addr[3] = (byte)(mn_recv_escaped_byte(TRUE));

#if (PING_GLEANING)
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
      /* we should only get here if the MAC address of the incoming packet
         matched our MAC address. So, if the MAC addresses match assume the
         incoming IP address is ours and set it. To only have the incoming IP
         address used when we don't know our IP address, comment out the
         second line and uncomment the first line below.
      */
/*    if (ip_src_addr[0] == 0 && packet_type & ICMP_TYPE) */
      if (packet_type & ICMP_TYPE)
         (void)memcpy(ip_src_addr, (void *)recv_dest_addr, IP_ADDR_LEN);
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif

#if (PPP || PING_GLEANING || !(ARP))
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || PING_GLEANING || !(ARP)) */
#if (ALLOW_BROADCAST || BOOTP || DHCP)
      if ( (!is_multicast()) && \
            (((recv_dest_addr[0] != ip_src_addr[0]) && (recv_dest_addr[0] != 255)) || \
            ((recv_dest_addr[1] != ip_src_addr[1]) && (recv_dest_addr[1] != 255)) || \
            ((recv_dest_addr[2] != ip_src_addr[2]) && (recv_dest_addr[2] != 255)) || \
            ((recv_dest_addr[3] != ip_src_addr[3]) && (recv_dest_addr[3] != 255))))
#else
      if ( (!is_multicast()) && \
            ((recv_dest_addr[0] != ip_src_addr[0]) || \
            (recv_dest_addr[1] != ip_src_addr[1]) || \
            (recv_dest_addr[2] != ip_src_addr[2]) || \
            (recv_dest_addr[3] != ip_src_addr[3])))
#endif      /* (ALLOW_BROADCAST) */
         {
#if (PPP || PING_GLEANING || !(ARP))
         MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || PING_GLEANING || !(ARP)) */
         return 0;
         }
#if (PPP || PING_GLEANING || !(ARP))
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || PING_GLEANING || !(ARP)) */

      csum = ip_checksum(MK_WORD16(ver_ihl,tos), ip_recv_len, IPId, frag, \
         MK_WORD16(ttl, proto), recv_dest_addr, recv_src_addr, opt_len);

      /* validate checksum */
      if (csumh != HIGHBYTE(csum) || csuml != LOWBYTE(csum))
         return(0);

      ip_recv_len -= ip_hdr_len;

      return(packet_type);       /* ok */
      }
   else
      {
      return(0);     /* error */
      }
}

/* ----------------------------------------------------------------------- */

/* Returns true if the received destination IP address is a valid multicast
   destination address. If multicasting is allowed the all-hosts group is
   always allowed even if IGMP is not enabled.
*/
static byte is_multicast(void)
cmx_reentrant {
   byte retval;
#if (IGMP)
   PIGMP_INFO pigmp;
#endif      /* (IGMP) */

   retval = FALSE;

#if (ALLOW_MULTICAST)
   if (memcmp(recv_dest_addr,all_hosts_addr,IP_ADDR_LEN) == 0)
      retval = TRUE;
#if (IGMP)
   if (!retval)
      {
      /* Search the igmp list for a valid matching entry. */
      MN_MUTEX_WAIT(MUTEX_IGMP,INFINITE_WAIT);
      pigmp = mn_igmp_search_entry(recv_dest_addr);
      if (pigmp != PTR_NULL && pigmp->ref_count && \
            (pigmp->igmp_state == IGMP_DELAY_MEMBER || \
            pigmp->igmp_state == IGMP_IDLE_MEMBER))
         retval = TRUE;
      MN_MUTEX_RELEASE(MUTEX_IGMP);
      }
#endif      /* (IGMP) */
#endif      /* (ALLOW_MULTICAST) */

   return (retval);
}

/* Calculate IP checksum. This function assumes that opt_len will only be
   greater than zero when called by ip_recv_header. When this function is
   called from mn_ip_send_header opt_len MUST be zero.
*/
static word32 ip_checksum(word16 tos, word16 IPlen, word16 IPId, word16 frag, \
   word16 TTLProto, byte *srcaddr, byte *rsrcaddr, byte opt_len)
cmx_reentrant {
   word32 csum;
   word16 temp_data;
   byte i;

   csum =  tos;            /* tos = version, IHL and type of service. */
   csum += CSUM_WORD16(srcaddr[0],srcaddr[1]);
   csum += CSUM_WORD16(srcaddr[2],srcaddr[3]);
   csum += IPlen;
   csum += IPId;
   csum += frag;
   csum += TTLProto;
   csum += CSUM_WORD16(rsrcaddr[0],rsrcaddr[1]);
   csum += CSUM_WORD16(rsrcaddr[2],rsrcaddr[3]);

   /* Option length must be an even number. */
   if (opt_len && !(opt_len & 1))
      {
      /* Throw away options, just get their checksum value. */
      for (i=0; i<opt_len; i+=2)
         {
         temp_data = LSHIFT8(mn_recv_escaped_byte(TRUE));
         temp_data += (word16)(mn_recv_escaped_byte(TRUE));
         csum += temp_data;
         }
      }

   csum = mn_udp_tcp_end_checksum(csum);

   return (csum);
}

#if (PING)
#if (RTOS_USED != RTOS_NONE)
void mn_ping_reply_task(void)
cmx_reentrant {
   while (1)
      {
      /* Wait for a signal from mn_receive_task. */
      if (MN_SIGNAL_WAIT(SIGNAL_PING_REPLY,INFINITE_WAIT) == SIGNAL_SUCCESS)
         send_ping_reply();
      }
}
#endif      /* (RTOS_USED != RTOS_NONE) */

/* Reads rest of ping request packet. Returns socket number if ok to send a
   reply, otherwise returns -1.
*/
static SCHAR get_ping_pkt(void)
cmx_reentrant {
   byte c;
   SCHAR retval;
   byte csum_hb;
   byte csum_lb;
   word16 ip_len;
   byte *ping_reply_ptr;
#if (ETHERNET)
   word16 bytes2end;
#endif      /* (ETHERNET) */

   retval = -1;

   c = (byte)(mn_recv_escaped_byte(TRUE));
   /* Is it an echo request? Is it small enough to fit in ping_reply_buff? */
   if ( (c == ICMP_ECHO) && (ip_recv_len <= (sizeof(ping_reply_buff)-1)) && \
         (ip_recv_len >= 4) )
      {
      /* open a socket to send the ping reply */
      retval = mn_open_socket(recv_src_addr,PING_PORT,PING_PORT,PROTO_ICMP, \
         STD_TYPE,0,0);
      if (retval >= 0)
         {
         c = (byte)(mn_recv_escaped_byte(TRUE));  /* skip the code */

         ip_len = ip_recv_len - 2;

         MN_MUTEX_WAIT(MUTEX_PING_BUFF,INFINITE_WAIT);
         /* add socket number and length to ping_reply_buff */
         ping_reply_buff[0] = (byte)retval;
         ping_reply_buff[1] = HIGHBYTE(ip_len);
         ping_reply_buff[2] = LOWBYTE(ip_len);
         ip_len -= 2;

         /* read and modify the checksum */
         csum_hb = (byte)(mn_recv_escaped_byte(TRUE));
         csum_lb = (byte)(mn_recv_escaped_byte(TRUE));
         if ((csum_hb += 8) < 0x8)
            csum_lb++;
         ping_reply_buff[3] = csum_hb;
         ping_reply_buff[4] = csum_lb;
         ping_reply_ptr = &ping_reply_buff[5];

         /* Copy everything from the receive buffer to the ping reply buffer.
         */
#if (ETHERNET && USE_RECV_BUFF)
         /* calculate the number of bytes until the end of recv_buff */
         bytes2end = &recv_buff[RECV_BUFF_SIZE - 1] - recv_out_ptr + 1;

         /* check if we have a wrap in the recv_buff */
         if (bytes2end >= ip_len)                     /* no wrap */
            (void)memcpy(ping_reply_ptr,(void *)recv_out_ptr,ip_len);
         else                                         /* handle wrap */
            {
            (void)memcpy(ping_reply_ptr,(void *)recv_out_ptr,bytes2end);
            ip_len -= bytes2end;
            (void)memcpy((ping_reply_ptr+bytes2end),(void *)(&recv_buff[0]),\
               ip_len);
            }
#else    /* PPP or SLIP */
         while (ip_len)
            {
            ip_len--;
            *ping_reply_ptr++ = (byte)(mn_recv_escaped_byte(TRUE));
            }
#endif      /* (ETHERNET) */
      
         MN_MUTEX_RELEASE(MUTEX_PING_BUFF);
         }
      }

   mn_ip_discard_packet();
   return (retval);
}

static void send_ping_reply(void)
cmx_reentrant {
   word16 data_len;
   SCHAR socket_no;
   PSOCKET_INFO socket_ptr;
#if (PPP || SLIP)
   byte *ping_reply_ptr;
#endif      /* (PPP || SLIP) */

   MN_MUTEX_WAIT(MUTEX_PING_BUFF,INFINITE_WAIT);

   /* The socket number is the first byte in the ping reply buffer. */
   socket_no = (SCHAR)ping_reply_buff[0];

   if (socket_no >= 0 && SOCKET_ACTIVE(socket_no))
      {
      socket_ptr = MK_SOCKET_PTR(socket_no);  /* get pointer to the socket */
      if (socket_ptr->ip_proto == PROTO_ICMP)
         {
         /* The next two bytes in the ping reply buffer are the length. */
         data_len = LSHIFT8(ping_reply_buff[1]);
         data_len += (word16)(ping_reply_buff[2]);

         if (data_len <= (sizeof(ping_reply_buff) - 3))
            {
#if (ETHERNET)
            socket_ptr->send_ptr = &ping_reply_buff[3];
            socket_ptr->send_len = data_len;

            /* start sending the reply */
            if (mn_ip_send_header(socket_ptr,PROTO_ICMP,(data_len+2)))
               {
               mn_send_escaped_byte(ICMP_ECHO_REPLY,TRUE);  
               mn_send_escaped_byte(0,TRUE);             /* code */
               MN_TASK_LOCK;
               (void)mn_close_packet(socket_ptr, data_len);
               MN_TASK_UNLOCK;
               }
#else    /* PPP or SLIP */
            /* start sending the reply */
            if (mn_ip_send_header(socket_ptr,PROTO_ICMP,(data_len+2)))
               {
               mn_send_escaped_byte(ICMP_ECHO_REPLY,TRUE);  
               mn_send_escaped_byte(0,TRUE);             /* code */
               ping_reply_ptr = &ping_reply_buff[3];
               while (data_len)
                  {
                  data_len--;
                  mn_send_escaped_byte(*ping_reply_ptr,TRUE);
                  ping_reply_ptr++;
                  }
               MN_TASK_LOCK;
               (void)mn_close_packet(socket_ptr, 0);
               MN_TASK_UNLOCK;
               }
#endif      /* (ETHERNET) */

            }
         (void)mn_abort(socket_no);
         }
      }

   MN_MUTEX_RELEASE(MUTEX_PING_BUFF);
}
#endif      /* (PING) */

#if (ETHERNET)
#if (USE_RECV_BUFF)
static void reset_recv(void)
cmx_reentrant {
   DISABLE_INTERRUPTS;
   init_recv();
   next_out_ptr = &recv_buff[0];
   ENABLE_INTERRUPTS;
}
#endif      /* (USE_RECV_BUFF) */
#endif      /* (ETHERNET) */

