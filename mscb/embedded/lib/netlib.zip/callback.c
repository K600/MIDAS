/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

/************************************************************
* CMX recommends making a copy of this file before changing *
* any of the routines below.                                *
*************************************************************/

#include "micronet.h"

/************************************************************
   Change the ip_src_addr below to relect the IP address of
   your target. If the IP address of the destination is known
   replace ip_dest_addr with that address. If you are dialing
   into an ISP the source and destination addresses initially
   specified do not matter as they will be negotiated.
*************************************************************/

#if ETHERNET
byte ip_dest_addr[IP_ADDR_LEN] = {192,168,2,2};
#if (PING_GLEANING)
byte ip_src_addr[IP_ADDR_LEN]  = {0,0,0,0};
#else
byte ip_src_addr[IP_ADDR_LEN]  = {192,168,2,3};
#endif      /* PING_GLEANING */
#else
byte ip_dest_addr[IP_ADDR_LEN] = {192,6,94,5};
#if (PING_GLEANING)
byte ip_src_addr[IP_ADDR_LEN]  = {0,0,0,0};
#else
byte ip_src_addr[IP_ADDR_LEN]  = {192,6,94,2};
#endif      /* PING_GLEANING */
#endif      /* ethernet */

#if (SMTP)
/* replace the ip address below with the ip address of your SMTP server */
byte ip_smtp_addr[IP_ADDR_LEN] = {216,148,227,125};
/* byte ip_smtp_addr[IP_ADDR_LEN] = {207,172,4,99}; */
#endif      /* (SMTP) */

#if ETHERNET
byte eth_dest_hw_addr[ETH_ADDR_LEN];
byte gateway_ip_addr[IP_ADDR_LEN];
byte subnet_mask[IP_ADDR_LEN];
#endif      /* ETHERNET */

/* --------------------------------------------------------------------- */
/* return number of bytes to send */
/* Called from mn_tcp_send and mn_udp_send */
word16 mn_app_get_send_size(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   word16 bytes_to_send;
#if (HTTP && SERVER_SIDE_INCLUDES)
   word16 num_bytes;
#endif      /* (HTTP && SERVER_SIDE_INCLUDES) */

   bytes_to_send = (socket_ptr->send_ptr == PTR_NULL ? 0: socket_ptr->send_len);
#if (HTTP || FTP || SMTP)
   if (bytes_to_send)
      {
      if ( (socket_ptr->socket_type & (HTTP_TYPE|SMTP_TYPE)) || \
            socket_ptr->src_port == FTP_DATA_PORT )
         {
         bytes_to_send = ((bytes_to_send > TCP_WINDOW) ? TCP_WINDOW : bytes_to_send);

#if (VIRTUAL_FILE)
#if (HTTP && SERVER_SIDE_INCLUDES)
         if ((socket_ptr->socket_type & HTTP_TYPE) && \
               (http_vf_ptrs[socket_ptr->socket_no] != PTR_NULL) && \
               (http_vf_ptrs[socket_ptr->socket_no]->page_type & VF_PTYPE_HTML))
            {
            num_bytes = mn_http_process_includes(socket_ptr,bytes_to_send);
            if (num_bytes)
               bytes_to_send = num_bytes;
            else
               bytes_to_send = socket_ptr->send_len;
            }
         else
#endif      /* (HTTP && SERVER_SIDE_INCLUDES) */
            {
#if (FTP && FTP_SERVER)
            if ((socket_ptr->socket_type & FTP_TYPE) && \
                  (socket_ptr->src_port == FTP_DATA_PORT) && \
                  (ftp_transfer_mode & FTP_LIST_ACTIVE))
               bytes_to_send = ftp_list(socket_ptr);
            else
#endif      /* (FTP && FTP_SERVER) */
            /* copy bytes to send from ROM to RAM buffer if necessary */
            if (page_send_info[socket_ptr->socket_no].page_ptr != PTR_NULL)
               {
               mn_memcpy_cb(socket_ptr->send_ptr, \
                  page_send_info[socket_ptr->socket_no].page_ptr, bytes_to_send);
               }
            }
#endif      /* (VIRTUAL_FILE) */
         }
      }
#endif      /* (HTTP || FTP || SMTP) */

   return (bytes_to_send);
}

/* initialization before receiving a packet */
/* Called from mn_tcp_recv and mn_udp_recv */
/* num = number of bytes to be received */   
void mn_app_init_recv(word16 num,PSOCKET_INFO socket_ptr)
cmx_reentrant {
#if (!(FTP && FTP_SERVER))
   num = num;
#endif      /* (!(FTP && FTP_SERVER)) */
   socket_ptr->recv_len = 0;

#if HTTP
   if (socket_ptr->socket_type & HTTP_TYPE)
      mn_http_init_recv(socket_ptr);
   else
#endif
#if (FTP && FTP_SERVER)
   if (socket_ptr->socket_type & FTP_TYPE)
      mn_ftp_server_init_recv(num,socket_ptr);
   else
#endif
      {
      /* put your code here */
      ;
      }
}

/* process received byte. Called from mn_tcp_recv and mn_udp_recv */
void mn_app_recv_byte(byte c,PSOCKET_INFO socket_ptr)
cmx_reentrant {
   byte *buff_ptr;

#if HTTP
   if (socket_ptr->socket_type & HTTP_TYPE)
      mn_http_recv_byte(c,socket_ptr);
   else
#endif
#if (FTP && FTP_SERVER)
   if (socket_ptr->src_port == FTP_CONTROL_PORT)
      mn_ftp_server_recv_byte(c);
   else
#endif
      {
      if (socket_ptr->recv_ptr != PTR_NULL)
         {
         /* copy the data into a buffer where we will deal with it later */
         buff_ptr = socket_ptr->recv_ptr + socket_ptr->recv_len;
         if (buff_ptr <= socket_ptr->recv_end)
            {
            *buff_ptr = c;
            socket_ptr->recv_len++;
            }
         }
      }
}

/* Process received packet. Called from mn_tcp_recv and mn_udp_recv. */
SCHAR mn_app_process_packet(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   /* for TCP packets if this function returns NEED_IGNORE_PACKET then
      the packet will be not be ACKed. UDP packets are not effected by
      the return code.
   */

#if HTTP
   if (socket_ptr->socket_type & HTTP_TYPE)
      return (mn_http_process_packet(socket_ptr));
   else
#endif
#if (FTP && FTP_SERVER)
   if (socket_ptr->src_port == FTP_CONTROL_PORT)
      mn_ftp_server_process_packet(socket_ptr);
   else if (socket_ptr->src_port == FTP_DATA_PORT)
      mn_ftp_server_process_data(socket_ptr);
   else
#endif
      {
      /* remove the next line and put your code here */
      socket_ptr = socket_ptr;
      ;
      }

   return (1);
}

#if TCP
/*
   Do what needs to be done after successfully sending a packet.
   Called from mn_tcp_recv().
*/
void mn_app_send_complete(word16 data_len,PSOCKET_INFO socket_ptr)
cmx_reentrant {
#if (VIRTUAL_FILE)
   PAGE_SEND_PTR ps_ptr;

   ps_ptr = &page_send_info[socket_ptr->socket_no];
#endif      /* (VIRTUAL_FILE) */

#if (HTTP && SERVER_SIDE_INCLUDES)
   /* When using server-side includes the size of the data sent may
      not be the same as the size of the data read from the web page.
      The mn_http_process_includes function keeps track of the bytes
      read from the page in the page_send_info structure bytes_read member.
   */
   if ((socket_ptr->socket_type & HTTP_TYPE) && \
         (http_vf_ptrs[socket_ptr->socket_no] != PTR_NULL) && \
         (http_vf_ptrs[socket_ptr->socket_no]->page_type & VF_PTYPE_HTML))
      data_len = ps_ptr->bytes_read;
#endif      /* (HTTP && SERVER_SIDE_INCLUDES) */
   
   /* data_len should never be greater than socket_ptr->send_len but
      just in case we check it.
   */
   data_len = data_len > socket_ptr->send_len ? socket_ptr->send_len : data_len;

   /* subtract bytes already sent */
   if (socket_ptr->send_len > 0)
      socket_ptr->send_len -= data_len;

   /* move pointer to next spot to start sending if anything left to send,
      or set it to PTR_NULL otherwise.
   */
   if (socket_ptr->send_len > 0)
      {
#if (VIRTUAL_FILE)
      if (ps_ptr->page_ptr != PTR_NULL)            /* page in ROM */
         ps_ptr->page_ptr += data_len;
      else if (ps_ptr->ram_page_ptr != PTR_NULL)   /* page in RAM using SSI */
         ps_ptr->ram_page_ptr += data_len;
      else
#endif      /* (VIRTUAL_FILE) */
         socket_ptr->send_ptr += data_len;
      }
   else     /* socket_ptr->send_len == 0 */
      {
      socket_ptr->send_ptr = PTR_NULL;
#if (VIRTUAL_FILE)
      ps_ptr->ram_page_ptr = PTR_NULL;
      ps_ptr->page_ptr = PTR_NULL;
      ps_ptr->bytes_read = 0;
#endif      /* (VIRTUAL_FILE) */
      }
}

#endif      /* #if TCP */

/* called from mn_server or mn_http_server_task when the server is idle */
SCHAR mn_app_server_idle(PSOCKET_INFO *psocket_ptr)
cmx_reentrant {
   /* put your code here.

      return NEED_TO_SEND if data must be sent immediately. If you
      switched sockets assign the new socket_ptr to psocket_ptr before
      returning NEED_TO_SEND.
      e.g. *psocket_ptr = new_socket_ptr;

      return NEED_TO_EXIT if mn_server must be exited immediately.
   */

   /* remove the next line and put your code here */
   psocket_ptr = psocket_ptr;

   return (0);
}

#if (RTOS_USED == RTOS_NONE)
/* called from mn_recv */
SCHAR mn_app_recv_idle(void)
cmx_reentrant {
   /* put your code here.

      return NEED_TO_EXIT if mn_recv must be exited immediately.
   */

   return (0);
}

/* called from mn_server after a packet has been received */
SCHAR mn_app_server_process_packet(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   /*
      return NEED_TO_EXIT if mn_server must be exited immediately.
   */

   /* remove the next line and put your code here */
   socket_ptr = socket_ptr;

   return (0);
}
#endif      /* (RTOS_USED == RTOS_NONE) */
