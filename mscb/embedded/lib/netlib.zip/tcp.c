/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

#if TCP

static void update_unacked_bytes(PSOCKET_INFO);
static SCHAR tcp_send_reset(PSOCKET_INFO) cmx_reentrant;
static SCHAR tcp_send_ack(PSOCKET_INFO) cmx_reentrant;
static SCHAR tcp_send_syn_close(PSOCKET_INFO,byte) cmx_reentrant;
static void tcp_update_ack(word16, PSOCKET_INFO) cmx_reentrant;
static SCHAR tcp_send_header(PSOCKET_INFO) cmx_reentrant;
static SCHAR tcp_send_nodata_hdr(PSOCKET_INFO,byte) cmx_reentrant;
static SCHAR tcp_send_nodata_pkt(PSOCKET_INFO,byte) cmx_reentrant;
static byte tcp_recv_header(word32 *, word16 *,PSOCKET_INFO *) cmx_reentrant;
static void tcp_recv_send(PSOCKET_INFO) cmx_reentrant;

#define tcp_send_fin_ack(p)   tcp_send_nodata_pkt((p),(TCP_FIN_ACK))
#define tcp_send_syn(p)       tcp_send_syn_close((p),(TCP_SYN))
#define tcp_send_syn_ack(p)   tcp_send_syn_close((p),(TCP_SYN_ACK))
/* ----------------------------------------------------------------------- */
/* initialize tcp settings for a socket */
void mn_tcp_init(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   if (socket_ptr != PTR_NULL)
      {
      socket_ptr->tcp_resends = TCP_RESEND_TRYS;
      socket_ptr->recv_tcp_window = TCP_WINDOW;
      socket_ptr->SND_UNA.NUML = ((word32)(socket_ptr->socket_no)<<16) + (MN_GET_TICK) + 1;
      socket_ptr->tcp_state = TCP_CLOSED;
      socket_ptr->tcp_flag = socket_ptr->recv_tcp_flag = 0;
      socket_ptr->tcp_unacked_bytes = 0;
      socket_ptr->data_offset = 0;
      socket_ptr->RCV_NXT.NUML = 0;
      socket_ptr->SEG_SEQ.NUML = 0;
      socket_ptr->SEG_ACK.NUML = 0;
      socket_ptr->tcp_timer.timer_start = 0;
      socket_ptr->tcp_timer.timer_end = 0;
      socket_ptr->tcp_timer.timer_wrap = FALSE;
      }
}

/* open a tcp connection in active or passive mode, returns tcp_state.
   times out after SOCKET_WAIT_TICKS*TCP_RESEND_TRYS ticks if doing an
   ACTIVE_OPEN.
*/
SCHAR mn_tcp_open(byte open_type,PSOCKET_INFO socket_ptr)
cmx_reentrant {
   TIMER_INFO_T wait_timer;

   if (socket_ptr == PTR_NULL || !SOCKET_ACTIVE(socket_ptr->socket_no))
      return (SOCKET_NOT_FOUND);

   switch (open_type)
      {
      case PASSIVE_OPEN:
         socket_ptr->tcp_state = TCP_LISTEN;
         break;
      case ACTIVE_OPEN:
         socket_ptr->tcp_state = TCP_SYN_SENT;
         if (tcp_send_syn(socket_ptr) > 0)
            mn_reset_timer(&wait_timer,((SOCKET_WAIT_TICKS)*(TCP_RESEND_TRYS)));
         else
            socket_ptr->tcp_state = TCP_CLOSED;
         break;
      case NO_OPEN:
         socket_ptr->tcp_state = TCP_LISTEN;
         return (TCP_LISTEN);
      default:
         return (TCP_CLOSED);
      }

   while (socket_ptr->tcp_state != TCP_ESTABLISHED && socket_ptr->tcp_state != TCP_CLOSED)
      {
      if (open_type == ACTIVE_OPEN && mn_timer_expired(&wait_timer))
         {
         mn_tcp_abort(socket_ptr);  /* sets tcp_state to TCP_CLOSED */
         break;
         }
      tcp_recv_send(socket_ptr);
      }

   return ((SCHAR)socket_ptr->tcp_state);
}

/* Get a TCP packet. Returns number of data bytes received  if ok, negative
   number not equal to NEED_TO_LISTEN if error, 0 if no data received, or
   NEED_TO_LISTEN if we need to listen again. psocket_ptr will point to the
   socket that received the data.
   mn_ip_recv() MUST be called before calling this function.
*/
int mn_tcp_recv(PSOCKET_INFO *psocket_ptr)
cmx_reentrant {
   byte c, odd_byte;
   word16 data_len;
   word16 TCPcsum;
   word32 csum;
   PSOCKET_INFO socket_ptr;
   word16 temp_data;
   word32 temp_num;
   SCHAR retval;

   if (!tcp_recv_header(&csum,&TCPcsum,psocket_ptr))
      {
      mn_ip_discard_packet();
      return (TCP_BAD_HEADER);
      }

    /* shouldn't get here if *psocket_ptr == PTR_NULL */
   socket_ptr = *psocket_ptr;

   switch(socket_ptr->tcp_state)
      {
      case TCP_ESTABLISHED:
         break;
      case TCP_CLOSED:
         mn_ip_discard_packet();
         if (!(socket_ptr->tcp_flag & TCP_RST))
            {
            tcp_send_reset(socket_ptr);
            if (socket_ptr->socket_type == AUTO_TYPE)
               {
               mn_abort(socket_ptr->socket_no);
               *psocket_ptr = PTR_NULL;
               }
            }
         return (TCP_NO_CONNECT);
      case TCP_LISTEN:
         mn_ip_discard_packet();
         if (!(socket_ptr->tcp_flag & TCP_RST))
            {
            if (socket_ptr->tcp_flag & TCP_ACK)
               {
               retval = tcp_send_reset(socket_ptr);
               if (retval > 0)
                  return 0;
               else
                  return ((int)retval);
               }
            else
               {
               socket_ptr->RCV_NXT.NUML = socket_ptr->SEG_SEQ.NUML;
               retval = tcp_send_syn_ack(socket_ptr);
               if (retval > 0)
                  socket_ptr->tcp_state = TCP_SYN_RECEIVED;
               else
                  return ((int)retval);
               }
            }
         return NEED_TO_LISTEN;
      case TCP_SYN_RECEIVED:
         /* if we received a valid packet take care of it below. */
         if ( socket_ptr->tcp_flag & TCP_ACK && \
               !( socket_ptr->tcp_flag & (TCP_RST|TCP_SYN) ) )
            break;

         /* we received a packet we weren't expecting */
         mn_ip_discard_packet();
         if (socket_ptr->tcp_flag & TCP_RST)
            {
            mn_tcp_init(socket_ptr);
            socket_ptr->tcp_state = TCP_LISTEN;
            }
         else if (socket_ptr->tcp_flag & TCP_SYN && \
               ((socket_ptr->RCV_NXT.NUML-1) == socket_ptr->SEG_SEQ.NUML))
            {
            /* if we received a SYN which is the same as the one that
               put us into SYN_RECEIVED state then our SYN_ACK must of
               got lost, send it again. For any other SYN send a reset.
            */
            tcp_send_syn_ack(socket_ptr);
            }
         else
            tcp_send_reset(socket_ptr);
         return NEED_TO_LISTEN;
/*         break; */
      case TCP_SYN_SENT:
         mn_ip_discard_packet();
         if (socket_ptr->tcp_flag & TCP_RST)
            {
/*            mn_tcp_abort(socket_ptr); */
            mn_abort(socket_ptr->socket_no);
            *psocket_ptr = PTR_NULL;
            return TCP_ERROR;
            }
         else if (!(socket_ptr->tcp_flag & TCP_ACK) || !(socket_ptr->tcp_flag & TCP_SYN)) 
            {
            retval = tcp_send_reset(socket_ptr);
            if (retval > 0)
               {
               socket_ptr->tcp_resends = TCP_RESEND_TRYS;
               return NEED_TO_LISTEN;
               }
            else
               return ((int)retval);
            }
         socket_ptr->tcp_state = TCP_ESTABLISHED;
         tcp_update_ack(1,socket_ptr);
         retval = tcp_send_ack(socket_ptr);
         if (retval > 0)
            {
            socket_ptr->tcp_resends = TCP_RESEND_TRYS;
            return 0;
            }
         else
            return ((int)retval);
      case TCP_FIN_WAIT_1:
         /* There are two possible closing sequences.
            Normal:
            A sends FIN,ACK
            B sends ACK
            B sends FIN,ACK
            A sends ACK

            Simultaneous:
            A sends FIN,ACK
            B sends FIN,ACK
            A sends FIN,ACK
            A sends ACK
            B sends ACK
            A sends ACK

            In TCP_FIN_WAIT_1 and TCP_FIN_WAIT_2 we are A. In TCP_LAST_ACK
            and CloseIt we are B. We always use the normal close when we
            are B.
         */
         mn_ip_discard_packet();
         if ( socket_ptr->recv_tcp_flag & TCP_FIN )
            {
            /* Simultaneous close */
            if (tcp_send_fin_ack(socket_ptr) > 0)
               {
               RESET_TCP_TIMER(socket_ptr);
               tcp_update_ack(1,socket_ptr);
               retval = tcp_send_ack(socket_ptr);
               if (retval <= 0)
                  return ((int)retval);
               }
            }
         socket_ptr->tcp_state = TCP_FIN_WAIT_2;
         return NEED_TO_LISTEN;
      case TCP_FIN_WAIT_2:
         if ( socket_ptr->recv_tcp_flag & TCP_FIN )
            {
            /* update seq, ack first for normal close */
            tcp_update_ack(1,socket_ptr);
            }
         mn_ip_discard_packet();
         retval = tcp_send_ack(socket_ptr);
         if (retval > 0)
            {
            socket_ptr->tcp_state = TCP_CLOSED;
            return (TCP_NO_CONNECT);
            }
         else
            return ((int)retval);
      case TCP_LAST_ACK:
         socket_ptr->tcp_state = TCP_CLOSED;
         mn_ip_discard_packet();
         return (TCP_NO_CONNECT);
      default:
         if (socket_ptr->tcp_state > TCP_TIME_WAIT)
            {
            mn_tcp_abort(socket_ptr);
            return TCP_ERROR;
            }
         break;
         }

   temp_num = socket_ptr->RCV_NXT.NUML;
   if (socket_ptr->SEG_SEQ.NUML != temp_num) /* correct sequence # ? */
      {
      /* Even though it has an incorrect sequence number it still could
         have a valid acknowledgement number, so check it.
      */
      update_unacked_bytes(socket_ptr);

      mn_ip_discard_packet();
      if (!(socket_ptr->tcp_flag & TCP_RST))
         {
         retval = tcp_send_ack(socket_ptr);        /* No, just ACK it. */
         if (retval <= 0)
            return ((int)retval);
         }
      return NEED_TO_LISTEN;
      }

   if (socket_ptr->tcp_flag & TCP_RST)
      {
/*      mn_tcp_abort(socket_ptr); */
      mn_ip_discard_packet();
      mn_abort(socket_ptr->socket_no);
      *psocket_ptr = PTR_NULL;
      return (TCP_ERROR);
      }
   else if (socket_ptr->tcp_flag & TCP_SYN)
      {
      mn_ip_discard_packet();
      retval = tcp_send_reset(socket_ptr);
      if (retval > 0)
         return (NEED_TO_LISTEN);
      else      
         return ((int)retval);
      }
   else if (!(socket_ptr->tcp_flag & TCP_ACK))
      {
      mn_ip_discard_packet();
      return NEED_TO_LISTEN;
      }

   if (socket_ptr->tcp_state != TCP_ESTABLISHED)
      socket_ptr->tcp_resends = TCP_RESEND_TRYS;

   socket_ptr->tcp_state = TCP_ESTABLISHED;

   if (ip_recv_len > TCP_WINDOW)    /* received packet too big? */
      {
      mn_ip_discard_packet();
      retval = tcp_send_ack(socket_ptr);
      if (retval > 0)
         return NEED_TO_LISTEN;
      else
         return ((int)retval);
      }

   temp_data = 0;

/* bww new call parameters */
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
   csum += mn_udp_tcp_start_checksum(PROTO_TCP,(ip_recv_len+socket_ptr->data_offset),\
      socket_ptr->src_port, socket_ptr->dest_port, ip_src_addr, \
      socket_ptr->ip_dest_addr);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */

   data_len = ip_recv_len;
   if (data_len)
      {
      odd_byte = 0;
      mn_app_init_recv(data_len,socket_ptr);
      do {
         c = (byte)(mn_recv_escaped_byte(TRUE));
         if (!odd_byte)
            {
            temp_data = LSHIFT8(c);
            odd_byte = 1;
            }
         else
            {
            temp_data += (word16)(c);
            csum += temp_data;
            odd_byte = 0;
            }
         mn_app_recv_byte(c,socket_ptr);
         }
      while (--ip_recv_len);
      if (odd_byte)           /* make sure we get all the csum data */
         csum += temp_data;
      }
   else
      socket_ptr->recv_len = 0;

   csum = mn_udp_tcp_end_checksum(csum);
   if (csum != TCPcsum)    /* checksum NG, so ignore packet */
      {
      /* should sent ICMP Parameter Problem Message */
      mn_ip_discard_packet();
      return (TCP_BAD_CSUM);
      }

#if PPP
   if (data_len)
      {
      /* make sure FCS is okay */
      if(!mn_recv_fcs_ok())
         {
         mn_ip_discard_packet();
         return (TCP_BAD_FCS);
         }
      }
#endif      /* PPP */
   
   update_unacked_bytes(socket_ptr);

   if (!data_len)
      {
      mn_ip_discard_packet();
      socket_ptr->RCV_NXT.NUML = socket_ptr->SEG_SEQ.NUML;
      if (!(socket_ptr->recv_tcp_flag & TCP_FIN))
         return 0;
      else
         goto CloseIt;
      }

   retval = mn_app_process_packet(socket_ptr);
   mn_ip_discard_packet();

   /* When mn_app_process_packet returns NEED_IGNORE_PACKET we don't ack the
      packet. We just pretend we never received it. This feature is used
      by the HTTP server to ignore a request it can't handle at the moment.
      The other side will resend the packet later at which point hopefully
      we can handle it.
   */
   if (retval == NEED_IGNORE_PACKET)
      return (0);

   socket_ptr->RCV_NXT.NUML = socket_ptr->SEG_SEQ.NUML + data_len;
   if (!(socket_ptr->recv_tcp_flag & TCP_FIN))
      {
      if ( ( (socket_ptr->socket_type & HTTP_TYPE) && \
            socket_ptr->send_len == 0 ) ||
            !(socket_ptr->socket_type & HTTP_TYPE) )
         {
         retval = tcp_send_ack(socket_ptr);
         if (retval <= 0)
            return ((int)retval);
         }
      return ((int)data_len);
      }

CloseIt:
   socket_ptr->RCV_NXT.NUML++;
   retval = tcp_send_ack(socket_ptr);
   if (retval > 0)
      {
      socket_ptr->tcp_state = TCP_LAST_ACK;
      RESET_TCP_TIMER(socket_ptr);
      retval = tcp_send_fin_ack(socket_ptr);
      if (retval > 0)
         return (NEED_TO_LISTEN);
      else
         {
         mn_abort(socket_ptr->socket_no);
         *psocket_ptr = PTR_NULL;
         return (TCP_ERROR);
         }
     }
  else
     return ((int)retval);
}

/* Check for valid received ACK and update SND_UNA if needed. */
static void update_unacked_bytes(PSOCKET_INFO socket_ptr)
{
   word16 tcp_unacked_bytes;
   word32 temp_num;

   tcp_unacked_bytes = socket_ptr->tcp_unacked_bytes;
   temp_num = socket_ptr->SND_UNA.NUML;
   if ( tcp_unacked_bytes && ( socket_ptr->SEG_ACK.NUML == (temp_num + tcp_unacked_bytes) ) )
      {
      mn_app_send_complete(tcp_unacked_bytes,socket_ptr);
      socket_ptr->tcp_unacked_bytes = 0;
      socket_ptr->tcp_resends = TCP_RESEND_TRYS;
      socket_ptr->SND_UNA.NUML = socket_ptr->SEG_ACK.NUML;
      }
}

/* Send a packet if we are not still waiting on an ack from the last one */
/* we sent. Returns number of data bytes sent, returns negative number if */
/* error or if the packet is too large to send */
int mn_tcp_send(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   word16 send_size;
   SCHAR retval;
#if (!ETHERNET)
   byte *MsgSendPointer;
#endif      /* (!ETHERNET) */

   if (socket_ptr == PTR_NULL)
      return (BAD_SOCKET_DATA);

   if (socket_ptr->tcp_state < TCP_SYN_SENT) /* valid state for send ? */
      return (TCP_NO_CONNECT);

   if (!socket_ptr->tcp_resends || socket_ptr->tcp_state > TCP_TIME_WAIT)
      {
      mn_tcp_abort(socket_ptr);
      return TCP_ERROR;
      }

   if (socket_ptr->tcp_state == TCP_SYN_SENT)
      {
      if (TCP_TIMER_EXPIRED(socket_ptr))
         {
         retval = tcp_send_syn(socket_ptr);
         if (retval <= 0)
            return ((int)retval);
         }
      return 0;
      }

   if (socket_ptr->tcp_unacked_bytes)
      {
      if (!TCP_TIMER_EXPIRED(socket_ptr))
         return 0;
      RESET_TCP_TIMER(socket_ptr);
      }
   else if (socket_ptr->tcp_state >= TCP_FIN_WAIT_1)
      {
      if (TCP_TIMER_EXPIRED(socket_ptr))
         {
         RESET_TCP_TIMER(socket_ptr);
         tcp_send_fin_ack(socket_ptr);
         return 0;
         }
      }

   socket_ptr->tcp_unacked_bytes = send_size = mn_app_get_send_size(socket_ptr);
   if (!send_size)
      return 0;
   /* make sure send_size <= recv_tcp_window */
/*   send_size = (send_size > socket_ptr->recv_tcp_window) ? socket_ptr->recv_tcp_window : send_size; */
   if (send_size > socket_ptr->recv_tcp_window)
      send_size = socket_ptr->recv_tcp_window;
   /* make sure send_size <= TCP_WINDOW */
/*   send_size = (send_size > TCP_WINDOW) ? TCP_WINDOW : send_size; */
   if (send_size > TCP_WINDOW)
      send_size = TCP_WINDOW;
   if (send_size != socket_ptr->tcp_unacked_bytes) /* packet too big */
      return TCP_TOO_LONG;

   /* Start a TCP packet.   */
   socket_ptr->tcp_flag = TCP_PSH|TCP_ACK;
   retval = tcp_send_header(socket_ptr);
   if (retval != 1)
      return ((int)retval);

#if (!ETHERNET)
   MsgSendPointer = socket_ptr->send_ptr;
   do {  /* Send the packet data. */
      mn_send_escaped_byte(*MsgSendPointer,TRUE);
      MsgSendPointer++;
      }
   while (--send_size);
#endif      /* (!ETHERNET) */
   /* At this point for PPP and SLIP send_size will always be zero. This is
      ok because mn_close_packet only uses it for ethernet packets.
   */
   MN_TASK_LOCK;
   retval = mn_close_packet(socket_ptr, send_size);
   MN_TASK_UNLOCK;
   if (retval <= 0)
      return ((int)retval);

   RESET_TCP_TIMER(socket_ptr);
   return ((int)socket_ptr->tcp_unacked_bytes);
}

/* abort the tcp connection */
void mn_tcp_abort(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   if (socket_ptr != PTR_NULL)
      {
      socket_ptr->tcp_state = TCP_CLOSED;
      socket_ptr->send_ptr = BYTE_PTR_NULL;
      socket_ptr->send_len = 0;
      socket_ptr->tcp_unacked_bytes = 0;
      }
}

/* Initiate a close. */
void mn_tcp_close(PSOCKET_INFO socket_ptr)
cmx_reentrant {

   if (socket_ptr != PTR_NULL)
      {
      socket_ptr->tcp_unacked_bytes = 0;
      socket_ptr->send_ptr = BYTE_PTR_NULL;
      socket_ptr->send_len = 0;
/*      if (socket_ptr->tcp_state < TCP_FIN_WAIT_1) */
      if ((socket_ptr->tcp_state == TCP_SYN_RECEIVED) \
          || (socket_ptr->tcp_state == TCP_ESTABLISHED) \
          || (socket_ptr->tcp_state == TCP_CLOSE_WAIT))
         {
         RESET_TCP_TIMER(socket_ptr);
         socket_ptr->tcp_state = TCP_FIN_WAIT_1;
         tcp_send_fin_ack(socket_ptr);
         }
      }
}

/* shutdown the tcp connection */
void mn_tcp_shutdown(PSOCKET_INFO socket_ptr)
cmx_reentrant {

   if (socket_ptr != PTR_NULL)
      {
      mn_tcp_close(socket_ptr);
      while (socket_ptr->tcp_state > TCP_CLOSED && \
            socket_ptr->tcp_state <= TCP_TIME_WAIT)
         tcp_recv_send(socket_ptr);
      }
}

/* ----------------------------------------------------------------------- */
/* does a recv then a send, called from mn_tcp_open and mn_tcp_shutdown */
static void tcp_recv_send(PSOCKET_INFO socket_ptr)
cmx_reentrant {
#if (RTOS_USED == RTOS_NONE)
   byte packet_type;
   int recvd;

   recvd = 0;

   packet_type = mn_ip_recv();
   if (packet_type & TCP_TYPE)
      recvd = mn_tcp_recv(&socket_ptr);
#if UDP
   else if (packet_type & UDP_TYPE)
      {
      mn_udp_recv(&socket_ptr);
      return;
      }
#endif

   if (recvd != NEED_TO_LISTEN && socket_ptr != PTR_NULL)
      mn_tcp_send(socket_ptr);
#else
   int retval;

   retval = 0;

/*   if (MN_SIGNAL_WAIT(signal_socket[socket_ptr->socket_no],(SOCKET_WAIT_TICKS)) == \ */
   if (MN_SIGNAL_WAIT(signal_socket[socket_ptr->socket_no], 1) == \
            SIGNAL_SUCCESS)
      {
      MN_TASK_LOCK;
      retval = socket_ptr->last_return_value;
      MN_TASK_UNLOCK;
      }

   if (retval != NEED_TO_LISTEN)
      mn_tcp_send(socket_ptr);
#endif      /* (RTOS_USED == RTOS_NONE) */
}

/* Get a TCP header. return 1 if ok, 0 on error */
static byte tcp_recv_header(word32 *csum_ptr,word16 *TCPcsum_ptr,PSOCKET_INFO *psocket_ptr)
cmx_reentrant {
   word16 src_port, dest_port, recv_tcp_window;
   byte opt_len, recv_tcp_flag, data_offset;
   SEQNUM_U SEG_SEQ;
   SEQNUM_U SEG_ACK;
   PSOCKET_INFO socket_ptr;
   SCHAR socket_no;
   byte socket_type;
   byte socket_status;
   word32 csum;

   socket_status = SAME_SOCKET;

   /* other side's source port is our dest port and vice versa */
   dest_port = LSHIFT8(mn_recv_escaped_byte(TRUE));
   dest_port += (word16)(mn_recv_escaped_byte(TRUE));
   src_port = LSHIFT8(mn_recv_escaped_byte(TRUE));
   src_port += (word16)(mn_recv_escaped_byte(TRUE));

#if (CHAR_BIT == 8)
#if (MN_LITTLE_ENDIAN)
#if 1
   SEG_SEQ.NUMC[3] = mn_recv_escaped_byte(TRUE);
   SEG_SEQ.NUMC[2] = mn_recv_escaped_byte(TRUE);
   SEG_SEQ.NUMC[1] = mn_recv_escaped_byte(TRUE);
   SEG_SEQ.NUMC[0] = mn_recv_escaped_byte(TRUE);

   SEG_ACK.NUMC[3] = mn_recv_escaped_byte(TRUE);
   SEG_ACK.NUMC[2] = mn_recv_escaped_byte(TRUE);
   SEG_ACK.NUMC[1] = mn_recv_escaped_byte(TRUE);
   SEG_ACK.NUMC[0] = mn_recv_escaped_byte(TRUE);
#else
   /* Some older compilers may not break down the above code properly.
      If this is the case then use the code below instead.
   */
   SEG_SEQ.NUMW[1] = LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMW[1] += (word16)(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMW[0] = LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMW[0] += (word16)(mn_recv_escaped_byte(TRUE));
         
   SEG_ACK.NUMW[1] = LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMW[1] += (word16)(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMW[0] = LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMW[0] += (word16)(mn_recv_escaped_byte(TRUE));
#endif      /* 1 */
#else       /* big-endian */
   SEG_SEQ.NUMC[0] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMC[1] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMC[2] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUMC[3] = (byte)(mn_recv_escaped_byte(TRUE));

   SEG_ACK.NUMC[0] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMC[1] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMC[2] = (byte)(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUMC[3] = (byte)(mn_recv_escaped_byte(TRUE));
#endif      /* (MN_LITTLE_ENDIAN) */
#else
   /* special handling for processors with > 8 bit chars */
   SEG_SEQ.NUML  = WORD32_LSHIFT24(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUML += WORD32_LSHIFT16(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUML += WORD32_LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_SEQ.NUML += mn_recv_escaped_byte(TRUE);

   SEG_ACK.NUML  = WORD32_LSHIFT24(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUML += WORD32_LSHIFT16(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUML += WORD32_LSHIFT8(mn_recv_escaped_byte(TRUE));
   SEG_ACK.NUML += mn_recv_escaped_byte(TRUE);
#endif      /* (CHAR_BIT == 8) */

#if (CHAR_BIT <= 16)
   csum =  SEG_SEQ.NUMW[0];
   csum += SEG_SEQ.NUMW[1];
   csum += SEG_ACK.NUMW[0];
   csum += SEG_ACK.NUMW[1];
#else
   csum  = LOWWORD(SEG_SEQ.NUML);
   csum += HIGHWORD(SEG_SEQ.NUML);
   csum += LOWWORD(SEG_ACK.NUML);
   csum += HIGHWORD(SEG_ACK.NUML);
#endif

   data_offset = (byte)(mn_recv_escaped_byte(TRUE));
   recv_tcp_flag = (byte)(mn_recv_escaped_byte(TRUE));
   csum += MK_WORD16(data_offset,recv_tcp_flag);

   data_offset &= 0xF0;                      /* get just the offset */
   data_offset = (byte)(data_offset >> 2);   /* calculate number of bytes. */

   if (ip_recv_len < data_offset || data_offset < (TCP_HEADER_LEN - 2))
      {
      *psocket_ptr = PTR_NULL;
      return (0);
      }

   ip_recv_len -= (word16)data_offset;    /* subtract it from total length */

   recv_tcp_window = LSHIFT8(mn_recv_escaped_byte(TRUE));
   recv_tcp_window += (word16)(mn_recv_escaped_byte(TRUE));
   csum += recv_tcp_window;
   *TCPcsum_ptr = LSHIFT8(mn_recv_escaped_byte(TRUE));
   *TCPcsum_ptr += (word16)(mn_recv_escaped_byte(TRUE));

   /* Skip over urgent pointer and options. Should be even number. */
   opt_len = (byte)(data_offset - (TCP_HEADER_LEN - 2));

   do {
      csum += LSHIFT8(mn_recv_escaped_byte(TRUE));
      csum += (word16)mn_recv_escaped_byte(TRUE);
      opt_len -= 2;
      }
   while (opt_len);

   *csum_ptr = csum;

   /* check what socket the packet goes to. check active open first. */
   socket_ptr = mn_find_socket(src_port, dest_port, recv_src_addr, PROTO_TCP);
   if (socket_ptr == PTR_NULL)
      {
      /* socket not found, check for passive open (socket_ptr->dest_port == 0) */
      socket_ptr = mn_find_socket(src_port, 0, recv_src_addr, PROTO_TCP);
      if (socket_ptr == PTR_NULL)
         socket_ptr = mn_find_socket(src_port, 0, null_addr, PROTO_TCP);
      if (socket_ptr != PTR_NULL && recv_tcp_flag & TCP_SYN)
         {
         /* socket found */
         socket_ptr->dest_port = dest_port;
         socket_status = NEW_SOCKET;
         }
      else
         {
         /* socket not found, open a new one with the same type as the
            incoming one.
         */
         if (recv_tcp_flag & TCP_RST)
            {
            /* we got a reset for a socket that wasn't open, so just toss it.
            */
            *psocket_ptr = (PSOCKET_INFO)PTR_NULL;
            return (0);
            }
         socket_type = mn_get_socket_type(src_port);
         socket_no = mn_open_socket(recv_src_addr,src_port,dest_port,\
            PROTO_TCP,socket_type,0,0);
         if (socket_no < 0)
            {
            /* couldn't open a socket, so just toss it.
            */
            *psocket_ptr = (PSOCKET_INFO)PTR_NULL;
            return (0);
            }
         else
            {
            socket_ptr = MK_SOCKET_PTR(socket_no);
#if (HTTP && RTOS_USED == RTOS_NONE)
            /* only allow automatic open of sockets for HTTP */
            if (recv_tcp_flag & TCP_SYN && src_port == HTTP_PORT)
               {
               /* can only open a new HTTP socket if we are done parsing
                  the HTTP header of the previous packet.
               */
               if (http_parse == HTTP_START)
                  socket_status = NEW_SOCKET;
               else
                  {
                  mn_abort(socket_no);
                  *psocket_ptr = (PSOCKET_INFO)PTR_NULL;
                  return (0);
                  }
               }
            else
#endif
#if (FTP && RTOS_USED == RTOS_NONE)
            if (recv_tcp_flag & TCP_SYN && src_port == FTP_CONTROL_PORT)
               socket_status = NEW_SOCKET;
            else
#endif      /* (FTP) */
               {
               /* set up so mn_tcp_recv will send a reset */
               socket_ptr->tcp_state = TCP_CLOSED;
/*               socket_ptr->RCV_NXT.NUML = SEG_SEQ.NUML + (ip_recv_len ? ip_recv_len : 1); */
               if (ip_recv_len)
                  socket_ptr->RCV_NXT.NUML = SEG_SEQ.NUML + ip_recv_len;
               else
                  socket_ptr->RCV_NXT.NUML = SEG_SEQ.NUML + 1;
               socket_ptr->socket_type = AUTO_TYPE;
               }
            }
         }
      }

   *psocket_ptr = socket_ptr;

#if (SOCKET_INACTIVITY_TIME)
   /* We got a packet for the socket so reset the inactivity timer if
      required.
   */
   mn_reset_inactivity_timer(socket_ptr);
#endif      /* (SOCKET_INACTIVITY_TIME) */

   socket_ptr->recv_tcp_flag = recv_tcp_flag;
   socket_ptr->tcp_flag = recv_tcp_flag;
   socket_ptr->recv_tcp_window = recv_tcp_window;
   socket_ptr->data_offset = data_offset;
   socket_ptr->SEG_SEQ.NUML = SEG_SEQ.NUML;
   socket_ptr->SEG_ACK.NUML = SEG_ACK.NUML;
   if (socket_status == NEW_SOCKET)
      socket_ptr->tcp_state = TCP_LISTEN;

#if (ETHERNET && !ARP)
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
   (void)memcpy((void *)socket_ptr->eth_dest_hw_addr,(void *)eth_dest_hw_addr,\
      ETH_ADDR_LEN);
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif

   if (socket_ptr->ip_dest_addr[0] == 0)
      {
      socket_ptr->ip_dest_addr[0] = recv_src_addr[0];
      socket_ptr->ip_dest_addr[1] = recv_src_addr[1];
      socket_ptr->ip_dest_addr[2] = recv_src_addr[2];
      socket_ptr->ip_dest_addr[3] = recv_src_addr[3];
      }

   return(1);
}

/* Compute checksum and send a TCP Header. Returns 1 if able to
   send packet, otherwise returns a negative number.
*/
static SCHAR tcp_send_header(PSOCKET_INFO socket_ptr)
cmx_reentrant {
#if (CHAR_BIT == 8)
   SCHAR i;           /* must be a signed char */
#endif      /* (CHAR_BIT == 8) */
   word32 csum;
   word16 tcp_csum;
   byte offset;
   word16 tcp_pkt_len;
   byte tcp_flag;
   SCHAR retval;

#define USE_MSS   1  /* set to 1 to add MSS option to header if a SYN packet */

   tcp_flag = socket_ptr->tcp_flag;
   tcp_pkt_len = socket_ptr->tcp_unacked_bytes;
#if (USE_MSS)  /* include this code to send MSS option with SYN packets */
   if (tcp_flag & TCP_SYN)
      {
      /* add MSS option to header if a SYN packet */
      tcp_pkt_len += TCP_OPT_HEADER_LEN;
      offset = TCP_OPT_OFFSET;
      csum = CSUM_WORD16(TCP_OPT_KIND_MSS,TCP_OPT_LEN_MSS);
      csum += TCP_WINDOW;  /* set MSS to TCP_WINDOW */
      }
   else
#endif
      {
      tcp_pkt_len += TCP_HEADER_LEN;
      offset = TCP_STD_OFFSET;
      csum = 0;
      }
/* bww new call parameters */
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */
   csum += mn_udp_tcp_start_checksum(PROTO_TCP,tcp_pkt_len, \
            socket_ptr->src_port, socket_ptr->dest_port, ip_src_addr, \
            socket_ptr->ip_dest_addr);
#if (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP))
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING || !(ARP)) */

   /* finish checksum on header */
#if (CHAR_BIT == 8)
   csum += socket_ptr->SND_UNA.NUMW[0];
   csum += socket_ptr->SND_UNA.NUMW[1];
   csum += socket_ptr->RCV_NXT.NUMW[0];
   csum += socket_ptr->RCV_NXT.NUMW[1];
#else
   /* special handling for processors with > 8 bit chars */
   csum += LOWWORD(socket_ptr->SND_UNA.NUML);
   csum += HIGHWORD(socket_ptr->SND_UNA.NUML);
   csum += LOWWORD(socket_ptr->RCV_NXT.NUML);
   csum += HIGHWORD(socket_ptr->RCV_NXT.NUML);
#endif      /* (CHAR_BIT == 8) */

   csum += MK_WORD16(offset,tcp_flag);
   csum += TCP_WINDOW;
   /* checksum on data */
   csum = mn_data_send_checksum(csum, socket_ptr->send_ptr, socket_ptr->tcp_unacked_bytes);

   /* finish checksum */
   csum = mn_udp_tcp_end_checksum(csum);
   tcp_csum = (word16)csum;

   /* Send the IP header. */
   retval = mn_ip_send_header(socket_ptr,socket_ptr->ip_proto,tcp_pkt_len);
   if (retval != 1)
      return (retval);
   mn_send_escaped_byte(HIGHBYTE(socket_ptr->src_port),TRUE);
   mn_send_escaped_byte(LOWBYTE(socket_ptr->src_port),TRUE);
   mn_send_escaped_byte(HIGHBYTE(socket_ptr->dest_port),TRUE);
   mn_send_escaped_byte(LOWBYTE(socket_ptr->dest_port),TRUE);
#if (CHAR_BIT == 8)
#if MN_LITTLE_ENDIAN
   for (i=3;i>=0;i--)
#else
   for (i=0;i<4;i++)
#endif
      mn_send_escaped_byte(socket_ptr->SND_UNA.NUMC[i],TRUE);
#if MN_LITTLE_ENDIAN
   for (i=3;i>=0;i--)
#else
   for (i=0;i<4;i++)
#endif
      mn_send_escaped_byte(socket_ptr->RCV_NXT.NUMC[i],TRUE);
#else
   /* special handling for processors with > 8 bit chars */
   mn_send_escaped_byte(WORD32_BYTE3(socket_ptr->SND_UNA.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE2(socket_ptr->SND_UNA.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE1(socket_ptr->SND_UNA.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE0(socket_ptr->SND_UNA.NUML),TRUE);

   mn_send_escaped_byte(WORD32_BYTE3(socket_ptr->RCV_NXT.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE2(socket_ptr->RCV_NXT.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE1(socket_ptr->RCV_NXT.NUML),TRUE);
   mn_send_escaped_byte(WORD32_BYTE0(socket_ptr->RCV_NXT.NUML),TRUE);
#endif      /* (CHAR_BIT == 8) */

   mn_send_escaped_byte(offset,TRUE);
   mn_send_escaped_byte(tcp_flag,TRUE);
   mn_send_escaped_byte(HIGHBYTE(TCP_WINDOW),TRUE);
   mn_send_escaped_byte(LOWBYTE(TCP_WINDOW),TRUE);
   mn_send_escaped_byte(HIGHBYTE(tcp_csum),TRUE);
   mn_send_escaped_byte(LOWBYTE(tcp_csum),TRUE);
   mn_send_escaped_byte(0,TRUE);    /* urgent pointer high byte */
   mn_send_escaped_byte(0,TRUE);    /* urgent pointer low byte */
#if (USE_MSS)  /* include this code to send MSS option with SYN packets */
   if (tcp_flag & TCP_SYN)
      {
      /* add MSS option to header if a SYN packet */
      mn_send_escaped_byte(TCP_OPT_KIND_MSS,TRUE);
      mn_send_escaped_byte(TCP_OPT_LEN_MSS,TRUE);
      mn_send_escaped_byte(TCP_OPT_MSS_HB,TRUE);
      mn_send_escaped_byte(TCP_OPT_MSS_LB,TRUE);
      }
#endif
   return (1);
}

/* update sequence and acknowledgement numbers */
static void tcp_update_ack(word16 data_len, PSOCKET_INFO socket_ptr)
cmx_reentrant {
   socket_ptr->SND_UNA.NUML = socket_ptr->SEG_ACK.NUML;
   /* Add the length of the received packet to the ACK. */
   socket_ptr->RCV_NXT.NUML = socket_ptr->SEG_SEQ.NUML + data_len;
}

static SCHAR tcp_send_nodata_hdr(PSOCKET_INFO socket_ptr, byte tcp_flag)
cmx_reentrant {
   socket_ptr->tcp_flag = tcp_flag;
   socket_ptr->send_ptr = PTR_NULL;
   socket_ptr->send_len = 0;
   socket_ptr->tcp_unacked_bytes = 0;

   return (tcp_send_header(socket_ptr));
}

/* Send a TCP packet without any data. returns positive number if able to
   send the packet otherwise returns a negative number.
*/
static SCHAR tcp_send_nodata_pkt(PSOCKET_INFO socket_ptr, byte tcp_flag)
cmx_reentrant {
   SCHAR retval;

   retval = tcp_send_nodata_hdr(socket_ptr,tcp_flag);
   if (retval == 1)
      {
      MN_TASK_LOCK;
      retval = mn_close_packet(socket_ptr, 0);
      MN_TASK_UNLOCK;
      }

   return (retval);
}

/* called from tcp_send_syn_ack & tcp_send_syn to finish sending packet.
   returns positive number if able to send the packet otherwise returns
   a negative number.
*/
static SCHAR tcp_send_syn_close(PSOCKET_INFO socket_ptr, byte tcp_flag)
cmx_reentrant {
   SCHAR retval;

#if 0
   /* Set the above to 1 if running against a Cisco router. */
   if (socket_ptr->tcp_resends == TCP_RESEND_TRYS && tcp_flag == TCP_SYN_ACK)
#else
   if (socket_ptr->tcp_resends == TCP_RESEND_TRYS)
#endif
      socket_ptr->RCV_NXT.NUML++;
   retval = tcp_send_nodata_hdr(socket_ptr,tcp_flag);
   if (retval == 1)
      {
      MN_TASK_LOCK;
      retval = mn_close_packet(socket_ptr, 0);
      if (retval > 0)
         {
         RESET_TCP_TIMER(socket_ptr);
         socket_ptr->SND_UNA.NUML++;
         }
      MN_TASK_UNLOCK;
      }

   return (retval);
}

/* Send an ACK packet */
static SCHAR tcp_send_ack(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   byte *send_ptr;
   word16 send_len;
   word16 tcp_unacked_bytes;
   SCHAR retval;

   /* save original values and restore afterwards */
   send_ptr = socket_ptr->send_ptr;
   send_len = socket_ptr->send_len;
   tcp_unacked_bytes = socket_ptr->tcp_unacked_bytes;

   retval = tcp_send_nodata_hdr(socket_ptr,TCP_ACK);
   MN_TASK_LOCK;
   if (retval == 1)
      retval = mn_close_packet(socket_ptr, 0);
   socket_ptr->tcp_resends = TCP_RESEND_TRYS;
   socket_ptr->send_ptr = send_ptr;
   socket_ptr->send_len = send_len;
   socket_ptr->tcp_unacked_bytes = tcp_unacked_bytes;
   MN_TASK_UNLOCK;

   return (retval);
}

/* Send a reset packet */
static SCHAR tcp_send_reset(PSOCKET_INFO socket_ptr)
cmx_reentrant {
   byte tcp_flag;

   socket_ptr->SND_UNA.NUML = socket_ptr->SEG_ACK.NUML;

/*   tcp_flag = socket_ptr->recv_tcp_flag == TCP_SYN ? (TCP_RST|TCP_ACK) : TCP_RST; */
   if (socket_ptr->recv_tcp_flag == TCP_SYN)
      tcp_flag = (byte)(TCP_RST|TCP_ACK);
   else
      tcp_flag = (byte)(TCP_RST);
   return (tcp_send_nodata_pkt(socket_ptr,tcp_flag));
}

#endif   /* TCP */
