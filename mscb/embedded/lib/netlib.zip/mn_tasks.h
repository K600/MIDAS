/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MN_TASKS_H_INC
#define MN_TASKS_H_INC 1

byte mn_os_init(void) cmx_reentrant;

#if (RTOS_USED == RTOS_CMX_RTX || RTOS_USED == RTOS_CMX_TINYP)
byte mn_alloc_mutex(MUTEX_NUM_T *) cmx_reentrant;
byte mn_alloc_signal(SIGNAL_NUM_T *, word16) cmx_reentrant;
#endif      /* (RTOS_USED == RTOS_CMX_RTX || RTOS_USED == RTOS_CMX_TINYP) */

#if (RTOS_USED == RTOS_CMX_TINYP)
byte mn_get_rom_id(CMX_FP) cmx_reentrant;
#endif      /* (RTOS_USED == RTOS_CMX_TINYP) */

#if (RTOS_USED != RTOS_NONE)
void mn_receive_task(void) cmx_reentrant;
#if (PING)
void mn_ping_reply_task(void) cmx_reentrant;
#endif      /* (PING) */
#if (IGMP)
void mn_igmp_timer_task(void) cmx_reentrant;
#endif      /* (IGMP) */
#if (DHCP || (ARP && ARP_TIMEOUT) || SOCKET_INACTIVITY_TIME)
void mn_timer_update_task(void) cmx_reentrant;
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (DHCP)
void mn_dhcp_lease_task(void) cmx_reentrant;
#endif      /* (DHCP) */
#if (FTP & FTP_SERVER)
void mn_ftp_server_task(void) cmx_reentrant;
#endif      /* (FTP && FTP_SERVER) */
#if (HTTP)
void mn_http_server_task(void) cmx_reentrant;
#endif      /* (HTTP) */
#endif      /* (RTOS_USED != RTOS_NONE) */

#endif      /* #ifndef MN_TASKS_H_INC */
