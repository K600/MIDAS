/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MNSERVER_H_INC
#define MNSERVER_H_INC   1

int mn_server(void) cmx_reentrant;

#endif   /* #ifndef MNSERVER_H_INC */


