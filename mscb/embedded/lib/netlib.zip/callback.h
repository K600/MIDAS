/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef CALLBACK_H_INC
#define CALLBACK_H_INC  1

word16 mn_app_get_send_size(PSOCKET_INFO) cmx_reentrant;
void mn_app_init_recv(word16,PSOCKET_INFO) cmx_reentrant;
void mn_app_recv_byte(byte,PSOCKET_INFO) cmx_reentrant;
SCHAR mn_app_process_packet(PSOCKET_INFO) cmx_reentrant;
#if TCP
void mn_app_send_complete(word16,PSOCKET_INFO) cmx_reentrant;
#endif   /* #if TCP */
SCHAR mn_app_server_idle(PSOCKET_INFO *) cmx_reentrant;
#if (RTOS_USED == RTOS_NONE)
SCHAR mn_app_recv_idle(void) cmx_reentrant;
SCHAR mn_app_server_process_packet(PSOCKET_INFO) cmx_reentrant;
#endif      /* (RTOS_USED == RTOS_NONE) */

#endif   /* #ifndef CALLBACK_H_INC */


