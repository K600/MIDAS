/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MNEXTERN_H_INC
#define MNEXTERN_H_INC  1

/* mn_os.c */
#if (RTOS_USED == RTOS_CMX_RTX)
extern TASKID_T mn_receive_id;
#if (PING)
extern TASKID_T mn_ping_reply_id;
#endif      /* (PING) */
#if (IGMP)
extern TASKID_T mn_igmp_timer_id;
#endif      /* (IGMP) */
#if (DHCP || (ARP && ARP_TIMEOUT))
extern TASKID_T mn_timer_update_id;
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (DHCP)
extern TASKID_T mn_dhcp_lease_id;
#endif      /* (DHCP) */
#if (FTP & FTP_SERVER)
extern TASKID_T mn_ftp_server_id;
#endif      /* (FTP && FTP_SERVER) */
#if (HTTP)
extern TASKID_T mn_http_server_id;
#endif      /* (HTTP) */
#endif      /* (RTOS_USED == RTOS_CMX_RTX) */
#if (RTOS_USED == RTOS_CMX_RTX || RTOS_USED == RTOS_CMX_TINYP)
extern MUTEX_NUM_T mutex_ip_receive;
extern MUTEX_NUM_T mutex_ip_send;
extern MUTEX_NUM_T mutex_mn_info;
#if (PING)
extern MUTEX_NUM_T mutex_ping_buff;
#endif      /* (PING) */
#if (IGMP)
extern MUTEX_NUM_T mutex_igmp;
#endif      /* (IGMP) */
#if (PPP)
extern MUTEX_NUM_T mutex_ppp;
#endif      /* (PPP) */
#if (ETHERNET && ARP)
extern MUTEX_NUM_T mutex_arp_cache;
#endif      /* (ETHERNET && ARP) */
#if (DHCP || BOOTP)
extern MUTEX_NUM_T mutex_bootp_dhcp;
#endif      /* (DHCP || BOOTP) */
#if (TFTP)
extern MUTEX_NUM_T mutex_tftp;
#endif      /* (TFTP) */
#if (SMTP)
extern MUTEX_NUM_T mutex_smtp;
#endif      /* (SMTP) */

#if (VIRTUAL_FILE)
extern MUTEX_NUM_T mutex_vfs_dir;
#if (HTTP)
#if (NUM_POST_FUNCS)
extern MUTEX_NUM_T mutex_vfs_pf;
#endif      /* (NUM_POST_FUNCS) */
#if (SERVER_SIDE_INCLUDES)
extern MUTEX_NUM_T mutex_vfs_gf;
#endif      /* (SERVER_SIDE_INCLUDES) */
#endif      /* (HTTP) */
#endif      /* (VIRTUAL_FILE) */

#if (FTP & FTP_SERVER)
extern MUTEX_NUM_T mutex_ftp_server;
#endif      /* (FTP && FTP_SERVER) */

#if (HTTP)
extern MUTEX_NUM_T mutex_http_server;
#endif      /* (HTTP) */

extern SIGNAL_NUM_T signal_transmit;
extern SIGNAL_NUM_T signal_receive;
extern SIGNAL_NUM_T signal_socket[NUM_SOCKETS];
#if (PING)
extern SIGNAL_NUM_T signal_ping_reply;
#endif      /* (PING) */
#if (IGMP)
extern SIGNAL_NUM_T signal_igmp;
#endif      /* (IGMP) */
#if (DHCP || (ARP && ARP_TIMEOUT))
extern SIGNAL_NUM_T signal_timer_update;
#endif      /* (DHCP || (ARP && ARP_TIMEOUT)) */
#if (PPP)
extern SIGNAL_NUM_T signal_ppp;
#endif      /* (PPP) */
#if (MODEM)
extern SIGNAL_NUM_T signal_modem;
#endif      /* (MODEM) */
#endif      /* (RTOS_USED == RTOS_CMX_RTX || RTOS_USED == RTOS_CMX_TINYP) */

/* mn_port.c */
#if (USE_RECV_BUFF)
extern byte recv_buff[RECV_BUFF_SIZE];
#endif      /* (USE_RECV_BUFF) */
#if (USE_SEND_BUFF)
extern byte send_buff[XMIT_BUFF_SIZE];
#endif      /* (USE_SEND_BUFF) */
#if (USE_RECV_BUFF)
extern byte *volatile recv_in_ptr;
extern byte *recv_out_ptr;
extern volatile RECV_COUNT_T recv_count;
#endif      /* (USE_RECV_BUFF) */
extern byte *volatile send_out_ptr;
extern byte *send_in_ptr;
#if (!(ETHERNET))
extern byte *send_end_ptr;
#endif      /* (!(ETHERNET)) */
#if (RTOS_USED == RTOS_NONE || defined(CMXPIC18))
extern volatile byte xmit_busy;
#endif      /* (RTOS_USED == RTOS_NONE || defined(CMXPIC18)) */
extern volatile word16 uart_errors;
#if (RTOS_USED != RTOS_NONE)
#if (MODEM)
extern byte modem_mode;
#endif      /* (MODEM) */
#endif      /* (RTOS_USED != RTOS_NONE) */

/* callback.c */
extern byte ip_dest_addr[IP_ADDR_LEN];
extern byte ip_src_addr[IP_ADDR_LEN];
#if (SMTP)
extern byte ip_smtp_addr[IP_ADDR_LEN];
#endif      /* (SMTP) */
#if ETHERNET
extern byte eth_src_hw_addr[ETH_ADDR_LEN];
extern byte eth_dest_hw_addr[ETH_ADDR_LEN];
extern byte gateway_ip_addr[IP_ADDR_LEN];
extern byte subnet_mask[IP_ADDR_LEN];
extern char host_name[20]; //##SR
#endif

/* ip.c */
extern byte recv_src_addr[IP_ADDR_LEN];
extern byte recv_dest_addr[IP_ADDR_LEN];
extern word16 ip_recv_len;
extern byte null_addr[IP_ADDR_LEN];
#if (DHCP || BOOTP || ALLOW_BROADCAST)
extern byte broadcast_addr[IP_ADDR_LEN];
#endif      /* (DHCP || BOOTP || ALLOW_BROADCAST) */
#if (ALLOW_MULTICAST)
extern byte all_hosts_addr[IP_ADDR_LEN];
#endif      /* (ALLOW_MULTICAST) */

/* socket.c */
extern SOCKET_INFO_T sock_info[NUM_SOCKETS];

#if (IGMP)
/* igmp.c */
extern IGMP_INFO_T igmp_info[IGMP_LIST_SIZE];
#endif      /* (IGMP) */

#if DHCP
extern DHCP_INFO_T dhcp_info;
extern DHCP_LEASE_T dhcp_lease;
#endif      /* DHCP */

#if (BOOTP || DHCP)
extern SCHAR bootpMode;
#endif      /* (BOOTP || DHCP) */

#if PPP
extern PPPSTATUS_T ppp_status;
#if USE_PAP
extern PAP_USER_T pap_user[PAP_NUM_USERS];
#endif      /* USE_PAP */
#endif      /* PPP */

#if HTTP
extern byte *URIptr;
extern byte *BODYptr;
extern VF_PTR http_vf_ptrs[NUM_SOCKETS];
extern byte http_parse;
extern cmx_const byte HTTPStatus204[];
extern cmx_const byte HTTPStatus400[];
extern cmx_const byte HTTPStatus404[];
extern cmx_const byte HTTPStatus501[];
#endif

#if (FTP)
extern byte ftp_transfer_mode;
#endif      /* (FTP) */

#if NEED_MEM_POOL
extern byte mem_pool[MEM_POOL_SIZE];
#endif      /* NEED_MEM_POOL */

#endif   /* #ifndef MNEXTERN_H_INC */
