/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

#if (!ETHERNET)
/* Send a byte to the xmit buffer. Adds to FCS if doFCS is true. */
void mn_send_escaped_byte(byte c, byte doFCS)
cmx_reentrant {
#if PPP
   if (doFCS)
      mn_ppp_fcs_accum(c, SEND_FCS);

   if (c < 0x20 || c == PPP_FRAME || c == PPP_ESC)
      {  
      mn_send_byte(PPP_ESC);
      mn_send_byte((byte)(c ^ PPP_COMPLEMENT));
      }
   else
      mn_send_byte(c);
#elif SLIP
   doFCS=doFCS;                           /* keep compiler happy */

   switch (c)
      {
      case SLIP_END:
         mn_send_byte(SLIP_ESC);
         mn_send_byte(SLIP_ESC_END);
         break;
      case SLIP_ESC:
         mn_send_byte(SLIP_ESC);
         mn_send_byte(SLIP_ESC_ESC);
         break;
      default:
         mn_send_byte(c);
         break;
      }
#endif
}

/* get a byte from the recv buffer, converting escaped chars if needed */
byte mn_recv_escaped_byte(byte doFCS)
cmx_reentrant {
   byte thisChar;
   int ret;

   ret = mn_recv_byte();
   if (ret == RECV_TIMED_OUT)
      return 0;
   else
      thisChar = (byte)ret;

#if PPP
   if (thisChar == PPP_ESC)
      {
      ret = mn_recv_byte();
      if (ret == RECV_TIMED_OUT)
         return 0;
      else
         thisChar = (byte)(((byte)ret) ^ PPP_COMPLEMENT);
      }
   if (doFCS)
      mn_ppp_fcs_accum(thisChar, RECV_FCS);
#elif SLIP
   doFCS = doFCS;

   if (thisChar == SLIP_ESC)
      {
      ret = mn_recv_byte();
      if (ret == RECV_TIMED_OUT)
         return 0;
      else
         {
/*         thisChar = ((byte)ret) == SLIP_ESC_END ? SLIP_END : SLIP_ESC; */
         if (ret == SLIP_ESC_END)
            thisChar = SLIP_END;
         else
            thisChar = SLIP_ESC;
         }
      }
#endif
   return(thisChar);
}
#endif      /* (!ETHERNET) */

/* put a byte in the xmit buffer */
void mn_send_byte(byte c)
cmx_reentrant {
#if (!ETHERNET)
   /* for ethernet we calculate in advance whether the packet will fit
      into the transmit buffer.
   */
   if (send_in_ptr <= send_end_ptr)
#endif      /* (!ETHERNET) */
      {
      *send_in_ptr = c;
      ++send_in_ptr;
      }
}

#if (USE_RECV_BUFF)
/* get a byte from the recv buffer, blocking temporarily if neccessary.
   for ethernet assume we will always have a full packet.
*/
int mn_recv_byte(void)
cmx_reentrant {
   byte c;

#if (!ETHERNET)
   byte have_char;
   TIMER_INFO_T wait_timer;

   have_char = FALSE;

   if (mn_recv_byte_present())      /* we got a char */
         have_char = TRUE;
   else
      {
      mn_reset_timer(&wait_timer,(SOCKET_WAIT_TICKS));
      /* check if we have a character, if not, wait for a few seconds */
      while (!mn_timer_expired(&wait_timer))
         {
         if (mn_recv_byte_present())      /* we got a char */
            {
            have_char = TRUE;
            break;
            }
#if (RTOS_USED != RTOS_NONE)
         MN_TASK_WAIT(1);
#endif      /* (RTOS_USED != RTOS_NONE) */
         }
      }

   if (have_char)
#endif      /* (!ETHERNET) */
      {
      c = *recv_out_ptr;
#if (RECV_COUNT_ATOMIC == 0)
      DISABLE_INTERRUPTS;
#endif
      --recv_count;
#if (RECV_COUNT_ATOMIC == 0)
      ENABLE_INTERRUPTS;
#endif
      ++recv_out_ptr;
      if (recv_out_ptr > &recv_buff[RECV_BUFF_SIZE-1])
         recv_out_ptr = &recv_buff[0];
      return ((int)c);
      }
#if (!ETHERNET)
   else
      return (RECV_TIMED_OUT);
#endif      /* (!ETHERNET) */
}
#endif      /* (USE_RECV_BUFF) */

#if (USE_RECV_BUFF)
#if (!(READ_RECV_COUNT_ATOMIC || (ETHERNET && POLLED_ETHERNET)))
byte mn_recv_byte_present(void)
cmx_reentrant {
   byte retval;

   DISABLE_INTERRUPTS;
   /* Anything in the receive buffer? */
   if (recv_count > 0)
      retval = TRUE;
   else
      retval = FALSE;
   ENABLE_INTERRUPTS;

   return (retval);
}
#endif   /* (!(READ_RECV_COUNT_ATOMIC || (ETHERNET && POLLED_ETHERNET))) */
#endif      /* (USE_RECV_BUFF) */
