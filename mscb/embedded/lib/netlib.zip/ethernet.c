/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

#if ETHERNET

static void sendHWAddr(PSOCKET_INFO, byte) cmx_reentrant;
#if ARP
static byte same_net_number(byte *ip_addr1,byte *ip_addr2) cmx_reentrant;
#endif      /* ARP */

/********************************************************************/

int mn_ether_init(void)
cmx_reentrant {

   DISABLE_INTERRUPTS;
   init_io_buffs();
   ENABLE_INTERRUPTS;

   return (ETHER_INIT);       /* macro defined in ethernet.h */
}

/* Processes the ethernet header, handling ARP calls if necessary. Returns 1
   if the packet is an IP packet, returns 0 if arp packet, otherwise returns
   -1.
*/
SCHAR ether_recv_header(void)
cmx_reentrant {
   byte eth_type_hb, eth_type_lb;
   byte i;
   SCHAR retval;
#if (!ARP)
   byte isBcast;

   isBcast = TRUE;
#endif      /* (!ARP) */

   retval = -1;

#if DHCP
   if (dhcp_lease.dhcp_state != DHCP_DEAD)
      {
#endif      /* DHCP */

      /* ethernet header format:

         dest hw addr (6 bytes), source hw addr (6 bytes)

         the next two bytes are 0x0800 for IP and 0x0806 for ARP. There
         are other possiblities but we ignore them for now.
      */
      for (i=0;i<ETH_ADDR_LEN;i++)
         {
#if (!ARP)
         if ( mn_recv_byte() != 0xff )
            isBcast = FALSE;
#else
         (void)mn_recv_byte();
#endif      /* (!ARP) */
         }

      /* The CS8900 does the filtering for us so we know the addr is ok if
         we get here. This may need to change for other ethernet chips.
      */


      /* save the hw addr for use later */
      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
      for (i=0;i<ETH_ADDR_LEN;i++)
         eth_dest_hw_addr[i] = (byte)mn_recv_byte();
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);

      /* check type for IP, ARP or unknown */
      eth_type_hb = (byte)mn_recv_byte();
      eth_type_lb = (byte)mn_recv_byte();

      if (eth_type_hb == ETH_TYPE_HB)
         {
         switch (eth_type_lb)
            {
            case ETH_IP_LB:                /* IP */
               retval = 1;
               break;
            case ETH_ARP_LB:               /* ARP */
#if (BOOTP || DHCP)
               /* we can't process ARP packets if in bootp mode */
               if (bootpMode != BOOTP_ACTIVE)
#endif      /* (BOOTP || DHCP) */
                  {
#if (!ARP)
                  if (isBcast)
                     {
#endif      /* (!ARP) */
                     /* handle ARP packet */
                     retval = mn_arp_process_packet();            
#if (!ARP)
                     }
#endif      /* (!ARP) */
                  }
               break;
            default:                /* unknown type */
               break;
            }
         }
   
      /* need to discard the rest of the packet if no further processing */
      if (retval <= 0)
         mn_ip_discard_packet();

#if DHCP
      }
#endif      /* DHCP */

   return (retval);
}

/* returns 1 if able to start the packet, otherwise returns a negative number.
*/
SCHAR mn_ether_start_packet(PSOCKET_INFO socket_ptr,word16 eth_type,byte isBcast)
cmx_reentrant {
#if ARP
   PARP_INFO parp;
#endif      /* ARP */
#if (ARP || ALLOW_BROADCAST)
   byte i;
#endif      /* (ARP || ALLOW_BROADCAST) */

   if (socket_ptr == PTR_NULL)
      return (BAD_SOCKET_DATA);

#if DHCP
   if (dhcp_lease.dhcp_state == DHCP_DEAD)
      return (DHCP_LEASE_EXPIRED);
#endif      /* DHCP */

   switch (eth_type)
      {
      case ETH_IP_TYPE:             /* IP */
#if (ALLOW_MULTICAST)
         if (socket_ptr->socket_type & MULTICAST_TYPE)
            {
            /* make hw address for the multicast address */
            socket_ptr->eth_dest_hw_addr[0] = 0x01;
            socket_ptr->eth_dest_hw_addr[1] = 0x00;
            socket_ptr->eth_dest_hw_addr[2] = 0x5E;
            socket_ptr->eth_dest_hw_addr[3] = (byte)(socket_ptr->ip_dest_addr[1] & 0x7F);
            socket_ptr->eth_dest_hw_addr[4] = socket_ptr->ip_dest_addr[2];
            socket_ptr->eth_dest_hw_addr[5] = socket_ptr->ip_dest_addr[3];
            }
         else
#endif      /* (ALLOW_MULTICAST) */
            {
#if (ALLOW_BROADCAST)
            if (!isBcast)
               {
               /* Check for broadcast address */
               for (i=0; i<IP_ADDR_LEN; i++)
                  {
                  if (socket_ptr->ip_dest_addr[i] == 255)
                     {
                     isBcast = TRUE;
                     break;
                     }
                  }
               }
#endif      /* (ALLOW_BROADCAST) */

#if ARP
            if (!isBcast)
               {
               /* do arp lookup, sending an ARP request if neccessary.
                  if the destination is not local and we are using a gateway
                  then use the gateway hardware address.
               */
#if (DHCP || BOOTP || PING_GLEANING)
               MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (DHCP || BOOTP || PING_GLEANING) */
               if ( gateway_ip_addr[0] == 255 || gateway_ip_addr[0] == 0 || \
                     same_net_number(socket_ptr->ip_dest_addr, ip_src_addr) )
                  {
#if (DHCP || BOOTP || PING_GLEANING)
                  MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (DHCP || BOOTP || PING_GLEANING) */
                  parp = mn_arp_lookup(socket_ptr->ip_dest_addr);
                  }
               else
                  {
#if (DHCP || BOOTP || PING_GLEANING)
                  MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (DHCP || BOOTP || PING_GLEANING) */
                  parp = mn_arp_lookup(gateway_ip_addr);
                  }

               if (parp != PTR_NULL)
                  {
                  /* update info */
                  for (i=0;i<ETH_ADDR_LEN;i++)
                     socket_ptr->eth_dest_hw_addr[i] = parp->eth_dest_hw_addr[i];
                  }
               else
                  return (ARP_REQUEST_FAILED);               /* error */
               }
#endif      /* ARP */
            }

         if (!mn_transmit_ready())
            return (UNABLE_TO_SEND);

         sendHWAddr(socket_ptr,isBcast);
         /* send type */
         mn_send_byte(ETH_TYPE_HB);
         mn_send_byte(ETH_IP_LB);
         break;
      default:                /* unknown type */
         break;
      }

   return (1);
}

void start_arp_packet(PSOCKET_INFO socket_ptr,byte isBcast)
cmx_reentrant {
   if (socket_ptr != PTR_NULL)
      {
      sendHWAddr(socket_ptr,isBcast);
      mn_send_byte(ETH_TYPE_HB);          /* packet type */
      mn_send_byte(ETH_ARP_LB);
      mn_send_byte(ETHERNET_10MB_HB);     /* hardware type */
      mn_send_byte(ETHERNET_10MB_LB);
      mn_send_byte(ETH_TYPE_HB);          /* protocol space == IP */
      mn_send_byte(ETH_IP_LB);
      mn_send_byte(ETH_ADDR_LEN);         /* lengths */
      mn_send_byte(IP_ADDR_LEN);
      }
}

/* the next two functions are for use by ethernet drivers */

/* gets a byte to transmit from the xmit buffer. check to make sure that
   send_out_ptr != send_in_ptr before calling this function.
*/
byte mn_get_xmit_byte(void)
cmx_reentrant {
   byte c1;

   c1 = *send_out_ptr;
   ++send_out_ptr;

   return c1;
}

#if (USE_RECV_BUFF)
/* puts a byte into the recv buffer. make sure there is enough room first. */
void mn_put_recv_byte(byte c2)
cmx_reentrant {
   *recv_in_ptr = c2;
   ++recv_in_ptr;
   if (recv_in_ptr > &recv_buff[RECV_BUFF_SIZE-1])
      recv_in_ptr = &recv_buff[0];
#if 0    /* (RECV_COUNT_ATOMIC == 0) */
   DISABLE_INTERRUPTS;
#endif
   ++recv_count;
#if 0    /* (RECV_COUNT_ATOMIC == 0) */
   ENABLE_INTERRUPTS;
#endif
}
#endif      /* (USE_RECV_BUFF) */

/**********************************************************************/

/* put hardware addresses in xmit buffer */
static void sendHWAddr(PSOCKET_INFO socket_ptr,byte isBcast)
cmx_reentrant {
   byte i;

   if (socket_ptr != PTR_NULL)
      {
      if (isBcast)
         {
         for (i=0;i<ETH_ADDR_LEN;i++)
            mn_send_byte(0xff);
         }
      else
         {
         /* send dest hw address */
         for (i=0;i<ETH_ADDR_LEN;i++)
            mn_send_byte(socket_ptr->eth_dest_hw_addr[i]);
         }

      MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
      /* send src hw address */
      for (i=0;i<ETH_ADDR_LEN;i++)
         mn_send_byte(eth_src_hw_addr[i]);
      MN_MUTEX_RELEASE(MUTEX_MN_INFO);
      }
}

#if ARP
/* Returns TRUE if both IP addresses are on the same subnet. */
static byte same_net_number(byte *ip_addr1,byte *ip_addr2)
cmx_reentrant {
   word32 net_num, mask_num, num1, num2;
   byte retval;

   net_num = MK_WORD32(ip_addr1[0],ip_addr1[1],ip_addr1[2],ip_addr1[3]);
   mask_num = MK_WORD32(subnet_mask[0],subnet_mask[1],subnet_mask[2],\
      subnet_mask[3]);
   num1 = (net_num & mask_num);

   net_num = MK_WORD32(ip_addr2[0],ip_addr2[1],ip_addr2[2],ip_addr2[3]);
   num2 = (net_num & mask_num);

   if (num1 == num2)
      retval = TRUE;
   else
      retval = FALSE;

   return (retval);
}
#endif      /* ARP */

#endif   /* ETHERNET */


