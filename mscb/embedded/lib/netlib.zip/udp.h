/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef UDP_H_INC
#define UDP_H_INC 1

int mn_udp_send(PSOCKET_INFO) cmx_reentrant;
int mn_udp_recv(PSOCKET_INFO *) cmx_reentrant;

#define UDP_HEADER_LEN   8

#endif   /* #ifndef UDP_H_INC */
