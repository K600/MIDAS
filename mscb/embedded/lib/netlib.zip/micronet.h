/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MICRONET_H_INC
#define MICRONET_H_INC  1

#define POL8051      //## SR
#define iPS_ETH8_100_RDWR ((volatile unsigned char xdata*)0xC000)

/*********************************************************/
/* do not change anything in this section */
/*********************************************************/
#include "mnconfig.h"      /* must be #included first */

#include <stdlib.h>
#include <string.h>

#include "mn_os.h"         /* must be #included before mn_defs.h */
#include "mn_defs.h"
#include "mn_env.h"
#include "mn_tasks.h"      /* must be #included after mn_defs.h */

#if (RTOS_USED != RTOS_NONE && ETHERNET && ARP)
/* workaround for ARP and RTOS - do not change */
#undef ARP_AUTO_UPDATE
#define ARP_AUTO_UPDATE  1
#endif      /* (RTOS_USED != RTOS_NONE && ETHERNET && ARP) */

#if ((HTTP || FTP) && !VIRTUAL_FILE)
#error HTTP and FTP require VIRTUAL_FILE
#endif
#if (HTTP && !TCP)
#error HTTP requires TCP
#endif
#if (FTP && !TCP)
#error FTP requires TCP
#endif
#if (SMTP && !TCP)
#error SMTP requires TCP
#endif
#if (!TCP && !UDP)
#error TCP or UDP must be selected
#endif
#if (ETHERNET && (PPP || SLIP))
#error Select Ethernet or PPP or SLIP
#endif
#if (PPP && SLIP)
#error Select PPP or SLIP not both
#endif
#if (!ETHERNET && !PPP && !SLIP)
#error Ethernet or PPP or SLIP must be selected
#endif
#if (DHCP && BOOTP)
#error Select DHCP or BOOTP not both
#endif
#if (DHCP && !UDP)
#error DHCP requires UDP
#endif
#if (BOOTP && !UDP)
#error BOOTP requires UDP
#endif
#if (TFTP && !UDP)
#error TFTP requires UDP
#endif
#if (MODEM && !(PPP || SLIP))
#error Modem requires PPP or SLIP
#endif

#if (NUM_SOCKETS < 1 || NUM_SOCKETS > 127)
#error Number of sockets must be between 1 and 127
#endif
#if (NUM_SOCKETS < 2 && (PING || ARP))
#error At least two sockets are required when using ARP or PING
#endif

#if (!(ETHERNET) && !(USE_RECV_BUFF))
#error For PPP and SLIP USE_RECV_BUFF must be set to 1.
#endif      /* (!(ETHERNET) && !(USE_RECV_BUFF)) */

#if (ETHERNET)
#if (USE_RECV_BUFF)
#if (RECV_BUFF_SIZE < 64)
#error RECV_BUFF_SIZE is too small!
#endif
#endif      /* (USE_RECV_BUFF) */
#if (USE_SEND_BUFF)
#if (XMIT_BUFF_SIZE < 64)
#error XMIT_BUFF_SIZE is too small!
#endif
#endif      /* (USE_SEND_BUFF) */
#endif      /* (ETHERNET) */

#if (ETHERNET && ARP)
#if (ARP_CACHE_SIZE < 1 || ARP_CACHE_SIZE > 255)
#error Invalid ARP_CACHE_SIZE
#endif      /* (ARP_CACHE_SIZE < 1 || ARP_CACHE_SIZE > 255) */
#endif      /* (ETHERNET && ARP) */

#if (TCP)
#if (USE_RECV_BUFF)
#if (TCP_WINDOW > RECV_BUFF_SIZE)
#error TCP_WINDOW too large for buffers
#endif      /* (USE_RECV_BUFF) */
#endif

#if ( ((SOCKET_WAIT_TICKS)*TCP_RESEND_TRYS) >= 65536 )
#error The product of SOCKET_WAIT_TICKS and TCP_RESEND_TRYS must be less than 65536
#endif
#endif      /* TCP */

#if (IGMP && !ALLOW_MULTICAST)
#error IGMP requires ALLOW_MULTICAST
#endif      /* (IGMP && !ALLOW_MULTICAST) */

#if (ALLOW_MULTICAST && !UDP)
#error Multicasting only works with UDP
#endif      /* (ALLOW_MULTICAST && !UDP) */

#if FTP
#if FTP_MAX_PARAM < 23
#error FTP_MAX_PARAM must be at least 23
#endif
#if FTP_NUM_USERS > 127
#error FTP_NUM_USERS must be less than 128
#endif
#if (FTP_BUFFER_LEN < TCP_WINDOW)
#error FTP_BUFFER_LEN is too small
#endif      /* (FTP_BUFFER_LEN < TCP_WINDOW) */
#endif      /* FTP */

#if (SMTP)
#if (SMTP_BUFFER_LEN < 46)
#error SMTP_BUFFER_LEN is too small
#endif
#endif      /* SMTP */

#if (HTTP && SERVER_SIDE_INCLUDES && !NUM_GET_FUNCS)
#error Use of SERVER_SIDE_INCLUDES requires NUM_GET_FUNCS greater than 0
#endif      /* HTTP && SERVER_SIDE_INCLUDES && !NUM_GET_FUNCS */

#if (HTTP && SERVER_SIDE_INCLUDES)
#if (HTTP_BUFFER_LEN < TCP_WINDOW)
#error HTTP_BUFFER_LEN is too small
#endif      /* (HTTP_BUFFER_LEN < TCP_WINDOW) */
#endif      /* HTTP && SERVER_SIDE_INCLUDES */

/*********************************************************/

#include "mn_port.h"
#include "mn_error.h"

#include "mn_timer.h"
#include "socket.h"
#if ETHERNET
#include "arp.h"
#include "ethernet.h"
#endif   /* ETHERNET */
#include "ip.h"
#include "mn_csum.h"
#include "callback.h"
#include "physical.h"
#include "support.h"
#include "mnstring.h"
#include "mnserver.h"

#if TCP
#include "tcp.h"
#endif

#if UDP
#include "udp.h"
#endif

#if IGMP
#include "igmp.h"
#endif

#if SLIP
#include "slip.h"
#endif

#if PPP
#include "ppp.h"
#endif

#if MODEM
#include "modem.h"
#endif

#if VIRTUAL_FILE
#include "vfile.h"
#endif

#if HTTP
#include "http.h"
#endif

#if FTP
#if FTP_SERVER
#include "ftpservr.h"
#endif
#include "mn_mem.h"
#endif

#if DHCP
#include "dhcp.h"
#endif      /* DHCP */

/* bww */
#if BOOTP
#include "bootp.h"
#endif      /* BOOTP */

#if TFTP
#include "tftp.h"
#endif

#if SMTP
#include "smtp.h"
#endif

#include "mnextern.h"

#endif   /* #ifndef MICRONET_H_INC */
