// Generated 12/7/00 11:24 PM By FastChip Version 1999 Build 30 

//////////////////////////////////////////////////////////////////////////////
//
//  ----------------------------------
//  ------   GENERATED CODE   --------
//  ----------------------------------
//  The code in this header file was generated automatically for your
//  project by Triscend FastChip. Please DO NOT EDIT this header file.
//  It will be overwritten the next time FastChip generates code for
//  your project.
//
//////////////////////////////////////////////////////////////////////////////

//======== Required symbol and macro definitions ========

#ifdef PROTOTYPE_ONLY
#   define CHAR_XDATA(name,location) extern volatile unsigned char xdata name;
#   define CHAR_ARRAY_XDATA(name,location,size) extern volatile unsigned char xdata name[size];
#else
#   define CHAR_XDATA(name,location) volatile unsigned char xdata name _at_ location;
#   define CHAR_ARRAY_XDATA(name,location,size) volatile unsigned char xdata name[size] _at_ location;
#endif

//========= BEGIN SOFT MODULE REGISTER DECLARATIONS ======

//-------------------------------- Module dipsw 
    CHAR_XDATA (dipsw,0xefec)

//-------------------------------- Module iPS_LCD_100 
    CHAR_XDATA (iPS_LCD_100_REGSEL,0xefef)
    CHAR_XDATA (iPS_LCD_100_ENABLE,0xefee)
    CHAR_XDATA (iPS_LCD_100_RDREG,0xefed)
    CHAR_XDATA (iPS_LCD_100_WRREG,0xefe8)
    CHAR_XDATA (iPS_LCD_100_WRRD,0xefeb)
    CHAR_XDATA (iPS_LCD_100_RDWR,0xefea)

//-------------------------------- Module iPS_ETH8_100 
    CHAR_XDATA (iPS_ETH8_100_ENRSET,0xefe9)
    CHAR_ARRAY_XDATA (iPS_ETH8_100_RDWR,0xeff0,16)

//========== END SOFT MODULE REGISTER DECLARATIONS =======

//======== E5 byte addressable SFR registers ========
    // -- reserved (P0) --
    sfr     SP      =   0x81;
    sfr     DPL     =   0x82;
    sfr     DPH     =   0x83;
    sfr     DPL1    =   0x84;
    sfr     DPH1    =   0x85;
    sfr     DPS     =   0x86;
    sfr     PCON    =   0x87;
    sfr     TCON    =   0x88;
    sfr     TMOD    =   0x89;
    sfr     TL0     =   0x8a;
    sfr     TL1     =   0x8b;
    sfr     TH0     =   0x8c;
    sfr     TH1     =   0x8d;
    sfr     CKCON   =   0x8e;
    // -- reserved (P1) --
    sfr     SCON    =   0x98;
    sfr     SBUF    =   0x99;
    // -- reserved (P2) --
    sfr     IE      =   0xa8;
    sfr     SADDR   =   0xa9;
    // -- reserved (P3) --
    sfr     IP      =   0xb8;
    sfr     SADEN   =   0xb9;
    sfr     TA      =   0xc7;
    sfr     T2CON   =   0xc8;
    sfr     T2MOD   =   0xc9;
    sfr     RCAP2L  =   0xca;
    sfr     RCAP2H  =   0xcb;
    sfr     TL2     =   0xcc;
    sfr     TH2     =   0xcd;
    sfr     PSW     =   0xd0;
    sfr     WDCON   =   0xd8;
    sfr     ACC     =   0xe0;
    sfr     EIE     =   0xe8;
    sfr     B       =   0xf0;
    sfr     EIP     =   0xf8;

//======== E5 bit addressable SFR registers ========
//---------------------------- TCON
    sbit    TF1     =   0x8f;
    sbit    TR1     =   0x8e;
    sbit    TF0     =   0x8d;
    sbit    TR0     =   0x8c;
    sbit    IE1     =   0x8b;
    sbit    IT1     =   0x8a;
    sbit    IE0     =   0x89;
    sbit    IT0     =   0x88;
//---------------------------- SCON
    sbit    SM0     =   0x9f;
    sbit    SM1     =   0x9e;
    sbit    SM2     =   0x9d;
    sbit    REN     =   0x9c;
    sbit    TB8     =   0x9b;
    sbit    RB8     =   0x9a;
    sbit    TI      =   0x99;
    sbit    RI      =   0x98;
//---------------------------- IE
    sbit    EA      =   0xaf;
    // -- reserved --
    sbit    ET2     =   0xad;
    sbit    ES      =   0xac;
    sbit    ET1     =   0xab;
    sbit    EX1     =   0xaa;
    sbit    ET0     =   0xa9;
    sbit    EX0     =   0xa8;
//---------------------------- IP
    // -- reserved --
    // -- reserved --
    sbit    PT2     =   0xbd;
    sbit    PS      =   0xbc;
    sbit    PT1     =   0xbb;
    sbit    PX1     =   0xba;
    sbit    PT0     =   0xb9;
    sbit    PX0     =   0xb8;
//---------------------------- T2CON
    sbit    TF2     =   0xcf;
    sbit    EXF2    =   0xce;
    sbit    RCLK    =   0xcd;
    sbit    TCLK    =   0xcc;
    sbit    EXEN2   =   0xcb;
    sbit    TR2     =   0xca;
    sbit    C_T2    =   0xc9;
    sbit    CP_RL2  =   0xc8;
//---------------------------- PSW
    sbit    CY      =   0xd7;
    sbit    AC      =   0xd6;
    sbit    F0      =   0xd5;
    sbit    RS1     =   0xd4;
    sbit    RS0     =   0xd3;
    sbit    OV      =   0xd2;
    // -- reserved --
    sbit    P       =   0xd0;
//---------------------------- WDCON
    // -- reserved --
    sbit    POR     =   0xde;
    sbit    EHPI    =   0xdd;
    sbit    HPI     =   0xdc;
    sbit    WDIF    =   0xdb;
    sbit    WTRF    =   0xda;
    sbit    EWT     =   0xd9;
    sbit    RWT     =   0xd8;
//---------------------------- EIE
    // -- reserved --
    // -- reserved --
    // -- reserved --
    sbit    EWDI    =   0xec;
    // -- reserved --
    // -- reserved --
    // -- reserved --
    // -- reserved --
//---------------------------- EIP
    // -- reserved --
    // -- reserved --
    // -- reserved --
    sbit    PWDI    =   0xfc;
    // -- reserved --
    // -- reserved --
    // -- reserved --
    // -- reserved --


//========= Visible CRU Registers ========
#define E5CRU_VISIBLE_BASE_ADDR 0xf000
    CHAR_XDATA ( CMAP0_TAR,        0xff00 )
    CHAR_XDATA ( CMAP0_ALT,        0xff01 )
    CHAR_XDATA ( CMAP1_TAR_0,      0xff02 )
    CHAR_XDATA ( CMAP1_TAR_1,      0xff03 )
    CHAR_XDATA ( CMAP1_TAR_2,      0xff04 )
    CHAR_XDATA ( CMAP1_SRC,        0xff05 )
    CHAR_XDATA ( CMAP1_CTL,        0xff06 )
    CHAR_XDATA ( CMAP1_ALT,        0xff07 )
    CHAR_XDATA ( CMAP2_TAR_0,      0xff08 )
    CHAR_XDATA ( CMAP2_TAR_1,      0xff09 )
    CHAR_XDATA ( CMAP2_TAR_2,      0xff0a )
    CHAR_XDATA ( CMAP2_SRC,        0xff0b )
    CHAR_XDATA ( CMAP2_CTL,        0xff0c )
    CHAR_XDATA ( CMAP2_ALT,        0xff0d )
    CHAR_XDATA ( DMAP0_TAR,        0xff0e )
    CHAR_XDATA ( DMAP1_TAR_0,      0xff0f )
    CHAR_XDATA ( DMAP1_TAR_1,      0xff10 )
    CHAR_XDATA ( DMAP1_TAR_2,      0xff11 )
    CHAR_XDATA ( DMAP1_SRC,        0xff12 )
    CHAR_XDATA ( DMAP1_CTL,        0xff13 )
    CHAR_XDATA ( DMAP2_TAR_0,      0xff14 )
    CHAR_XDATA ( DMAP2_TAR_1,      0xff15 )
    CHAR_XDATA ( DMAP2_TAR_2,      0xff16 )
    CHAR_XDATA ( DMAP2_SRC,        0xff17 )
    CHAR_XDATA ( DMAP2_CTL,        0xff18 )
    CHAR_XDATA ( DMAP3_TAR,        0xff19 )
    CHAR_XDATA ( DMAP3_SRC,        0xff1a )
    CHAR_XDATA ( DMAP3_CTL,        0xff1b )
    // -- reserved --
    // -- reserved --
    // -- reserved --
    // -- reserved --
    CHAR_XDATA ( DMASADR0_0,       0xff20 )
    CHAR_XDATA ( DMASADR0_1,       0xff21 )
    CHAR_XDATA ( DMASADR0_2,       0xff22 )
    CHAR_XDATA ( DMASADR0_3,       0xff23 )
    CHAR_XDATA ( DMASCNT0_0,       0xff24 )
    CHAR_XDATA ( DMASCNT0_1,       0xff25 )
    CHAR_XDATA ( DMASCNT0_2,       0xff26 )
    CHAR_XDATA ( DMACTRL0_0,       0xff27 )
    CHAR_XDATA ( DMACTRL0_1,       0xff28 )
    CHAR_XDATA ( DMAEINT0,         0xff29 )
    CHAR_XDATA ( DMAINT0,          0xff2a )
    CHAR_XDATA ( DMACADR0_0,       0xff2b )
    CHAR_XDATA ( DMACADR0_1,       0xff2c )
    CHAR_XDATA ( DMACADR0_2,       0xff2d )
    CHAR_XDATA ( DMACADR0_3,       0xff2e )
    CHAR_XDATA ( DMACCNT0_0,       0xff2f )
    CHAR_XDATA ( DMACCNT0_1,       0xff30 )
    CHAR_XDATA ( DMACCNT0_2,       0xff31 )
    CHAR_XDATA ( DMAPREQ0_0,       0xff32 )
    CHAR_XDATA ( DMAPREQ0_1,       0xff33 )
    CHAR_XDATA ( DMASADR1_0,       0xff34 )
    CHAR_XDATA ( DMASADR1_1,       0xff35 )
    CHAR_XDATA ( DMASADR1_2,       0xff36 )
    CHAR_XDATA ( DMASADR1_3,       0xff37 )
    CHAR_XDATA ( DMASCNT1_0,       0xff38 )
    CHAR_XDATA ( DMASCNT1_1,       0xff39 )
    CHAR_XDATA ( DMASCNT1_2,       0xff3a )
    CHAR_XDATA ( DMACTRL1_0,       0xff3b )
    CHAR_XDATA ( DMACTRL1_1,       0xff3c )
    CHAR_XDATA ( DMAEINT1,         0xff3d )
    CHAR_XDATA ( DMAINT1,          0xff3e )
    CHAR_XDATA ( DMACADR1_0,       0xff3f )
    CHAR_XDATA ( DMACADR1_1,       0xff40 )
    CHAR_XDATA ( DMACADR1_2,       0xff41 )
    CHAR_XDATA ( DMACADR1_3,       0xff42 )
    CHAR_XDATA ( DMACCNT1_0,       0xff43 )
    CHAR_XDATA ( DMACCNT1_1,       0xff44 )
    CHAR_XDATA ( DMACCNT1_2,       0xff45 )
    CHAR_XDATA ( DMAPREQ1_0,       0xff46 )
    CHAR_XDATA ( DMAPREQ1_1,       0xff47 )
    CHAR_XDATA ( DMACRC_0,         0xff48 )
    CHAR_XDATA ( DMACRC_1,         0xff49 )

    CHAR_XDATA ( PROTECT,          0xff60 )
    CHAR_XDATA ( SECURITY,         0xff61 )
    CHAR_XDATA ( PWDSEL,           0xff62 )
    CHAR_XDATA ( PORCTRL,          0xff63 )

    CHAR_XDATA ( DMAP4_TAR_0,      0xff80 )
    CHAR_XDATA ( DMAP4_TAR_1,      0xff81 )
    CHAR_XDATA ( DMAP4_TAR_2,      0xff82 )
    CHAR_XDATA ( DMAP4_SRC,        0xff83 )
    CHAR_XDATA ( DMAP4_CTL,        0xff84 )
    CHAR_XDATA ( DMAP5_TAR_0,      0xff85 )
    CHAR_XDATA ( DMAP5_TAR_1,      0xff86 )
    CHAR_XDATA ( DMAP5_TAR_2,      0xff87 )
    CHAR_XDATA ( DMAP5_SRC,        0xff88 )
    CHAR_XDATA ( DMAP5_CTL,        0xff89 )


//**************************************************************
// The following are the function declarations for 'Timer_0'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void Timer_0_INIT ();
#else

//*********************************************
// Initialization Routine for 'Timer_0'
//*********************************************

void Timer_0_INIT () {

// TIMER 0 INITIALIZATION ROUTINE
// ==============================

//    Version = 0.8
//       Mode = 1
//       Type = Timer


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.


// TMOD (Address 0x89)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |        Timer 1        |        Timer 0        |
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | GATE| C/T |  M1 |  M0 | GATE| C/T |  M1 |  M0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  1  |  0  |  0  |  1  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// TCON (Address 0x88)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | TF1 | TR1 | TF0 | TR0 | IE1 | IT1 | IE0 | IT0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  0  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// CKCON (Address 0x8e)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    | WD1 | WD0 | T2M | T1M | T0M |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  0  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// IE (Address 0xA8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  EA |     | ET2 |  ES | ET1 | EX1 | ET0 | EX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  -  |  -  |  0  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

    TR0 = 0;      // Disable Timer 0 (TCON.4)
    TMOD &= 0x0F0;   // Clear Timer 0 bits (lower nibble) in TMOD register
    TMOD |= 0x09; // Set appropriate bits for Timer 0
    TL0 = 0x00;      // Set Timer 0 low byte to user-defined value
    TH0 = 0x00;      // Set Timer 0 high byte to user-defined value

    CKCON &= 0x0F7;  // Timer 0 clock source is (BusClock / 12) (CKCON.3)

    ET0 = 0;            // Set or clear Timer 0 interrupt (IE.1)

}

#endif


//**************************************************************
// The following are the function declarations for 'Timer_1'
//**************************************************************
//

#ifdef PROTOTYPE_ONLY
    extern void Timer_1_INIT ();
#else

//*********************************************
// Initialization Routine for 'Timer_1'
//*********************************************


void Timer_1_INIT () {

// TIMER 1 INITIALIZATION ROUTINE
// ==============================

//    Version = 0.8
//       Mode = 1
//       Type = Timer


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.


// TMOD (Address 0x89)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |        Timer 1        |        Timer 0        |
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | GATE| C/T |  M1 |  M0 | GATE| C/T |  M1 |  M0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  1  |  0  |  0  |  1  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// TCON (Address 0x88)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | TF1 | TR1 | TF0 | TR0 | IE1 | IT1 | IE0 | IT0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  0  |  -  |  -  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// CKCON (Address 0x8e)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    | WD1 | WD0 | T2M | T1M | T0M |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  0  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

// IE (Address 0xA8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  EA |     | ET2 |  ES | ET1 | EX1 | ET0 | EX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  0  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

    TR1 = 0;      // Disable Timer 1 (TCON.6)
    TMOD &= 0x0F; // Clear Timer 1 bits (upper nibble) in TMOD register
    TMOD |= 0x90; // Set appropriate bits for Timer 1
    TL1 = 0x00;      // Set Timer 1 low byte to user-defined value
    TH1 = 0x00;      // Set Timer 1 high byte to user-defined value

    CKCON &= 0x0EF;  // Timer 1 clock source is (BusClock / 12) (CKCON.4)

    ET1 = 0;            // Set or clear Timer 1 interrupt (IE.3)

}

#endif

//**************************************************************
// The following are the function declarations for 'Timer_2'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void Timer_2_INIT ();
#else

//*********************************************
// Initialization Routine for 'Timer_2'
//*********************************************


void Timer_2_INIT () {

// TIMER 2 INITIALIZATION ROUTINE
// ==============================

//         Version = 0.8
//            Mode = 2

// RCAP2H (Address 0xCB) = 000H
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

// RCAP2L (Address 0xCA) = 000H
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// TH2 (Address 0xCD) = 000H
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// TL2 (Address 0xCC) = 000H
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// CKCON (Address 0x8E)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    | WD1 | WD0 | T2M | T1M | T0M |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  0  |  -  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// T2MOD (Address 0xC9)
//    +-----+-----+-----+-----+-----+-----+-----+-------+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |   0   |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-------+
//    |     |     |     |     |     |     |     |  DCEN |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=======+
//    |  -  |  -  |  -  |  -  |  -  |  -  |  -  |   0   |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-------+


// T2CON (Address 0xC8)
//    +-----+-----+-----+-----+-----+-----+-----+-------+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |   0   |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-------+
//    | TF2 | EXF2| RCLK| TCLK|EXEN2| TR2 | C/T2| CP/RL2|   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=======+
//    |  -  |  -  |  -  |  -  |  0  |  1  |  0  |   0   |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-------+


// IE (Address 0xA8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  EA |     | ET2 |  ES | ET1 | EX1 | ET0 | EX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  0  |  -  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

    TR2 = 0;      //Halt Timer 2, allows safe writing of RCAP2x registers (T2CON.2)
    RCAP2H = 0x00;   //Define high-byte in Timer 2 reload register
    RCAP2L = 0x00;   //Define low-byte in Timer 2 reload register
    TH2 = 0x00;      //Define high-byte in Timer 2 counter register
    TL2 = 0x00;      //Define low-byte in Timer 2 counter register
    T2MOD = 0x00; //Define down-count enable bit

    CKCON &= 0xdf;   //Timer 2 clock source is (BusClock / 12) (CKCON.5)

    ET2 = 0;            // Set or clear Timer 2 interrupt (IE.5)

    T2CON &= 0xfb;   //Clear appropriate bits in T2CON
    T2CON |= 0x04;   //Set appropriate bits in T2CON

}

#endif


//**************************************************************
// The following are the function declarations for 'UART'
//**************************************************************
//

#ifdef PROTOTYPE_ONLY
    extern void UART_INIT ();
#else

//*********************************************
// Initialization Routine for 'UART'
//*********************************************


void UART_INIT () {

// SERIAL PORT INITIALIZATION ROUTINE
// ==================================

//         Version = 0.9
//            Mode = -1
//        Receiver = Disabled
// Auto Addressing = Disabled


// ----- Set up control registers for UART
// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.


// SCON (Address 0x98)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | SM0 | SM1 | SM2 | REN | TB8 | RB8 |  TI |  RI |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// SBUF (Address 0x99) = 000H
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// PCON (Address 0x87)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | SMOD|     |     |     | GF1 | GF0 | PDE | IDLE|   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  -  |  -  |  -  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

// IE (Address 0xA8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  EA |     | ET2 |  ES | ET1 | EX1 | ET0 | EX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  0  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


    SCON = 0x00;  // Set up serial port control register
//    SBUF = 0x00;   // Clear UART buffer
    PCON |= 0x00; // Set double-rate bit, SMOD, if enabled

}


#endif

//**************************************************************
// The following are the function declarations for 'Interrupt'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void Interrupt_INIT ();
#else

//*********************************************
// Initialization Routine for 'Interrupt'
//*********************************************

void Interrupt_INIT () {

// INTERRUPT CONTROLLER INITIALIZATION ROUTINE
// ===========================================

//         Version = 0.8

// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.

// NOTES:
// =====
// Interrupt vector locations for the Triscend E5
//
// ---------------------------------+------------+---------------
//         INTERRUPT                |   VECTOR   |  KEIL INTR #
// ---------------------------------+------------+---------------
//  High-Priority Interrupt (HPINT)     0033h           6
//  External Interrupt (INT0)           0003h           0
//  Timer 0                             000Bh           1
//  External Interrupt (INT1)           0013h           2
//  Timer 1                             001Bh           3
//  UART                                0023h           4
//  Timer 2                             002Bh           5
//  DMA Controller                      003Bh           7
//  -- Reserved (hardware breakpoint)   0043h           8
//  -- Reserved (JTAG controller)       004Bh           9
//  -- Reserved (software breakpoint)   0053h          10
//  Watchdog Timer                      0063h          12


// Example Keil code for interrupt service routines (Watchdog timer)
//
// static void watchdogISR() interrupt 12 {
//     <your application code here>
// }


//  WDCON (Address 0xd8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     | POR | EHPI| HPI | WDIF| WTRF| EWT | RWT |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  0  |  0  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// TCON (Address 0x88)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    | TF1 | TR1 | TF0 | TR0 | IE1 | IT1 | IE0 | IT0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  -  |  0  |  -  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// IE (Address 0xA8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  EA |     | ET2 |  ES | ET1 | EX1 | ET0 | EX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  0  |  -  |  -  |  -  |  -  |  0  |  -  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//
//    NOTE:
//    ----
//       ET2 controlled by Timer 2 module
//       ES controlled by UART module
//       ET1 controlled by Timer 1 module
//       ET0 controlled by Timter 0 module


// IP (Address 0xB8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |     |     | PT2 |  PS | PT1 | PX1 | PT0 | PX0 |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// EIP (Address 0xF8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     |     |     | PWDI|     |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  0  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


  
    WDCON &= 0xCF;    // Disable high-priority interrupt, clear HPI flag
    IE    &= 0x7A;    // Disable all interrupts, clear EX1 and EX0

    TCON  |= 0x00;    // Set IT1 and IT0 as defined
    TCON  &= 0x55;    // Clear interrupt flags in TCON register

    IP    &= 0xC0;    // Clear IP register
    IP    |= 0x00;    // Set priority values in IP register

    PWDI  =  0;       // Set priority bit for watchdog timer

    IE    |= 0x00;    // Enable EX1, EX0, and EA (enable all interrupts) as defined
    WDCON |= 0x00;    // Enable high-priority interrupt (HPI), as defined

}

#endif /*PROTOTYPE_ONLY*/



//**************************************************************
// The following are the function declarations for 'Watchdog'
//**************************************************************
//

#ifdef PROTOTYPE_ONLY
    extern void Watchdog_INIT ();
#else

//*********************************************
// Initialization Routine for 'Watchdog'
//*********************************************


void Watchdog_INIT () {

// WATCHDOG TIMER INITIALIZATION ROUTINE
// =====================================

//    Version = 0.8
//       Mode =
//       Type =


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.


// WDCON (Address 0xd8) (IMPORTANT:  WDCON is timed-access protected!)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     | POR | EHPI| HPI | WDIF| WTRF| EWT | RWT |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// CKCON (Address 0x8e)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    | WD1 | WD0 | T2M | T1M | T0M |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  1  |  0  |  -  |  -  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// EIE (Address 0xe8)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     |     |     | EWDI|     |     |     |     |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  1  |  -  |  -  |  -  |  -  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+

    TA = 0xAA;      // Open timed-access window by writing 'AA' followed by
    TA = 0x55;      //     '55' to the TA register to access WDCON register
    RWT = 1;        // Reset watchdog timer to prevent MCU reset (WDCON.0)
    TA = 0xAA;      // Open timed-access window by writing 'AA' followed by
    TA = 0x55;      //     '55' to the TA register to access WDCON register
    WDCON &= 0xF0;  // Disable watchdog timer and clear watchdog flags
    CKCON |= 0x80;  // Set watchdog timer timeout value

    EWDI = 0;       // Enable or disabled watchdog interrupt (EWDI, EIE.4)

}

#endif


//**************************************************************
// The following are the function declarations for 'DMA_0'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void DMA_0_INIT ();
#else

//*********************************************
// Initialization Routine for 'DMA_0'
//*********************************************

void DMA_0_INIT () {

// DMA CHANNEL 0 INITIALIZATION ROUTINE
// ====================================

//    Version = 0.8
//       Mode = DMA_READ


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.



// DMACTRL0_0 (Address 0xff27)
//    +-----+-----+-----+------+-----+-----+-----+-----+
//    |  7  |  6  |  5  |   4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+======+=====+=====+=====+=====+
//    | W/R-| PAIR|BLOCK|SFTREQ| CONT| INIT|  EN | CLR |   BIT NAMES
//    +=====+=====+=====+======+=====+=====+=====+=====+
//    |  0  |  0  |  0  |   0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+------+-----+-----+-----+-----+


// DMACTRL0_1 (Address 0xff28)
//    +-----+-----+-----+-----+-----+------+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |   2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+======+=====+=====+
//    |     |     |     |     |     |CRC_EN|ADRM1|ADRM0|   BIT NAMES
//    +=====+=====+=====+=====+=====+======+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |   0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+------+-----+-----+


// DMAEINT0 (Address 0xff29)
//    +-----+-----+-----+-----+-----+------+-------+-----+
//    |  7  |  6  |  5  |  4  |  3  |   2  |   1   |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+======+=======+=====+
//    |     |     |     |     |     |OVR_EN|INIT_EN|TC_EN|   BIT NAMES
//    +=====+=====+=====+=====+=====+======+=======+=====+
//    |  0  |  0  |  0  |  0  |  0  |   0  |   0   |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+------+-------+-----+


// Set up the DMA Channel 0 control register
// -----------------------------------------
    DMACTRL0_0 = 0x01;                // Clear DMA channel 0 control register
    DMACTRL0_1 = 0x00;                // Set high-byte settings in control register
    DMACTRL0_0 = 0x00;                // Set low-byte settings in control register


// Set up the transfer count
// -------------------------
// NOTE:  TRANSFER_COUNT = (BYTE_COUNT - 1)
    DMASCNT0_0 = 0x00;                // Move transfer count low-byte of DMA 0 transfer count register
    DMASCNT0_1 = 0x00;                // Move transfer count mid-byte of DMA 0 transfer count register
    DMASCNT0_2 = 0x00;                // Move transfer count high-byte of DMA 0 transfer count register

    
// Enable the DMA Channel 0 interrupts
// -----------------------------------
    DMAINT0    = 0x07;                // Clear DMA channel 0 interrupt flags by writing ones to bit
    DMAEINT0   = 0x00;                // Enable DMA channel 0 interrupts


// NOTE:  Must still set up the Starting Address registers and
// ====   enable and initialize the channel before starting any transfers.
//
// DMA Start Address is a 32-bit _physical_ address value stored in the following locations
//
// DMASADR0_0 = Start_Address[7:0]
// DMASADR0_1 = Start_Address[15:8]
// DMASADR0_2 = Start_Address[23:16]
// DMASADR0_3 = Start_Address[31:24]

}

#endif


//**************************************************************
// The following are the function declarations for 'DMA_1'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void DMA_1_INIT ();
#else

//*********************************************
// Initialization Routine for 'DMA_1'
//*********************************************

void DMA_1_INIT () {

// DMA CHANNEL 1 INITIALIZATION ROUTINE
// ====================================

//    Version = 0.8
//       Mode = DMA_READ


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.



// DMACTRL1_0 (Address 0xff3b)
//    +-----+-----+-----+------+-----+-----+-----+-----+
//    |  7  |  6  |  5  |   4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+======+=====+=====+=====+=====+
//    | W/R-| PAIR|BLOCK|SFTREQ| CONT| INIT|  EN | CLR |   BIT NAMES
//    +=====+=====+=====+======+=====+=====+=====+=====+
//    |  0  |  0  |  0  |   0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+------+-----+-----+-----+-----+


// DMACTRL1_1 (Address 0xff3c)
//    +-----+-----+-----+-----+-----+------+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |   2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+======+=====+=====+
//    |     |     |     |     |     |CRC_EN|ADRM1|ADRM0|   BIT NAMES
//    +=====+=====+=====+=====+=====+======+=====+=====+
//    |  0  |  0  |  0  |  0  |  0  |   0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+------+-----+-----+


// DMAEINT1 (Address 0xff3d)
//    +-----+-----+-----+-----+-----+------+-------+-----+
//    |  7  |  6  |  5  |  4  |  3  |   2  |   1   |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+======+=======+=====+
//    |     |     |     |     |     |OVR_EN|INIT_EN|TC_EN|   BIT NAMES
//    +=====+=====+=====+=====+=====+======+=======+=====+
//    |  0  |  0  |  0  |  0  |  0  |   0  |   0   |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+------+-------+-----+

    
// Set up the DMA Channel 1 control register
// -----------------------------------------
    DMACTRL1_0 = 0x01;                // Clear DMA channel 1 control register
    DMACTRL1_1 = 0x00;                // Set high-byte settings in control register
    DMACTRL1_0 = 0x00;                // Set low-byte settings in control register


// Set up the transfer count
// -------------------------
// NOTE:  TRANSFER_COUNT = (BYTE_COUNT - 1)
    DMASCNT1_0 = 0x00;                // Move transfer count low-byte of DMA 1 transfer count register
    DMASCNT1_1 = 0x00;                // Move transfer count mid-byte of DMA 1 transfer count register
    DMASCNT1_2 = 0x00;                // Move transfer count high-byte of DMA 1 transfer count register


// Enable the DMA Channel 1 interrupts
// -----------------------------------
    DMAINT1    = 0x07;                // Clear DMA channel 1 interrupt flags by writing ones to bit
    DMAEINT1   = 0x00;                // Enable DMA channel 1 interrupts


// NOTE:  Must still set up the Starting Address registers and
// ====   enable and initialize the channel before starting any transfers.
//
// DMA Start Address is a 32-bit _physical_ address value stored in the following locations
//
// DMASADR1_0 = Start_Address[7:0]
// DMASADR1_1 = Start_Address[15:8]
// DMASADR1_2 = Start_Address[23:16]
// DMASADR1_3 = Start_Address[31:24]

}

#endif

//**************************************************************
// The following are the function declarations for 'Power'
//**************************************************************

#ifdef PROTOTYPE_ONLY
    extern void Power_INIT ();
#else

//*********************************************
// Initialization Routine for 'Power'
//*********************************************


void Power_INIT () {

// POWER MANAGEMENT INITIALIZATION ROUTINE
// =======================================
//    Version = 0.8
//       Mode =
//       Type =


// This initialization routing modifies the following registers:
// Note:  A dash (-) in a register location indicates an untouched bit.

// PCON (Address 0x87)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    | SMOD|SMOD0|     |     | GF1 | GF0 |  PD | IDL |   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  -  |  -  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// PWDSEL (Address XDATA 0xff62)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     |     | PIO | XTAL| OSC | GBUF| CSL | BCLK|   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  0  |  0  |  0  |  0  |  0  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


// PORCTRL (Address XDATA 0xff63)
//    +-----+-----+-----+-----+-----+-----+-----+-----+
//    |  7  |  6  |  5  |  4  |  3  |  2  |  1  |  0  |   BIT LOCATIONS
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |     |     |     |     |     |     |     |PORCT|   BIT NAMES
//    +=====+=====+=====+=====+=====+=====+=====+=====+
//    |  -  |  -  |  -  |  -  |  -  |  -  |  -  |  0  |   REGISTER VALUE
//    +-----+-----+-----+-----+-----+-----+-----+-----+


    PWDSEL  = 0x00;        // Set power-down options in PWDSEL

    PORCTRL = 0x00;        // Write the POR enable/disable value into the PORCTRL

    PCON   &= 0xfc;        // Clear power-down bit (PD, PCON.1) and idle bit (IDL, PCON.0)
}

#endif  /* PROTOTYPE_ONLY */


//========= PROJECT INITIALIZATION FUNCTION ======

#ifdef PROTOTYPE_ONLY

extern void iKitEth8v100_INIT();

#else

void iKitEth8v100_INIT () {
    Timer_0_INIT();
    Timer_1_INIT();
    Timer_2_INIT();
    UART_INIT();
    Interrupt_INIT();
    Watchdog_INIT();
    DMA_0_INIT();
    DMA_1_INIT();
    Power_INIT();
}

#endif
