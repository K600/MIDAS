/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

/* run checksum on pseudo header and ports. 
   pseudo header is:
                  0      7 8     15 16    23 24    31 
                 +--------+--------+--------+--------+
                 |          source address           |
                 +--------+--------+--------+--------+
                 |        destination address        |
                 +--------+--------+--------+--------+
                 |  zero  |protocol| TCP/UDP length  |
                 +--------+--------+--------+--------+
*/

/* bww Modified to allow us to specify src ip addr. */

word32 mn_udp_tcp_start_checksum(byte proto, word16 len, word16 port1, word16 port2, \
                         byte *srcaddr, byte *dstaddr)
cmx_reentrant {
   word32 csum;

   csum = CSUM_WORD16(srcaddr[0],srcaddr[1]);
   csum += CSUM_WORD16(srcaddr[2],srcaddr[3]);
   csum += CSUM_WORD16(dstaddr[0],dstaddr[1]);
   csum += CSUM_WORD16(dstaddr[2],dstaddr[3]);
   csum += proto;
   csum += len;
   csum += port1;
   csum += port2;

   if (proto == PROTO_UDP) /* finish UDP header checksum */
      csum += len;

#if 0
   /* ensure that csum does not overflow */
   while (csum >> 16)
      csum = (csum & 0xFFFF) + (csum >> 16);
#endif

   return (csum);
}
      
#if ( TCP || (UDP && UDP_CHKSUM) )
/* update the checksum from the data to be sent */
word32 mn_data_send_checksum(word32 csum, byte * data_ptr, word16 data_len)
cmx_reentrant {
   word16 temp_data;
   byte odd_byte;

   if (data_len)
      {
      odd_byte = (byte)(data_len & 0x01);
      data_len >>= 1;               /* convert bytes to words */
      /* we could do this more efficiently if we knew that data_ptr
         always had the proper alignment.  This also assumes that the
         string pointed to by data_ptr is always terminated with a NULL.

         modified 12/18/00 so string does not have to be NULL terminated.
      */
      while (data_len--)            /* sum up data */
         {
         temp_data = LSHIFT8(*data_ptr++);
         temp_data += (word16)(*data_ptr++);
         csum += temp_data;
         }

      if (odd_byte)
         {
         temp_data = LSHIFT8(*data_ptr);
         temp_data &= 0xff00;
         csum += temp_data;
         }
      }

   return (csum);
}
#endif      /* #if (TCP || (UDP && UDP_CHKSUM)) */

/* finish checksum calculation */
word32 mn_udp_tcp_end_checksum(word32 csum)
cmx_reentrant {
   while (csum >> 16)
      csum = (csum & 0xFFFF) + (csum >> 16);

   return (~csum & 0xFFFF);
}


