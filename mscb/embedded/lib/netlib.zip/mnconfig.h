/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MNCONFIG_H_INC
#define MNCONFIG_H_INC 1

/* Watchdog ## SR */
#define USE_WATCHDOG

/* Protocols */
#define TCP         1 
#define UDP         1 
#define UDP_CHKSUM  1 
#define ETHERNET    1 
#define SLIP        0 
#define PPP         0 
#define PING        1 
#define IGMP        1 

/* Sockets */
#define NUM_SOCKETS                 16
#define SOCKET_WAIT_TICKS          600
#define RECV_BUFF_SIZE            1024
#define XMIT_BUFF_SIZE            1024
#define SOCKET_INACTIVITY_TIME       0

/* TCP/IP options */
#define TIME_TO_LIVE                64 
#define TCP_WINDOW                 512 
#define TCP_RESEND_TICKS            50 // orig: 600 ## SR
#define TCP_RESEND_TRYS             60 // orig: 12 
#define PING_GLEANING                0 
#define PING_BUFF_SIZE              64 // for linux, orig: 32
#define ALLOW_BROADCAST              0 
#define ALLOW_MULTICAST              1 
#define MULTICAST_TTL                4 // for inside PSI, orig: 1 ## SR 
#define IGMP_LIST_SIZE               4 
                                     
/* Ethernet */                       
#define POLLED_ETHERNET              1 
#define ETHER_WAIT_TICKS             5 

/* ARP */
#define ARP                          1      
#define ARP_TIMEOUT                  0      
#define ARP_AUTO_UPDATE              1      
#define ARP_CACHE_SIZE              10 // orig: 2     
#define ARP_KEEP_TICKS            6000      
#define ARP_RESEND_TRYS              6      
#define ARP_WAIT_TICKS             600      

/* DHCP */
#define DHCP                         1 
#define DHCP_RESEND_TRYS             3 // orig: 4
#define DHCP_DEFAULT_LEASE_TIME  36000

/* BOOTP */
#define BOOTP                        0 
#define BOOTP_RESEND_TRYS            6
#define BOOTP_REQUEST_IP             1 

/* PPP options */
#define USE_PAP                      1  
#define PAP_USER_LEN                10 
#define PAP_PASSWORD_LEN            10 
#define PAP_NUM_USERS                1  
#define PPP_RESEND_TICKS           300
#define PPP_RESEND_TRYS              6  
#define PPP_TERMINATE_TRYS           2  
#define FAST_FCS                     1  

/* Modem */
#define MODEM                        0
#define DIRECT_CONNECT               1
#define NULL_MODEM                   1
#define REMOTE_IS_NT                 1
#define USE_PASSWORD                 0

/* HTTP */
#define HTTP                         0  
#define SERVER_SIDE_INCLUDES         1  
#define INCLUDE_HEAD                 0  
#define URI_BUFFER_LEN              52 
#define BODY_BUFFER_LEN             52 
#define HTTP_BUFFER_LEN            512

/* FTP */
#define FTP                          0   
#define NEED_MEM_POOL                0   
#define MEM_POOL_SIZE             4096
#define FTP_SERVER                   0   
#define FTP_MAX_PARAM               24  
#define FTP_BUFFER_LEN             512 
#define FTP_USER_LEN                10  
#define FTP_PASSWORD_LEN            10  
#define FTP_NUM_USERS                1   
#define FTP_CLIENT                   0  
#define FTPC_USER_LEN               10 
#define FTPC_PASSWORD_LEN           10 
#define FTPC_ACCOUNT_LEN             0  
#define FTPC_CMD_BUFF_SIZE          64  
#define FTPC_REPLY_BUFF_SIZE        64  
#define FTPC_FILE_BUFFER_LEN       250 
#define FTPC_WAIT_TICKS            600 

/* TFTP */
#define TFTP                         0
#define TFTP_RESEND_TRYS             3
#define TFTP_USE_FLASH               0

/* SMTP */
#define SMTP                         0   
#define SMTP_BUFFER_LEN            512 

/* SNMP */
#define SNMP                         0 
#define SNMP_VERSION2C               0 
#define SNMP_TRAP                    1 
#define SNMP_IN_BUFF_SIZE          484
#define SNMP_OUT_BUFF_SIZE         484

/* Virtual File System */
#define VIRTUAL_FILE                 0  
#define NUM_VF_PAGES                 8  
#define VF_NAME_LEN                 20 
#define FUNC_NAME_LEN               20 
#define NUM_POST_FUNCS               2  
#define NUM_GET_FUNCS                2  
#define USE_LONG_FSIZE               0 
#define USE_EFFS_THIN                0 
#define USE_EFFS                     0 
#define USE_EFFSM                    0 
#define USE_EFFS_FAT                 0 

#endif   /* ifndef MNCONFIG_H_INC */
