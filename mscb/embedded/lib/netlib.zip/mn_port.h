/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MN_PORT_H_INC
#define MN_PORT_H_INC   1

void init_recv(void) cmx_reentrant;
void init_io_buffs(void) cmx_reentrant;
byte mn_transmit_ready(void) cmx_reentrant;
void mn_uart_init(void) cmx_reentrant;
void mn_timer_init(void) cmx_reentrant;

#endif      /* #ifndef MN_PORT_H_INC */
