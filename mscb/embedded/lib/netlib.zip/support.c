/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#include "micronet.h"

/* convert an unsigned short to ascii and copy to a string
   returns number of bytes added to string
*/
byte mn_ustoa(byte *str,word16 num)
cmx_reentrant {

   byte digit,suppress;
   word16 divisor;
   byte num_bytes;
   byte * temp_str;

   num_bytes = 0;
   temp_str = str;

    divisor = 10000;
    suppress = 1;
    while( !( divisor == 1 )){
      digit = (byte)(num / divisor);
      num = num - (digit * divisor);
      divisor = divisor / 10;
      if( suppress  &&  digit )
         suppress = 0;
      if( !suppress )
         {
         digit |= '0';
         *temp_str++ = digit;
         num_bytes++;
         }
      }
   *temp_str++ = (byte)(num+'0');
   *temp_str = '\0';

   return (++num_bytes);
}

/* convert an unsigned char to ascii and copy to a string
   returns number of bytes added to string
*/
byte mn_uctoa(byte *str, byte num)
cmx_reentrant {

   byte digit,suppress;
   byte divisor;
   byte num_bytes;
   byte * temp_str;

   num_bytes = 0;
   temp_str = str;

    divisor = 100;
    suppress = 1;
    while( !( divisor == 1 )){
      digit = (byte)(num / divisor);
      num = (byte)(num - (digit * divisor));
      divisor = (byte)(divisor / 10);
      if( suppress  &&  digit )
         suppress = 0;
      if( !suppress )
         {
         digit |= '0';
         *temp_str++ = digit;
         num_bytes++;
         }
      }
   *temp_str++ = (byte)(num+'0');
   *temp_str = '\0';

   return (++num_bytes);
}

/* put current IP Address in str and return number of bytes added to str */
word16 mn_getMyIPAddr_func(byte **str)
cmx_reentrant {
   byte bytes_added;
   word16 num_bytes;
   byte *temp_ptr;
   static byte temp_str[16];

   num_bytes = 0;
   temp_str[0] = '\0';
   temp_ptr = temp_str;

#if (PPP || DHCP || BOOTP || PING_GLEANING)
   MN_MUTEX_WAIT(MUTEX_MN_INFO,INFINITE_WAIT);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING) */
   bytes_added = mn_uctoa(temp_ptr, ip_src_addr[0]);
   temp_ptr += bytes_added;
   num_bytes += bytes_added;
   *temp_ptr++ = '.';
   num_bytes++;
   bytes_added = mn_uctoa(temp_ptr, ip_src_addr[1]);
   temp_ptr += bytes_added;
   num_bytes += bytes_added;
   *temp_ptr++ = '.';
   num_bytes++;
   bytes_added = mn_uctoa(temp_ptr, ip_src_addr[2]);
   temp_ptr += bytes_added;
   num_bytes += bytes_added;
   *temp_ptr++ = '.';
   num_bytes++;
   bytes_added = mn_uctoa(temp_ptr, ip_src_addr[3]);
   num_bytes += bytes_added;
#if (PPP || DHCP || BOOTP || PING_GLEANING)
   MN_MUTEX_RELEASE(MUTEX_MN_INFO);
#endif      /* (PPP || DHCP || BOOTP || PING_GLEANING) */

   *str = temp_str;

   return (num_bytes);
}

/* convert an ascii string to an unsigned short. assumes number is base 10. */
word16 mn_atous(byte *str)
cmx_reentrant {
   word16 retval;
   byte in_num;

   retval = 0;
   in_num = FALSE;

   /* skip everything until we hit the first number or end of string */
   while (*str)
      {
      if (*str >= '0' && *str <= '9')
         {
         in_num = TRUE;
         retval = (retval * 10) + (*str - '0');
         }
      else if (in_num)     /* hit a non-number */
         break;

      str++;
      }

   return (retval);
}
