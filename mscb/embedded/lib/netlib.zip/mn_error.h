/*********************************************************
Copyright (c) CMX Systems, Inc. 2004. All rights reserved
*********************************************************/

#ifndef MN_ERROR_H_INC
#define MN_ERROR_H_INC  1

/* error numbers */
#define NOT_ENOUGH_SOCKETS       -128
#define SOCKET_ALREADY_EXISTS    -127
#define NOT_SUPPORTED            -126
#define PPP_OPEN_FAILED          -125
#define TCP_OPEN_FAILED          -124
#define BAD_SOCKET_DATA          -123
#define SOCKET_NOT_FOUND         -122
#define SOCKET_TIMED_OUT         -121
#define BAD_IP_HEADER            -120
#define NEED_TO_LISTEN           -119
#define RECV_TIMED_OUT           -118
#define ETHER_INIT_ERROR         -117
#define ETHER_SEND_ERROR         -116
#define ETHER_RECV_ERROR         -115
#define NEED_TO_SEND             -114
#define UNABLE_TO_SEND           -113
#define VFILE_ENTRY_IN_USE       -112
#define TFTP_FILE_NOT_FOUND      -111
#define TFTP_NO_FILE_SPECIFIED   -110
#define TFTP_FILE_TOO_BIG        -109
#define TFTP_FAILED              -108
#define SMTP_ALREADY_OPEN        -107
#define SMTP_OPEN_FAILED         -106
#define SMTP_NOT_OPEN            -105
#define SMTP_BAD_PARAM_ERR       -104
#define SMTP_ERROR               -103
#define NEED_TO_EXIT             -102
#define FTP_FILE_MAXOUT          -101
#define DHCP_ERROR               -100
#define DHCP_LEASE_EXPIRED       -99
#define PPP_LINK_DOWN            -98
#define GET_FUNC_ERROR           -97
#define FTP_SERVER_DOWN          -96
#define ARP_REQUEST_FAILED       -95
#define NEED_IGNORE_PACKET       -94
#define TASK_DID_NOT_START       -93
#define DHCP_LEASE_RENEWING      -92
#define IGMP_ERROR               -91


/* TCP function error codes */
#define TCP_ERROR       -1
#define TCP_TOO_LONG    -2
#define TCP_BAD_HEADER  -3
#define TCP_BAD_CSUM    -4
#define TCP_BAD_FCS     -5
#define TCP_NO_CONNECT  -6

/* UDP error codes */
#define UDP_ERROR       -1
#define UDP_BAD_CSUM    -4
#define UDP_BAD_FCS     -5

#endif   /* #ifndef MN_ERROR_H_INC */

